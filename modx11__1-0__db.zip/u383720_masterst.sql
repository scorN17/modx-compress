-- phpMyAdmin SQL Dump
-- version 
-- http://www.phpmyadmin.net
--
-- Хост: u383720.mysql.masterhost.ru
-- Время создания: Июл 16 2016 г., 14:00
-- Версия сервера: 5.6.28
-- Версия PHP: 5.4.4-14+deb7u14

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `u383720_masterst`
--

-- --------------------------------------------------------

--
-- Структура таблицы `ms_active_users`
--

CREATE TABLE IF NOT EXISTS `ms_active_users` (
  `internalKey` int(9) NOT NULL DEFAULT '0',
  `username` varchar(50) NOT NULL DEFAULT '',
  `lasthit` int(20) NOT NULL DEFAULT '0',
  `id` int(10) DEFAULT NULL,
  `action` varchar(10) NOT NULL DEFAULT '',
  `ip` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`internalKey`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='Contains data about active users.';

--
-- Дамп данных таблицы `ms_active_users`
--

INSERT INTO `ms_active_users` (`internalKey`, `username`, `lasthit`, `id`, `action`, `ip`) VALUES
(1, 'admin', 1468666716, NULL, '31', '80.80.109.182');

-- --------------------------------------------------------

--
-- Структура таблицы `ms_categories`
--

CREATE TABLE IF NOT EXISTS `ms_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(45) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 COMMENT='Categories to be used snippets,tv,chunks, etc' AUTO_INCREMENT=12 ;

--
-- Дамп данных таблицы `ms_categories`
--

INSERT INTO `ms_categories` (`id`, `category`) VALUES
(1, 'Js'),
(2, 'Manager and Admin'),
(3, 'Search'),
(4, 'Content'),
(5, 'Navigation'),
(6, 'Forms'),
(7, 'Login'),
(8, '_ШАБЛОН'),
(9, '_SEO'),
(10, '_КАТАЛОГ'),
(11, '_МАГАЗИН');

-- --------------------------------------------------------

--
-- Структура таблицы `ms_documentgroup_names`
--

CREATE TABLE IF NOT EXISTS `ms_documentgroup_names` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `private_memgroup` tinyint(4) DEFAULT '0' COMMENT 'determine whether the document group is private to manager users',
  `private_webgroup` tinyint(4) DEFAULT '0' COMMENT 'determines whether the document is private to web users',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 COMMENT='Contains data used for access permissions.' AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `ms_documentgroup_names`
--

INSERT INTO `ms_documentgroup_names` (`id`, `name`, `private_memgroup`, `private_webgroup`) VALUES
(1, 'admin', 1, 0),
(2, 'manager', 1, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `ms_document_groups`
--

CREATE TABLE IF NOT EXISTS `ms_document_groups` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `document_group` int(10) NOT NULL DEFAULT '0',
  `document` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `document` (`document`),
  KEY `document_group` (`document_group`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='Contains data used for access permissions.' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `ms_event_log`
--

CREATE TABLE IF NOT EXISTS `ms_event_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `eventid` int(11) DEFAULT '0',
  `createdon` int(11) NOT NULL DEFAULT '0',
  `type` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1- information, 2 - warning, 3- error',
  `user` int(11) NOT NULL DEFAULT '0' COMMENT 'link to user table',
  `usertype` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0 - manager, 1 - web',
  `source` varchar(50) NOT NULL DEFAULT '',
  `description` text,
  PRIMARY KEY (`id`),
  KEY `user` (`user`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 COMMENT='Stores event and error logs' AUTO_INCREMENT=11 ;

--
-- Дамп данных таблицы `ms_event_log`
--

INSERT INTO `ms_event_log` (`id`, `eventid`, `createdon`, `type`, `user`, `usertype`, `source`, `description`) VALUES
(1, 0, 1468501341, 3, 0, 1, 'Snippet - PageContacts', '<h2 style="color:red">&laquo; MODX Parse Error &raquo;</h2><div style="font-weight:bold;border:1px solid #ccc;padding:8px;color:#333;background-color:#ffffcd;margin-bottom:15px;">Error : mysql_query(): No such file or directory</div>\n<table class="grid">\n	<thead>\n	<tr class="">\n		<th width="100px" >Error information</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class="gridItem">\n		<td>ErrorType[num]</td>\n		<td>WARNING[2]</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>File</td>\n		<td>/home/u383720/masterstroy-rnd.ru/www/_new/manager/includes/document.parser.class.inc.php(1120) : eval()''d code</td>\n	</tr>\n	<tr class="gridItem">\n		<td>Line</td>\n		<td>15</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>Current Snippet</td>\n		<td>PageContacts</td>\n	</tr>\n</table>\n<br />\n<table class="grid">\n	<thead>\n	<tr class="">\n		<th width="100px" >Basic info</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class="gridItem">\n		<td>REQUEST_URI</td>\n		<td>http://masterstroy-rnd.ru/_new/contacts.html</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>Resource</td>\n		<td>[6] <a href="http://masterstroy-rnd.ru/_new/contacts.html" target="_blank">Контактная информация</a></td>\n	</tr>\n	<tr class="gridItem">\n		<td>Referer</td>\n		<td></td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>User Agent</td>\n		<td>Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36</td>\n	</tr>\n	<tr class="gridItem">\n		<td>IP</td>\n		<td>80.80.109.182</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>Current time</td>\n		<td>2016-07-14 16:02:21</td>\n	</tr>\n</table>\n<br />\n<table class="grid">\n	<thead>\n	<tr class="">\n		<th width="100px" >Benchmarks</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class="gridItem">\n		<td>MySQL</td>\n		<td>0.0021 s (5 Requests)</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>PHP</td>\n		<td>0.0179 s</td>\n	</tr>\n	<tr class="gridItem">\n		<td>Total</td>\n		<td>0.0200 s</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>Memory</td>\n		<td>1.7271118164062 mb</td>\n	</tr>\n</table>\n<br />\n<table class="grid">\n	<thead>\n	<tr class="">\n		<th>Backtrace</th>\n	</tr>\n	</thead>\n	<tr class="gridItem">\n		<td><strong>DocumentParser->executeParser</strong>()<br />index.php on line 145</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td><strong>DocumentParser->prepareResponse</strong>()<br />manager/includes/document.parser.class.inc.php on line 1803</td>\n	</tr>\n	<tr class="gridItem">\n		<td><strong>DocumentParser->outputContent</strong>()<br />manager/includes/document.parser.class.inc.php on line 1906</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td><strong>DocumentParser->parseDocumentSource</strong>(''[[PageContacts]]'')<br />manager/includes/document.parser.class.inc.php on line 634</td>\n	</tr>\n	<tr class="gridItem">\n		<td><strong>DocumentParser->evalSnippets</strong>(''[[PageContacts]]'')<br />manager/includes/document.parser.class.inc.php on line 1655</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td><strong>DocumentParser->_get_snip_result</strong>(''PageContacts'')<br />manager/includes/document.parser.class.inc.php on line 1172</td>\n	</tr>\n	<tr class="gridItem">\n		<td><strong>DocumentParser->evalSnippet</strong>(string $var1, array $var2)<br />manager/includes/document.parser.class.inc.php on line 1195</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td><strong>eval</strong>()<br />manager/includes/document.parser.class.inc.php on line 1120</td>\n	</tr>\n	<tr class="gridItem">\n		<td><strong>mysql_query</strong>(string $var1)<br />manager/includes/document.parser.class.inc.php(1120) : eval()''d code on line 15</td>\n	</tr>\n</table>\n'),
(2, 0, 1468501363, 3, 1, 0, 'Системные файлы были изменены.', 'Вы включили проверку системных файлов на наличие изменений, характерных для взломанных сайтов. Это не значит, что сайт был взломан, но желательно просмотреть измененные файлы.(index.php, .htaccess, manager/index.php, manager/includes/config.inc.php)'),
(3, 0, 1468501445, 3, 0, 1, 'Snippet - PageContacts', '<h2 style="color:red">&laquo; MODX Parse Error &raquo;</h2><div style="font-weight:bold;border:1px solid #ccc;padding:8px;color:#333;background-color:#ffffcd;margin-bottom:15px;">Error : mysql_query(): No such file or directory</div>\n<table class="grid">\n	<thead>\n	<tr class="">\n		<th width="100px" >Error information</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class="gridItem">\n		<td>ErrorType[num]</td>\n		<td>WARNING[2]</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>File</td>\n		<td>/home/u383720/masterstroy-rnd.ru/www/_new/manager/includes/document.parser.class.inc.php(1120) : eval()''d code</td>\n	</tr>\n	<tr class="gridItem">\n		<td>Line</td>\n		<td>15</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>Current Snippet</td>\n		<td>PageContacts</td>\n	</tr>\n</table>\n<br />\n<table class="grid">\n	<thead>\n	<tr class="">\n		<th width="100px" >Basic info</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class="gridItem">\n		<td>REQUEST_URI</td>\n		<td>http://masterstroy-rnd.ru/_new/contacts.html</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>Resource</td>\n		<td>[6] <a href="http://masterstroy-rnd.ru/_new/contacts.html" target="_blank">Контактная информация</a></td>\n	</tr>\n	<tr class="gridItem">\n		<td>Referer</td>\n		<td></td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>User Agent</td>\n		<td>Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36</td>\n	</tr>\n	<tr class="gridItem">\n		<td>IP</td>\n		<td>80.80.109.182</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>Current time</td>\n		<td>2016-07-14 16:04:05</td>\n	</tr>\n</table>\n<br />\n<table class="grid">\n	<thead>\n	<tr class="">\n		<th width="100px" >Benchmarks</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class="gridItem">\n		<td>MySQL</td>\n		<td>0.0016 s (5 Requests)</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>PHP</td>\n		<td>0.0186 s</td>\n	</tr>\n	<tr class="gridItem">\n		<td>Total</td>\n		<td>0.0202 s</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>Memory</td>\n		<td>1.7267608642578 mb</td>\n	</tr>\n</table>\n<br />\n<table class="grid">\n	<thead>\n	<tr class="">\n		<th>Backtrace</th>\n	</tr>\n	</thead>\n	<tr class="gridItem">\n		<td><strong>DocumentParser->executeParser</strong>()<br />index.php on line 145</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td><strong>DocumentParser->prepareResponse</strong>()<br />manager/includes/document.parser.class.inc.php on line 1803</td>\n	</tr>\n	<tr class="gridItem">\n		<td><strong>DocumentParser->outputContent</strong>()<br />manager/includes/document.parser.class.inc.php on line 1906</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td><strong>DocumentParser->parseDocumentSource</strong>(''[[PageContacts]]'')<br />manager/includes/document.parser.class.inc.php on line 634</td>\n	</tr>\n	<tr class="gridItem">\n		<td><strong>DocumentParser->evalSnippets</strong>(''[[PageContacts]]'')<br />manager/includes/document.parser.class.inc.php on line 1655</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td><strong>DocumentParser->_get_snip_result</strong>(''PageContacts'')<br />manager/includes/document.parser.class.inc.php on line 1172</td>\n	</tr>\n	<tr class="gridItem">\n		<td><strong>DocumentParser->evalSnippet</strong>(string $var1, array $var2)<br />manager/includes/document.parser.class.inc.php on line 1195</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td><strong>eval</strong>()<br />manager/includes/document.parser.class.inc.php on line 1120</td>\n	</tr>\n	<tr class="gridItem">\n		<td><strong>mysql_query</strong>(string $var1)<br />manager/includes/document.parser.class.inc.php(1120) : eval()''d code on line 15</td>\n	</tr>\n</table>\n'),
(4, 0, 1468501938, 3, 0, 1, 'Snippet - PageContacts', '<h2 style="color:red">&laquo; MODX Parse Error &raquo;</h2><div style="font-weight:bold;border:1px solid #ccc;padding:8px;color:#333;background-color:#ffffcd;margin-bottom:15px;">Error : mysql_query(): No such file or directory</div>\n<table class="grid">\n	<thead>\n	<tr class="">\n		<th width="100px" >Error information</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class="gridItem">\n		<td>ErrorType[num]</td>\n		<td>WARNING[2]</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>File</td>\n		<td>/home/u383720/masterstroy-rnd.ru/www/_new/manager/includes/document.parser.class.inc.php(1120) : eval()''d code</td>\n	</tr>\n	<tr class="gridItem">\n		<td>Line</td>\n		<td>15</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>Current Snippet</td>\n		<td>PageContacts</td>\n	</tr>\n</table>\n<br />\n<table class="grid">\n	<thead>\n	<tr class="">\n		<th width="100px" >Basic info</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class="gridItem">\n		<td>REQUEST_URI</td>\n		<td>http://masterstroy-rnd.ru/_new/contacts.html</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>Resource</td>\n		<td>[6] <a href="http://masterstroy-rnd.ru/_new/contacts.html" target="_blank">Контактная информация</a></td>\n	</tr>\n	<tr class="gridItem">\n		<td>Referer</td>\n		<td></td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>User Agent</td>\n		<td>Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36</td>\n	</tr>\n	<tr class="gridItem">\n		<td>IP</td>\n		<td>80.80.109.182</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>Current time</td>\n		<td>2016-07-14 16:12:18</td>\n	</tr>\n</table>\n<br />\n<table class="grid">\n	<thead>\n	<tr class="">\n		<th width="100px" >Benchmarks</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class="gridItem">\n		<td>MySQL</td>\n		<td>0.0021 s (5 Requests)</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>PHP</td>\n		<td>0.0081 s</td>\n	</tr>\n	<tr class="gridItem">\n		<td>Total</td>\n		<td>0.0102 s</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>Memory</td>\n		<td>0.49552154541016 mb</td>\n	</tr>\n</table>\n<br />\n<table class="grid">\n	<thead>\n	<tr class="">\n		<th>Backtrace</th>\n	</tr>\n	</thead>\n	<tr class="gridItem">\n		<td><strong>DocumentParser->executeParser</strong>()<br />index.php on line 145</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td><strong>DocumentParser->prepareResponse</strong>()<br />manager/includes/document.parser.class.inc.php on line 1803</td>\n	</tr>\n	<tr class="gridItem">\n		<td><strong>DocumentParser->outputContent</strong>()<br />manager/includes/document.parser.class.inc.php on line 1906</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td><strong>DocumentParser->parseDocumentSource</strong>(''[[PageContacts]]'')<br />manager/includes/document.parser.class.inc.php on line 634</td>\n	</tr>\n	<tr class="gridItem">\n		<td><strong>DocumentParser->evalSnippets</strong>(''[[PageContacts]]'')<br />manager/includes/document.parser.class.inc.php on line 1655</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td><strong>DocumentParser->_get_snip_result</strong>(''PageContacts'')<br />manager/includes/document.parser.class.inc.php on line 1172</td>\n	</tr>\n	<tr class="gridItem">\n		<td><strong>DocumentParser->evalSnippet</strong>(string $var1, array $var2)<br />manager/includes/document.parser.class.inc.php on line 1195</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td><strong>eval</strong>()<br />manager/includes/document.parser.class.inc.php on line 1120</td>\n	</tr>\n	<tr class="gridItem">\n		<td><strong>mysql_query</strong>(string $var1)<br />manager/includes/document.parser.class.inc.php(1120) : eval()''d code on line 15</td>\n	</tr>\n</table>\n'),
(5, 0, 1468501938, 3, 0, 1, 'Snippet - PageContacts', '<h2 style="color:red">&laquo; MODX Parse Error &raquo;</h2><div style="font-weight:bold;border:1px solid #ccc;padding:8px;color:#333;background-color:#ffffcd;margin-bottom:15px;">Error : mysql_query(): No such file or directory</div>\n<table class="grid">\n	<thead>\n	<tr class="">\n		<th width="100px" >Error information</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class="gridItem">\n		<td>ErrorType[num]</td>\n		<td>WARNING[2]</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>File</td>\n		<td>/home/u383720/masterstroy-rnd.ru/www/_new/manager/includes/document.parser.class.inc.php(1120) : eval()''d code</td>\n	</tr>\n	<tr class="gridItem">\n		<td>Line</td>\n		<td>15</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>Current Snippet</td>\n		<td>PageContacts</td>\n	</tr>\n</table>\n<br />\n<table class="grid">\n	<thead>\n	<tr class="">\n		<th width="100px" >Basic info</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class="gridItem">\n		<td>REQUEST_URI</td>\n		<td>http://masterstroy-rnd.ru/_new/contacts.html</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>Resource</td>\n		<td>[6] <a href="http://masterstroy-rnd.ru/_new/contacts.html" target="_blank">Контактная информация</a></td>\n	</tr>\n	<tr class="gridItem">\n		<td>Referer</td>\n		<td></td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>User Agent</td>\n		<td>Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36</td>\n	</tr>\n	<tr class="gridItem">\n		<td>IP</td>\n		<td>80.80.109.182</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>Current time</td>\n		<td>2016-07-14 16:12:18</td>\n	</tr>\n</table>\n<br />\n<table class="grid">\n	<thead>\n	<tr class="">\n		<th width="100px" >Benchmarks</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class="gridItem">\n		<td>MySQL</td>\n		<td>0.0012 s (2 Requests)</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>PHP</td>\n		<td>0.0037 s</td>\n	</tr>\n	<tr class="gridItem">\n		<td>Total</td>\n		<td>0.0049 s</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>Memory</td>\n		<td>0.49753570556641 mb</td>\n	</tr>\n</table>\n<br />\n<table class="grid">\n	<thead>\n	<tr class="">\n		<th>Backtrace</th>\n	</tr>\n	</thead>\n	<tr class="gridItem">\n		<td><strong>DocumentParser->executeParser</strong>()<br />index.php on line 145</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td><strong>DocumentParser->prepareResponse</strong>()<br />manager/includes/document.parser.class.inc.php on line 1803</td>\n	</tr>\n	<tr class="gridItem">\n		<td><strong>DocumentParser->outputContent</strong>()<br />manager/includes/document.parser.class.inc.php on line 1906</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td><strong>DocumentParser->parseDocumentSource</strong>(''[[PageContacts]]'')<br />manager/includes/document.parser.class.inc.php on line 634</td>\n	</tr>\n	<tr class="gridItem">\n		<td><strong>DocumentParser->evalSnippets</strong>(''[[PageContacts]]'')<br />manager/includes/document.parser.class.inc.php on line 1655</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td><strong>DocumentParser->_get_snip_result</strong>(''PageContacts'')<br />manager/includes/document.parser.class.inc.php on line 1172</td>\n	</tr>\n	<tr class="gridItem">\n		<td><strong>DocumentParser->evalSnippet</strong>(string $var1, array $var2)<br />manager/includes/document.parser.class.inc.php on line 1195</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td><strong>eval</strong>()<br />manager/includes/document.parser.class.inc.php on line 1120</td>\n	</tr>\n	<tr class="gridItem">\n		<td><strong>mysql_query</strong>(string $var1)<br />manager/includes/document.parser.class.inc.php(1120) : eval()''d code on line 15</td>\n	</tr>\n</table>\n'),
(6, 0, 1468501991, 3, 0, 1, 'Snippet - PageContacts', '<h2 style="color:red">&laquo; MODX Parse Error &raquo;</h2><div style="font-weight:bold;border:1px solid #ccc;padding:8px;color:#333;background-color:#ffffcd;margin-bottom:15px;">Error : mysql_query(): No such file or directory</div>\n<table class="grid">\n	<thead>\n	<tr class="">\n		<th width="100px" >Error information</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class="gridItem">\n		<td>ErrorType[num]</td>\n		<td>WARNING[2]</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>File</td>\n		<td>/home/u383720/masterstroy-rnd.ru/www/_new/manager/includes/document.parser.class.inc.php(1120) : eval()''d code</td>\n	</tr>\n	<tr class="gridItem">\n		<td>Line</td>\n		<td>15</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>Current Snippet</td>\n		<td>PageContacts</td>\n	</tr>\n</table>\n<br />\n<table class="grid">\n	<thead>\n	<tr class="">\n		<th width="100px" >Basic info</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class="gridItem">\n		<td>REQUEST_URI</td>\n		<td>http://masterstroy-rnd.ru/_new/contacts.html</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>Resource</td>\n		<td>[6] <a href="http://masterstroy-rnd.ru/_new/contacts.html" target="_blank">Контактная информация</a></td>\n	</tr>\n	<tr class="gridItem">\n		<td>Referer</td>\n		<td></td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>User Agent</td>\n		<td>Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36</td>\n	</tr>\n	<tr class="gridItem">\n		<td>IP</td>\n		<td>80.80.109.182</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>Current time</td>\n		<td>2016-07-14 16:13:11</td>\n	</tr>\n</table>\n<br />\n<table class="grid">\n	<thead>\n	<tr class="">\n		<th width="100px" >Benchmarks</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class="gridItem">\n		<td>MySQL</td>\n		<td>0.0017 s (5 Requests)</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>PHP</td>\n		<td>0.0094 s</td>\n	</tr>\n	<tr class="gridItem">\n		<td>Total</td>\n		<td>0.0111 s</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>Memory</td>\n		<td>0.74753570556641 mb</td>\n	</tr>\n</table>\n<br />\n<table class="grid">\n	<thead>\n	<tr class="">\n		<th>Backtrace</th>\n	</tr>\n	</thead>\n	<tr class="gridItem">\n		<td><strong>DocumentParser->executeParser</strong>()<br />index.php on line 145</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td><strong>DocumentParser->prepareResponse</strong>()<br />manager/includes/document.parser.class.inc.php on line 1803</td>\n	</tr>\n	<tr class="gridItem">\n		<td><strong>DocumentParser->outputContent</strong>()<br />manager/includes/document.parser.class.inc.php on line 1906</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td><strong>DocumentParser->parseDocumentSource</strong>(''[[PageContacts]]'')<br />manager/includes/document.parser.class.inc.php on line 634</td>\n	</tr>\n	<tr class="gridItem">\n		<td><strong>DocumentParser->evalSnippets</strong>(''[[PageContacts]]'')<br />manager/includes/document.parser.class.inc.php on line 1655</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td><strong>DocumentParser->_get_snip_result</strong>(''PageContacts'')<br />manager/includes/document.parser.class.inc.php on line 1172</td>\n	</tr>\n	<tr class="gridItem">\n		<td><strong>DocumentParser->evalSnippet</strong>(string $var1, array $var2)<br />manager/includes/document.parser.class.inc.php on line 1195</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td><strong>eval</strong>()<br />manager/includes/document.parser.class.inc.php on line 1120</td>\n	</tr>\n	<tr class="gridItem">\n		<td><strong>mysql_query</strong>(string $var1)<br />manager/includes/document.parser.class.inc.php(1120) : eval()''d code on line 15</td>\n	</tr>\n</table>\n'),
(7, 0, 1468501992, 3, 0, 1, 'Snippet - PageContacts', '<h2 style="color:red">&laquo; MODX Parse Error &raquo;</h2><div style="font-weight:bold;border:1px solid #ccc;padding:8px;color:#333;background-color:#ffffcd;margin-bottom:15px;">Error : mysql_query(): No such file or directory</div>\n<table class="grid">\n	<thead>\n	<tr class="">\n		<th width="100px" >Error information</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class="gridItem">\n		<td>ErrorType[num]</td>\n		<td>WARNING[2]</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>File</td>\n		<td>/home/u383720/masterstroy-rnd.ru/www/_new/manager/includes/document.parser.class.inc.php(1120) : eval()''d code</td>\n	</tr>\n	<tr class="gridItem">\n		<td>Line</td>\n		<td>15</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>Current Snippet</td>\n		<td>PageContacts</td>\n	</tr>\n</table>\n<br />\n<table class="grid">\n	<thead>\n	<tr class="">\n		<th width="100px" >Basic info</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class="gridItem">\n		<td>REQUEST_URI</td>\n		<td>http://masterstroy-rnd.ru/_new/contacts.html</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>Resource</td>\n		<td>[6] <a href="http://masterstroy-rnd.ru/_new/contacts.html" target="_blank">Контактная информация</a></td>\n	</tr>\n	<tr class="gridItem">\n		<td>Referer</td>\n		<td></td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>User Agent</td>\n		<td>Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36</td>\n	</tr>\n	<tr class="gridItem">\n		<td>IP</td>\n		<td>80.80.109.182</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>Current time</td>\n		<td>2016-07-14 16:13:12</td>\n	</tr>\n</table>\n<br />\n<table class="grid">\n	<thead>\n	<tr class="">\n		<th width="100px" >Benchmarks</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class="gridItem">\n		<td>MySQL</td>\n		<td>0.0013 s (2 Requests)</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>PHP</td>\n		<td>0.0040 s</td>\n	</tr>\n	<tr class="gridItem">\n		<td>Total</td>\n		<td>0.0053 s</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>Memory</td>\n		<td>0.49753570556641 mb</td>\n	</tr>\n</table>\n<br />\n<table class="grid">\n	<thead>\n	<tr class="">\n		<th>Backtrace</th>\n	</tr>\n	</thead>\n	<tr class="gridItem">\n		<td><strong>DocumentParser->executeParser</strong>()<br />index.php on line 145</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td><strong>DocumentParser->prepareResponse</strong>()<br />manager/includes/document.parser.class.inc.php on line 1803</td>\n	</tr>\n	<tr class="gridItem">\n		<td><strong>DocumentParser->outputContent</strong>()<br />manager/includes/document.parser.class.inc.php on line 1906</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td><strong>DocumentParser->parseDocumentSource</strong>(''[[PageContacts]]'')<br />manager/includes/document.parser.class.inc.php on line 634</td>\n	</tr>\n	<tr class="gridItem">\n		<td><strong>DocumentParser->evalSnippets</strong>(''[[PageContacts]]'')<br />manager/includes/document.parser.class.inc.php on line 1655</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td><strong>DocumentParser->_get_snip_result</strong>(''PageContacts'')<br />manager/includes/document.parser.class.inc.php on line 1172</td>\n	</tr>\n	<tr class="gridItem">\n		<td><strong>DocumentParser->evalSnippet</strong>(string $var1, array $var2)<br />manager/includes/document.parser.class.inc.php on line 1195</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td><strong>eval</strong>()<br />manager/includes/document.parser.class.inc.php on line 1120</td>\n	</tr>\n	<tr class="gridItem">\n		<td><strong>mysql_query</strong>(string $var1)<br />manager/includes/document.parser.class.inc.php(1120) : eval()''d code on line 15</td>\n	</tr>\n</table>\n'),
(8, 0, 1468501992, 3, 0, 1, 'Snippet - PageContacts', '<h2 style="color:red">&laquo; MODX Parse Error &raquo;</h2><div style="font-weight:bold;border:1px solid #ccc;padding:8px;color:#333;background-color:#ffffcd;margin-bottom:15px;">Error : mysql_query(): No such file or directory</div>\n<table class="grid">\n	<thead>\n	<tr class="">\n		<th width="100px" >Error information</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class="gridItem">\n		<td>ErrorType[num]</td>\n		<td>WARNING[2]</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>File</td>\n		<td>/home/u383720/masterstroy-rnd.ru/www/_new/manager/includes/document.parser.class.inc.php(1120) : eval()''d code</td>\n	</tr>\n	<tr class="gridItem">\n		<td>Line</td>\n		<td>15</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>Current Snippet</td>\n		<td>PageContacts</td>\n	</tr>\n</table>\n<br />\n<table class="grid">\n	<thead>\n	<tr class="">\n		<th width="100px" >Basic info</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class="gridItem">\n		<td>REQUEST_URI</td>\n		<td>http://masterstroy-rnd.ru/_new/contacts.html</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>Resource</td>\n		<td>[6] <a href="http://masterstroy-rnd.ru/_new/contacts.html" target="_blank">Контактная информация</a></td>\n	</tr>\n	<tr class="gridItem">\n		<td>Referer</td>\n		<td></td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>User Agent</td>\n		<td>Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36</td>\n	</tr>\n	<tr class="gridItem">\n		<td>IP</td>\n		<td>80.80.109.182</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>Current time</td>\n		<td>2016-07-14 16:13:12</td>\n	</tr>\n</table>\n<br />\n<table class="grid">\n	<thead>\n	<tr class="">\n		<th width="100px" >Benchmarks</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class="gridItem">\n		<td>MySQL</td>\n		<td>0.0013 s (2 Requests)</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>PHP</td>\n		<td>0.0051 s</td>\n	</tr>\n	<tr class="gridItem">\n		<td>Total</td>\n		<td>0.0064 s</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>Memory</td>\n		<td>0.49753570556641 mb</td>\n	</tr>\n</table>\n<br />\n<table class="grid">\n	<thead>\n	<tr class="">\n		<th>Backtrace</th>\n	</tr>\n	</thead>\n	<tr class="gridItem">\n		<td><strong>DocumentParser->executeParser</strong>()<br />index.php on line 145</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td><strong>DocumentParser->prepareResponse</strong>()<br />manager/includes/document.parser.class.inc.php on line 1803</td>\n	</tr>\n	<tr class="gridItem">\n		<td><strong>DocumentParser->outputContent</strong>()<br />manager/includes/document.parser.class.inc.php on line 1906</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td><strong>DocumentParser->parseDocumentSource</strong>(''[[PageContacts]]'')<br />manager/includes/document.parser.class.inc.php on line 634</td>\n	</tr>\n	<tr class="gridItem">\n		<td><strong>DocumentParser->evalSnippets</strong>(''[[PageContacts]]'')<br />manager/includes/document.parser.class.inc.php on line 1655</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td><strong>DocumentParser->_get_snip_result</strong>(''PageContacts'')<br />manager/includes/document.parser.class.inc.php on line 1172</td>\n	</tr>\n	<tr class="gridItem">\n		<td><strong>DocumentParser->evalSnippet</strong>(string $var1, array $var2)<br />manager/includes/document.parser.class.inc.php on line 1195</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td><strong>eval</strong>()<br />manager/includes/document.parser.class.inc.php on line 1120</td>\n	</tr>\n	<tr class="gridItem">\n		<td><strong>mysql_query</strong>(string $var1)<br />manager/includes/document.parser.class.inc.php(1120) : eval()''d code on line 15</td>\n	</tr>\n</table>\n'),
(9, 0, 1468564050, 3, 1, 0, 'Системные файлы были изменены.', 'Вы включили проверку системных файлов на наличие изменений, характерных для взломанных сайтов. Это не значит, что сайт был взломан, но желательно просмотреть измененные файлы.(index.php, .htaccess, manager/index.php, manager/includes/config.inc.php)'),
(10, 0, 1468565536, 3, 0, 1, 'Snippet - Compress', '<h2 style="color:red">&laquo; MODX Parse Error &raquo;</h2><div style="font-weight:bold;border:1px solid #ccc;padding:8px;color:#333;background-color:#ffffcd;margin-bottom:15px;">Error : filesize(): stat failed for /home/u383720/masterstroy-rnd.ru/www/_new/template/css/dop.css</div>\n<table class="grid">\n	<thead>\n	<tr class="">\n		<th width="100px" >Error information</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class="gridItem">\n		<td>ErrorType[num]</td>\n		<td>WARNING[2]</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>File</td>\n		<td>/home/u383720/masterstroy-rnd.ru/www/_new/manager/includes/document.parser.class.inc.php(1120) : eval()''d code</td>\n	</tr>\n	<tr class="gridItem">\n		<td>Line</td>\n		<td>87</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>Current Snippet</td>\n		<td>Compress</td>\n	</tr>\n</table>\n<br />\n<table class="grid">\n	<thead>\n	<tr class="">\n		<th width="100px" >Basic info</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class="gridItem">\n		<td>REQUEST_URI</td>\n		<td>http://masterstroy-rnd.ru/_new/</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>Resource</td>\n		<td>[1] <a href="http://masterstroy-rnd.ru/_new/" target="_blank">Главная</a></td>\n	</tr>\n	<tr class="gridItem">\n		<td>Referer</td>\n		<td>http://masterstroy-rnd.ru/_new/manager/index.php?a=1&amp;amp;f=menu</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>User Agent</td>\n		<td>Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36</td>\n	</tr>\n	<tr class="gridItem">\n		<td>IP</td>\n		<td>80.80.109.182</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>Current time</td>\n		<td>2016-07-15 09:52:16</td>\n	</tr>\n</table>\n<br />\n<table class="grid">\n	<thead>\n	<tr class="">\n		<th width="100px" >Benchmarks</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class="gridItem">\n		<td>MySQL</td>\n		<td>0.0019 s (5 Requests)</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>PHP</td>\n		<td>0.0270 s</td>\n	</tr>\n	<tr class="gridItem">\n		<td>Total</td>\n		<td>0.0290 s</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td>Memory</td>\n		<td>2.730598449707 mb</td>\n	</tr>\n</table>\n<br />\n<table class="grid">\n	<thead>\n	<tr class="">\n		<th>Backtrace</th>\n	</tr>\n	</thead>\n	<tr class="gridItem">\n		<td><strong>DocumentParser->executeParser</strong>()<br />index.php on line 145</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td><strong>DocumentParser->prepareResponse</strong>()<br />manager/includes/document.parser.class.inc.php on line 1803</td>\n	</tr>\n	<tr class="gridItem">\n		<td><strong>DocumentParser->outputContent</strong>()<br />manager/includes/document.parser.class.inc.php on line 1906</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td><strong>DocumentParser->parseDocumentSource</strong>(string $var1)<br />manager/includes/document.parser.class.inc.php on line 634</td>\n	</tr>\n	<tr class="gridItem">\n		<td><strong>DocumentParser->evalSnippets</strong>(string $var1)<br />manager/includes/document.parser.class.inc.php on line 1655</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td><strong>DocumentParser->_get_snip_result</strong>(string $var1)<br />manager/includes/document.parser.class.inc.php on line 1172</td>\n	</tr>\n	<tr class="gridItem">\n		<td><strong>DocumentParser->evalSnippet</strong>(string $var1, array $var2)<br />manager/includes/document.parser.class.inc.php on line 1195</td>\n	</tr>\n	<tr class="gridAltItem">\n		<td><strong>eval</strong>()<br />manager/includes/document.parser.class.inc.php on line 1120</td>\n	</tr>\n	<tr class="gridItem">\n		<td><strong>filesize</strong>(string $var1)<br />manager/includes/document.parser.class.inc.php(1120) : eval()''d code on line 87</td>\n	</tr>\n</table>\n');

-- --------------------------------------------------------

--
-- Структура таблицы `ms_keyword_xref`
--

CREATE TABLE IF NOT EXISTS `ms_keyword_xref` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `keyword_id` int(11) NOT NULL DEFAULT '0',
  KEY `content_id` (`content_id`),
  KEY `keyword_id` (`keyword_id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='Cross reference bewteen keywords and content';

-- --------------------------------------------------------

--
-- Структура таблицы `ms_manager_log`
--

CREATE TABLE IF NOT EXISTS `ms_manager_log` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `timestamp` int(20) NOT NULL DEFAULT '0',
  `internalKey` int(10) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `action` int(10) NOT NULL DEFAULT '0',
  `itemid` varchar(10) DEFAULT '0',
  `itemname` varchar(255) DEFAULT NULL,
  `message` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 COMMENT='Contains a record of user interaction.' AUTO_INCREMENT=482 ;

--
-- Дамп данных таблицы `ms_manager_log`
--

INSERT INTO `ms_manager_log` (`id`, `timestamp`, `internalKey`, `username`, `action`, `itemid`, `itemname`, `message`) VALUES
(1, 1468498737, 1, 'admin', 58, '-', 'MODX', 'Logged in'),
(2, 1468498738, 1, 'admin', 17, '-', '-', 'Editing settings'),
(3, 1468498839, 1, 'admin', 118, '-', '-', 'Call settings ajax include'),
(4, 1468498843, 1, 'admin', 118, '-', '-', 'Call settings ajax include'),
(5, 1468498846, 1, 'admin', 118, '-', '-', 'Call settings ajax include'),
(6, 1468498853, 1, 'admin', 118, '-', '-', 'Call settings ajax include'),
(7, 1468498857, 1, 'admin', 118, '-', '-', 'Call settings ajax include'),
(8, 1468498868, 1, 'admin', 76, '-', '-', 'Element management'),
(9, 1468498869, 1, 'admin', 17, '-', '-', 'Editing settings'),
(10, 1468498990, 1, 'admin', 30, '-', '-', 'Saving settings'),
(11, 1468498999, 1, 'admin', 58, '-', 'MODX', 'Logged in'),
(12, 1468499173, 1, 'admin', 27, '1', 'MODX CMS Install Success', 'Editing resource'),
(13, 1468499189, 1, 'admin', 5, '1', 'Главная', 'Saving resource'),
(14, 1468499190, 1, 'admin', 3, '1', 'Главная', 'Viewing data for resource'),
(15, 1468499195, 1, 'admin', 4, '-', 'Новый ресурс', 'Creating a resource'),
(16, 1468499271, 1, 'admin', 5, '-', 'Доставка и оплата', 'Saving resource'),
(17, 1468499271, 1, 'admin', 4, '-', 'Новый ресурс', 'Creating a resource'),
(18, 1468499274, 1, 'admin', 4, '-', 'Новый ресурс', 'Creating a resource'),
(19, 1468499295, 1, 'admin', 5, '-', 'Верхнее меню', 'Saving resource'),
(20, 1468499296, 1, 'admin', 3, '3', 'Верхнее меню', 'Viewing data for resource'),
(21, 1468499297, 1, 'admin', 27, '1', 'Главная', 'Editing resource'),
(22, 1468499300, 1, 'admin', 5, '1', 'Главная', 'Saving resource'),
(23, 1468499301, 1, 'admin', 3, '1', 'Главная', 'Viewing data for resource'),
(24, 1468499302, 1, 'admin', 27, '2', 'Доставка и оплата', 'Editing resource'),
(25, 1468499305, 1, 'admin', 5, '2', 'Доставка и оплата', 'Saving resource'),
(26, 1468499307, 1, 'admin', 3, '2', 'Доставка и оплата', 'Viewing data for resource'),
(27, 1468499308, 1, 'admin', 27, '3', 'Верхнее меню', 'Editing resource'),
(28, 1468499314, 1, 'admin', 5, '3', 'Верхнее меню', 'Saving resource'),
(29, 1468499315, 1, 'admin', 3, '3', 'Верхнее меню', 'Viewing data for resource'),
(30, 1468499318, 1, 'admin', 27, '1', 'Главная', 'Editing resource'),
(31, 1468499319, 1, 'admin', 4, '-', 'Новый ресурс', 'Creating a resource'),
(32, 1468499331, 1, 'admin', 5, '-', 'Статьи', 'Saving resource'),
(33, 1468499331, 1, 'admin', 4, '-', 'Новый ресурс', 'Creating a resource'),
(34, 1468499340, 1, 'admin', 5, '-', 'Написать нам', 'Saving resource'),
(35, 1468499340, 1, 'admin', 4, '-', 'Новый ресурс', 'Creating a resource'),
(36, 1468499360, 1, 'admin', 5, '-', 'Контактная информация', 'Saving resource'),
(37, 1468499360, 1, 'admin', 4, '-', 'Новый ресурс', 'Creating a resource'),
(38, 1468499365, 1, 'admin', 75, '-', '-', 'User/ role management'),
(39, 1468499366, 1, 'admin', 12, '1', 'admin', 'Editing user'),
(40, 1468499373, 1, 'admin', 32, '1', 'admin', 'Saving user'),
(41, 1468499373, 1, 'admin', 75, '-', '-', 'User/ role management'),
(42, 1468499375, 1, 'admin', 27, '6', 'Контактная информация', 'Editing resource'),
(43, 1468499378, 1, 'admin', 76, '-', '-', 'Element management'),
(44, 1468499379, 1, 'admin', 16, '3', 'Minimal Template', 'Editing template'),
(45, 1468499408, 1, 'admin', 20, '3', 'Обычная страница', 'Saving template'),
(46, 1468499408, 1, 'admin', 76, '-', '-', 'Element management'),
(47, 1468499433, 1, 'admin', 27, '2', 'Доставка и оплата', 'Editing resource'),
(48, 1468499436, 1, 'admin', 4, '-', 'Новый ресурс', 'Creating a resource'),
(49, 1468499445, 1, 'admin', 5, '-', 'Каталог', 'Saving resource'),
(50, 1468499446, 1, 'admin', 3, '7', 'Каталог', 'Viewing data for resource'),
(51, 1468499458, 1, 'admin', 76, '-', '-', 'Element management'),
(52, 1468499538, 1, 'admin', 102, '8', 'TransAlias', 'Edit plugin'),
(53, 1468499568, 1, 'admin', 103, '8', 'TransAlias', 'Saving plugin'),
(54, 1468499568, 1, 'admin', 76, '-', '-', 'Element management'),
(55, 1468499578, 1, 'admin', 101, '-', 'Новый плагин', 'Create new plugin'),
(56, 1468499612, 1, 'admin', 103, '-', 'Untitled plugin', 'Saving plugin'),
(57, 1468499612, 1, 'admin', 76, '-', '-', 'Element management'),
(58, 1468499622, 1, 'admin', 102, '9', 'Untitled plugin', 'Edit plugin'),
(59, 1468499646, 1, 'admin', 103, '9', 'REDIRECT', 'Saving plugin'),
(60, 1468499646, 1, 'admin', 76, '-', '-', 'Element management'),
(61, 1468499653, 1, 'admin', 17, '-', '-', 'Editing settings'),
(62, 1468499691, 1, 'admin', 76, '-', '-', 'Element management'),
(63, 1468499694, 1, 'admin', 76, '-', '-', 'Element management'),
(64, 1468499695, 1, 'admin', 16, '3', 'Обычная страница', 'Editing template'),
(65, 1468499701, 1, 'admin', 20, '3', 'Обычная страница', 'Saving template'),
(66, 1468499701, 1, 'admin', 76, '-', '-', 'Element management'),
(67, 1468499703, 1, 'admin', 23, '-', 'Новый сниппет', 'Creating a new Snippet'),
(68, 1468499711, 1, 'admin', 24, '-', 'sdfs', 'Saving Snippet'),
(69, 1468499712, 1, 'admin', 76, '-', '-', 'Element management'),
(70, 1468499772, 1, 'admin', 102, '9', 'REDIRECT', 'Edit plugin'),
(71, 1468499779, 1, 'admin', 103, '9', 'REDIRECT', 'Saving plugin'),
(72, 1468499779, 1, 'admin', 102, '9', 'REDIRECT', 'Edit plugin'),
(73, 1468499907, 1, 'admin', 103, '9', 'REDIRECT', 'Saving plugin'),
(74, 1468499907, 1, 'admin', 102, '9', 'REDIRECT', 'Edit plugin'),
(75, 1468499921, 1, 'admin', 103, '9', 'REDIRECT', 'Saving plugin'),
(76, 1468499921, 1, 'admin', 102, '9', 'REDIRECT', 'Edit plugin'),
(77, 1468499928, 1, 'admin', 103, '9', 'REDIRECT', 'Saving plugin'),
(78, 1468499928, 1, 'admin', 102, '9', 'REDIRECT', 'Edit plugin'),
(79, 1468499949, 1, 'admin', 103, '9', 'REDIRECT', 'Saving plugin'),
(80, 1468499949, 1, 'admin', 102, '9', 'REDIRECT', 'Edit plugin'),
(81, 1468499983, 1, 'admin', 103, '9', 'REDIRECT', 'Saving plugin'),
(82, 1468499983, 1, 'admin', 102, '9', 'REDIRECT', 'Edit plugin'),
(83, 1468499994, 1, 'admin', 103, '9', 'REDIRECT', 'Saving plugin'),
(84, 1468499994, 1, 'admin', 102, '9', 'REDIRECT', 'Edit plugin'),
(85, 1468499996, 1, 'admin', 102, '9', 'REDIRECT', 'Edit plugin'),
(86, 1468499998, 1, 'admin', 76, '-', '-', 'Element management'),
(87, 1468499999, 1, 'admin', 16, '3', 'Обычная страница', 'Editing template'),
(88, 1468500002, 1, 'admin', 20, '3', 'Обычная страница', 'Saving template'),
(89, 1468500002, 1, 'admin', 76, '-', '-', 'Element management'),
(90, 1468500021, 1, 'admin', 103, '9', 'REDIRECT', 'Saving plugin'),
(91, 1468500021, 1, 'admin', 102, '9', 'REDIRECT', 'Edit plugin'),
(92, 1468500101, 1, 'admin', 103, '9', 'REDIRECT', 'Saving plugin'),
(93, 1468500101, 1, 'admin', 102, '9', 'REDIRECT', 'Edit plugin'),
(94, 1468500115, 1, 'admin', 103, '9', 'REDIRECT', 'Saving plugin'),
(95, 1468500115, 1, 'admin', 102, '9', 'REDIRECT', 'Edit plugin'),
(96, 1468500124, 1, 'admin', 76, '-', '-', 'Element management'),
(97, 1468500139, 1, 'admin', 101, '-', 'Новый плагин', 'Create new plugin'),
(98, 1468500157, 1, 'admin', 103, '-', 'BaseAndCanonical', 'Saving plugin'),
(99, 1468500157, 1, 'admin', 101, '-', 'Новый плагин', 'Create new plugin'),
(100, 1468500226, 1, 'admin', 103, '-', 'Antideer4', 'Saving plugin'),
(101, 1468500226, 1, 'admin', 101, '-', 'Новый плагин', 'Create new plugin'),
(102, 1468501107, 1, 'admin', 31, '-', '-', 'Using file manager'),
(103, 1468501108, 1, 'admin', 76, '-', '-', 'Element management'),
(104, 1468501109, 1, 'admin', 106, '-', '-', 'Viewing Modules'),
(105, 1468501111, 1, 'admin', 107, '-', 'Новый модуль', 'Create new module'),
(106, 1468501125, 1, 'admin', 109, '-', 'Страница Контакты', 'Saving module'),
(107, 1468501125, 1, 'admin', 106, '-', '-', 'Viewing Modules'),
(108, 1468501181, 1, 'admin', 76, '-', '-', 'Element management'),
(109, 1468501183, 1, 'admin', 23, '-', 'Новый сниппет', 'Creating a new Snippet'),
(110, 1468501321, 1, 'admin', 24, '-', 'PageContacts', 'Saving Snippet'),
(111, 1468501321, 1, 'admin', 22, '20', 'PageContacts', 'Editing Snippet'),
(112, 1468501334, 1, 'admin', 27, '6', 'Контактная информация', 'Editing resource'),
(113, 1468501340, 1, 'admin', 5, '6', 'Контактная информация', 'Saving resource'),
(114, 1468501342, 1, 'admin', 3, '6', 'Контактная информация', 'Viewing data for resource'),
(115, 1468501364, 1, 'admin', 112, '3', 'Страница Контакты', 'Execute module'),
(116, 1468501367, 1, 'admin', 112, '3', 'Страница Контакты', 'Execute module'),
(117, 1468501368, 1, 'admin', 112, '3', 'Страница Контакты', 'Execute module'),
(118, 1468501369, 1, 'admin', 112, '3', 'Страница Контакты', 'Execute module'),
(119, 1468501376, 1, 'admin', 112, '3', 'Страница Контакты', 'Execute module'),
(120, 1468501387, 1, 'admin', 70, '-', '-', 'Viewing site schedule'),
(121, 1468501388, 1, 'admin', 93, '-', '-', 'Backup Manager'),
(122, 1468501449, 1, 'admin', 93, '-', '-', 'Backup Manager'),
(123, 1468501489, 1, 'admin', 76, '-', '-', 'Element management'),
(124, 1468501491, 1, 'admin', 114, '-', '-', 'View event log'),
(125, 1468501491, 1, 'admin', 70, '-', '-', 'Viewing site schedule'),
(126, 1468501492, 1, 'admin', 53, '-', '-', 'Viewing system info'),
(127, 1468501829, 1, 'admin', 76, '-', '-', 'Element management'),
(128, 1468501832, 1, 'admin', 102, '11', 'Antideer4', 'Edit plugin'),
(129, 1468501838, 1, 'admin', 27, '1', 'Главная', 'Editing resource'),
(130, 1468501839, 1, 'admin', 5, '1', 'Главная', 'Saving resource'),
(131, 1468501840, 1, 'admin', 3, '1', 'Главная', 'Viewing data for resource'),
(132, 1468501841, 1, 'admin', 53, '-', '-', 'Viewing system info'),
(133, 1468501853, 1, 'admin', 76, '-', '-', 'Element management'),
(134, 1468501857, 1, 'admin', 31, '-', '-', 'Using file manager'),
(135, 1468501859, 1, 'admin', 31, '-', '-', 'Using file manager'),
(136, 1468501860, 1, 'admin', 31, '-', '-', 'Using file manager'),
(137, 1468501862, 1, 'admin', 31, '-', '/home/u383720/masterstroy-rnd.ru/www/_new/manager/includes/config.inc.php', 'Viewing File'),
(138, 1468501921, 1, 'admin', 53, '-', '-', 'Viewing system info'),
(139, 1468501926, 1, 'admin', 27, '1', 'Главная', 'Editing resource'),
(140, 1468501927, 1, 'admin', 5, '1', 'Главная', 'Saving resource'),
(141, 1468501928, 1, 'admin', 53, '-', '-', 'Viewing system info'),
(142, 1468501929, 1, 'admin', 53, '-', '-', 'Viewing system info'),
(143, 1468501942, 1, 'admin', 26, '-', '-', 'Refreshing site'),
(144, 1468501989, 1, 'admin', 26, '-', '-', 'Refreshing site'),
(145, 1468502044, 1, 'admin', 112, '3', 'Страница Контакты', 'Execute module'),
(146, 1468502045, 1, 'admin', 112, '3', 'Страница Контакты', 'Execute module'),
(147, 1468502046, 1, 'admin', 112, '3', 'Страница Контакты', 'Execute module'),
(148, 1468502060, 1, 'admin', 31, '-', '/home/u383720/masterstroy-rnd.ru/www/_new/manager/includes/config.inc.php', 'Viewing File'),
(149, 1468502062, 1, 'admin', 31, '-', '/home/u383720/masterstroy-rnd.ru/www/_new/manager/includes/config.inc.php', 'Viewing File'),
(150, 1468502159, 1, 'admin', 112, '3', 'Страница Контакты', 'Execute module'),
(151, 1468502160, 1, 'admin', 112, '3', 'Страница Контакты', 'Execute module'),
(152, 1468502162, 1, 'admin', 112, '3', 'Страница Контакты', 'Execute module'),
(153, 1468502233, 1, 'admin', 112, '3', 'Страница Контакты', 'Execute module'),
(154, 1468502242, 1, 'admin', 112, '3', 'Страница Контакты', 'Execute module'),
(155, 1468502243, 1, 'admin', 112, '3', 'Страница Контакты', 'Execute module'),
(156, 1468502245, 1, 'admin', 112, '3', 'Страница Контакты', 'Execute module'),
(157, 1468502247, 1, 'admin', 112, '3', 'Страница Контакты', 'Execute module'),
(158, 1468502248, 1, 'admin', 112, '3', 'Страница Контакты', 'Execute module'),
(159, 1468502386, 1, 'admin', 112, '3', 'Страница Контакты', 'Execute module'),
(160, 1468502497, 1, 'admin', 112, '3', 'Страница Контакты', 'Execute module'),
(161, 1468502503, 1, 'admin', 26, '-', '-', 'Refreshing site'),
(162, 1468502506, 1, 'admin', 27, '5', 'Написать нам', 'Editing resource'),
(163, 1468502507, 1, 'admin', 76, '-', '-', 'Element management'),
(164, 1468502654, 1, 'admin', 76, '-', '-', 'Element management'),
(165, 1468502655, 1, 'admin', 23, '-', 'Новый сниппет', 'Creating a new Snippet'),
(166, 1468502689, 1, 'admin', 24, '-', 'SuperPuperForms', 'Saving Snippet'),
(167, 1468502689, 1, 'admin', 76, '-', '-', 'Element management'),
(168, 1468502691, 1, 'admin', 27, '5', 'Написать нам', 'Editing resource'),
(169, 1468502699, 1, 'admin', 22, '21', 'SuperPuperForms', 'Editing Snippet'),
(170, 1468502713, 1, 'admin', 5, '5', 'Написать нам', 'Saving resource'),
(171, 1468502713, 1, 'admin', 27, '5', 'Написать нам', 'Editing resource'),
(172, 1468502766, 1, 'admin', 24, '21', 'SuperPuperForms', 'Saving Snippet'),
(173, 1468502766, 1, 'admin', 76, '-', '-', 'Element management'),
(174, 1468502779, 1, 'admin', 22, '21', 'SuperPuperForms', 'Editing Snippet'),
(175, 1468502796, 1, 'admin', 24, '21', 'SuperPuperForms', 'Saving Snippet'),
(176, 1468502796, 1, 'admin', 22, '21', 'SuperPuperForms', 'Editing Snippet'),
(177, 1468502861, 1, 'admin', 24, '21', 'SuperPuperForms', 'Saving Snippet'),
(178, 1468502861, 1, 'admin', 22, '21', 'SuperPuperForms', 'Editing Snippet'),
(179, 1468503014, 1, 'admin', 27, '2', 'Доставка и оплата', 'Editing resource'),
(180, 1468503017, 1, 'admin', 5, '2', 'Доставка и оплата', 'Saving resource'),
(181, 1468503018, 1, 'admin', 3, '2', 'Доставка и оплата', 'Viewing data for resource'),
(182, 1468503095, 1, 'admin', 76, '-', '-', 'Element management'),
(183, 1468503096, 1, 'admin', 23, '-', 'Новый сниппет', 'Creating a new Snippet'),
(184, 1468503107, 1, 'admin', 24, '-', 'Compress', 'Saving Snippet'),
(185, 1468503107, 1, 'admin', 23, '-', 'Новый сниппет', 'Creating a new Snippet'),
(186, 1468503121, 1, 'admin', 24, '-', 'GenerAlias', 'Saving Snippet'),
(187, 1468503121, 1, 'admin', 23, '-', 'Новый сниппет', 'Creating a new Snippet'),
(188, 1468503159, 1, 'admin', 24, '-', 'GetDoc61', 'Saving Snippet'),
(189, 1468503159, 1, 'admin', 23, '-', 'Новый сниппет', 'Creating a new Snippet'),
(190, 1468503170, 1, 'admin', 24, '-', 'GetIdOnLvl', 'Saving Snippet'),
(191, 1468503170, 1, 'admin', 23, '-', 'Новый сниппет', 'Creating a new Snippet'),
(192, 1468503183, 1, 'admin', 24, '-', 'GetLvl', 'Saving Snippet'),
(193, 1468503183, 1, 'admin', 23, '-', 'Новый сниппет', 'Creating a new Snippet'),
(194, 1468503226, 1, 'admin', 24, '-', 'ImgCrop71', 'Saving Snippet'),
(195, 1468503226, 1, 'admin', 23, '-', 'Новый сниппет', 'Creating a new Snippet'),
(196, 1468504551, 1, 'admin', 76, '-', '-', 'Element management'),
(197, 1468504552, 1, 'admin', 300, '-', 'Новый параметр (TV)', 'Create Template Variable'),
(198, 1468564050, 1, 'admin', 58, '-', 'MODX', 'Logged in'),
(199, 1468564052, 1, 'admin', 26, '-', '-', 'Refreshing site'),
(200, 1468564059, 1, 'admin', 26, '-', '-', 'Refreshing site'),
(201, 1468564665, 1, 'admin', 76, '-', '-', 'Element management'),
(202, 1468564667, 1, 'admin', 76, '-', '-', 'Element management'),
(203, 1468564668, 1, 'admin', 76, '-', '-', 'Element management'),
(204, 1468564672, 1, 'admin', 16, '3', 'Обычная страница', 'Editing template'),
(205, 1468564674, 1, 'admin', 77, '-', 'Новый чанк', 'Creating a new Chunk (HTML Snippet)'),
(206, 1468564775, 1, 'admin', 79, '-', 'Untitled chunk', 'Saving Chunk (HTML Snippet)'),
(207, 1468564775, 1, 'admin', 76, '-', '-', 'Element management'),
(208, 1468564776, 1, 'admin', 78, '2', 'Untitled chunk', 'Editing Chunk (HTML Snippet)'),
(209, 1468564789, 1, 'admin', 79, '2', 'Untitled chunk', 'Saving Chunk (HTML Snippet)'),
(210, 1468564789, 1, 'admin', 78, '2', 'Untitled chunk', 'Editing Chunk (HTML Snippet)'),
(211, 1468564797, 1, 'admin', 79, '2', 'HEAD', 'Saving Chunk (HTML Snippet)'),
(212, 1468564797, 1, 'admin', 78, '2', 'HEAD', 'Editing Chunk (HTML Snippet)'),
(213, 1468564804, 1, 'admin', 20, '3', 'Обычная страница', 'Saving template'),
(214, 1468564804, 1, 'admin', 16, '3', 'Обычная страница', 'Editing template'),
(215, 1468564843, 1, 'admin', 76, '-', '-', 'Element management'),
(216, 1468564845, 1, 'admin', 300, '-', 'Новый параметр (TV)', 'Create Template Variable'),
(217, 1468564889, 1, 'admin', 302, '-', '[admin] SEO Title', 'Save Template Variable'),
(218, 1468564889, 1, 'admin', 300, '-', 'Новый параметр (TV)', 'Create Template Variable'),
(219, 1468564910, 1, 'admin', 302, '-', '[admin] SEO Description', 'Save Template Variable'),
(220, 1468564911, 1, 'admin', 300, '-', 'Новый параметр (TV)', 'Create Template Variable'),
(221, 1468564912, 1, 'admin', 75, '-', '-', 'User/ role management'),
(222, 1468564913, 1, 'admin', 11, '-', 'Новый пользователь', 'Creating a user'),
(223, 1468564965, 1, 'admin', 11, '-', 'Новый пользователь', 'Creating a user'),
(224, 1468564991, 1, 'admin', 32, '-', 'administrator', 'Saving user'),
(225, 1468564993, 1, 'admin', 99, '-', '-', 'Manage Web Users'),
(226, 1468564994, 1, 'admin', 86, '-', '-', 'Role management'),
(227, 1468564995, 1, 'admin', 35, '2', 'Editor', 'Editing role'),
(228, 1468565018, 1, 'admin', 36, '2', 'Editor', 'Saving role'),
(229, 1468565018, 1, 'admin', 86, '-', '-', 'Role management'),
(230, 1468565020, 1, 'admin', 86, '-', '-', 'Role management'),
(231, 1468565022, 1, 'admin', 40, '-', '-', 'Editing Access Permissions'),
(232, 1468565026, 1, 'admin', 41, '-', '-', 'Editing Access Permissions'),
(233, 1468565026, 1, 'admin', 40, '-', '-', 'Editing Access Permissions'),
(234, 1468565029, 1, 'admin', 41, '-', '-', 'Editing Access Permissions'),
(235, 1468565029, 1, 'admin', 40, '-', '-', 'Editing Access Permissions'),
(236, 1468565032, 1, 'admin', 41, '-', '-', 'Editing Access Permissions'),
(237, 1468565032, 1, 'admin', 40, '-', '-', 'Editing Access Permissions'),
(238, 1468565035, 1, 'admin', 41, '-', '-', 'Editing Access Permissions'),
(239, 1468565035, 1, 'admin', 40, '-', '-', 'Editing Access Permissions'),
(240, 1468565036, 1, 'admin', 41, '-', '-', 'Editing Access Permissions'),
(241, 1468565036, 1, 'admin', 40, '-', '-', 'Editing Access Permissions'),
(242, 1468565039, 1, 'admin', 41, '-', '-', 'Editing Access Permissions'),
(243, 1468565039, 1, 'admin', 40, '-', '-', 'Editing Access Permissions'),
(244, 1468565042, 1, 'admin', 75, '-', '-', 'User/ role management'),
(245, 1468565043, 1, 'admin', 12, '1', 'admin', 'Editing user'),
(246, 1468565045, 1, 'admin', 75, '-', '-', 'User/ role management'),
(247, 1468565046, 1, 'admin', 12, '2', 'administrator', 'Editing user'),
(248, 1468565058, 1, 'admin', 32, '2', 'administrator', 'Saving user'),
(249, 1468565058, 1, 'admin', 75, '-', '-', 'User/ role management'),
(250, 1468565061, 1, 'admin', 12, '2', 'administrator', 'Editing user'),
(251, 1468565063, 1, 'admin', 76, '-', '-', 'Element management'),
(252, 1468565079, 1, 'admin', 300, '-', 'Новый параметр (TV)', 'Create Template Variable'),
(253, 1468565100, 1, 'admin', 302, '-', '[admin] SEO Keywords', 'Save Template Variable'),
(254, 1468565100, 1, 'admin', 76, '-', '-', 'Element management'),
(255, 1468565101, 1, 'admin', 301, '2', '[admin] SEO Description', 'Edit Template Variable'),
(256, 1468565103, 1, 'admin', 76, '-', '-', 'Element management'),
(257, 1468565104, 1, 'admin', 301, '3', '[admin] SEO Keywords', 'Edit Template Variable'),
(258, 1468565119, 1, 'admin', 302, '3', '[admin] SEO Keywords', 'Save Template Variable'),
(259, 1468565119, 1, 'admin', 300, '-', 'Новый параметр (TV)', 'Create Template Variable'),
(260, 1468565145, 1, 'admin', 302, '-', '[admin] SEO - H1', 'Save Template Variable'),
(261, 1468565145, 1, 'admin', 300, '-', 'Новый параметр (TV)', 'Create Template Variable'),
(262, 1468565534, 1, 'admin', 79, '2', 'HEAD', 'Saving Chunk (HTML Snippet)'),
(263, 1468565534, 1, 'admin', 78, '2', 'HEAD', 'Editing Chunk (HTML Snippet)'),
(264, 1468565554, 1, 'admin', 79, '2', 'HEAD', 'Saving Chunk (HTML Snippet)'),
(265, 1468565554, 1, 'admin', 78, '2', 'HEAD', 'Editing Chunk (HTML Snippet)'),
(266, 1468565670, 1, 'admin', 79, '2', 'HEAD', 'Saving Chunk (HTML Snippet)'),
(267, 1468565670, 1, 'admin', 78, '2', 'HEAD', 'Editing Chunk (HTML Snippet)'),
(268, 1468565870, 1, 'admin', 79, '2', 'HEAD', 'Saving Chunk (HTML Snippet)'),
(269, 1468565870, 1, 'admin', 78, '2', 'HEAD', 'Editing Chunk (HTML Snippet)'),
(270, 1468565871, 1, 'admin', 78, '2', 'HEAD', 'Editing Chunk (HTML Snippet)'),
(271, 1468565872, 1, 'admin', 76, '-', '-', 'Element management'),
(272, 1468565874, 1, 'admin', 77, '-', 'Новый чанк', 'Creating a new Chunk (HTML Snippet)'),
(273, 1468565880, 1, 'admin', 79, '-', 'GoogleAnalytics', 'Saving Chunk (HTML Snippet)'),
(274, 1468565880, 1, 'admin', 76, '-', '-', 'Element management'),
(275, 1468565929, 1, 'admin', 79, '2', 'HEAD', 'Saving Chunk (HTML Snippet)'),
(276, 1468565929, 1, 'admin', 78, '2', 'HEAD', 'Editing Chunk (HTML Snippet)'),
(277, 1468566162, 1, 'admin', 78, '2', 'HEAD', 'Editing Chunk (HTML Snippet)'),
(278, 1468566170, 1, 'admin', 76, '-', '-', 'Element management'),
(279, 1468566171, 1, 'admin', 77, '-', 'Новый чанк', 'Creating a new Chunk (HTML Snippet)'),
(280, 1468566423, 1, 'admin', 79, '-', 'FOOTER', 'Saving Chunk (HTML Snippet)'),
(281, 1468566423, 1, 'admin', 78, '4', 'FOOTER', 'Editing Chunk (HTML Snippet)'),
(282, 1468566425, 1, 'admin', 76, '-', '-', 'Element management'),
(283, 1468566427, 1, 'admin', 77, '-', 'Новый чанк', 'Creating a new Chunk (HTML Snippet)'),
(284, 1468566436, 1, 'admin', 79, '-', 'COUNTER', 'Saving Chunk (HTML Snippet)'),
(285, 1468566436, 1, 'admin', 76, '-', '-', 'Element management'),
(286, 1468566437, 1, 'admin', 79, '4', 'FOOTER', 'Saving Chunk (HTML Snippet)'),
(287, 1468566437, 1, 'admin', 78, '4', 'FOOTER', 'Editing Chunk (HTML Snippet)'),
(288, 1468566443, 1, 'admin', 76, '-', '-', 'Element management'),
(289, 1468566444, 1, 'admin', 16, '3', 'Обычная страница', 'Editing template'),
(290, 1468566449, 1, 'admin', 20, '3', 'Обычная страница', 'Saving template'),
(291, 1468566449, 1, 'admin', 76, '-', '-', 'Element management'),
(292, 1468566663, 1, 'admin', 79, '4', 'FOOTER', 'Saving Chunk (HTML Snippet)'),
(293, 1468566663, 1, 'admin', 78, '4', 'FOOTER', 'Editing Chunk (HTML Snippet)'),
(294, 1468566672, 1, 'admin', 79, '4', 'FOOTER', 'Saving Chunk (HTML Snippet)'),
(295, 1468566672, 1, 'admin', 78, '4', 'FOOTER', 'Editing Chunk (HTML Snippet)'),
(296, 1468566743, 1, 'admin', 23, '-', 'Новый сниппет', 'Creating a new Snippet'),
(297, 1468566749, 1, 'admin', 24, '-', 'Date', 'Saving Snippet'),
(298, 1468566749, 1, 'admin', 76, '-', '-', 'Element management'),
(299, 1468566832, 1, 'admin', 79, '4', 'FOOTER', 'Saving Chunk (HTML Snippet)'),
(300, 1468566832, 1, 'admin', 78, '4', 'FOOTER', 'Editing Chunk (HTML Snippet)'),
(301, 1468566847, 1, 'admin', 16, '3', 'Обычная страница', 'Editing template'),
(302, 1468566857, 1, 'admin', 76, '-', '-', 'Element management'),
(303, 1468566872, 1, 'admin', 300, '-', 'Новый параметр (TV)', 'Create Template Variable'),
(304, 1468566891, 1, 'admin', 302, '-', 'Изображение', 'Save Template Variable'),
(305, 1468566891, 1, 'admin', 76, '-', '-', 'Element management'),
(306, 1468566901, 1, 'admin', 300, '-', 'Новый параметр (TV)', 'Create Template Variable'),
(307, 1468566914, 1, 'admin', 302, '-', 'Дата', 'Save Template Variable'),
(308, 1468566915, 1, 'admin', 76, '-', '-', 'Element management'),
(309, 1468566921, 1, 'admin', 300, '-', 'Новый параметр (TV)', 'Create Template Variable'),
(310, 1468566944, 1, 'admin', 302, '-', '[admin] До контента', 'Save Template Variable'),
(311, 1468566944, 1, 'admin', 76, '-', '-', 'Element management'),
(312, 1468566950, 1, 'admin', 300, '-', 'Новый параметр (TV)', 'Create Template Variable'),
(313, 1468566960, 1, 'admin', 302, '-', '[admin] До контента', 'Save Template Variable'),
(314, 1468566960, 1, 'admin', 76, '-', '-', 'Element management'),
(315, 1468566967, 1, 'admin', 300, '-', 'Новый параметр (TV)', 'Create Template Variable'),
(316, 1468566985, 1, 'admin', 302, '-', 'Цена, руб.', 'Save Template Variable'),
(317, 1468566985, 1, 'admin', 76, '-', '-', 'Element management'),
(318, 1468566987, 1, 'admin', 16, '3', 'Обычная страница', 'Editing template'),
(319, 1468566990, 1, 'admin', 96, '3', 'Duplicate of Обычная страница', 'Duplicate Template'),
(320, 1468566990, 1, 'admin', 16, '4', 'Duplicate of Обычная страница', 'Editing template'),
(321, 1468566998, 1, 'admin', 20, '4', 'Каталог', 'Saving template'),
(322, 1468566998, 1, 'admin', 76, '-', '-', 'Element management'),
(323, 1468567002, 1, 'admin', 301, '9', 'Цена, руб.', 'Edit Template Variable'),
(324, 1468567005, 1, 'admin', 302, '9', 'Цена, руб.', 'Save Template Variable'),
(325, 1468567005, 1, 'admin', 76, '-', '-', 'Element management'),
(326, 1468567015, 1, 'admin', 300, '-', 'Новый параметр (TV)', 'Create Template Variable'),
(327, 1468567063, 1, 'admin', 302, '-', 'Бирка', 'Save Template Variable'),
(328, 1468567063, 1, 'admin', 76, '-', '-', 'Element management'),
(329, 1468567073, 1, 'admin', 78, '1', 'mm_rules', 'Editing Chunk (HTML Snippet)'),
(330, 1468567074, 1, 'admin', 79, '1', 'mm_rules', 'Saving Chunk (HTML Snippet)'),
(331, 1468567074, 1, 'admin', 76, '-', '-', 'Element management'),
(332, 1468567103, 1, 'admin', 77, '-', 'Новый чанк', 'Creating a new Chunk (HTML Snippet)'),
(333, 1468567116, 1, 'admin', 79, '-', 'CONTENT_1', 'Saving Chunk (HTML Snippet)'),
(334, 1468567116, 1, 'admin', 77, '-', 'Новый чанк', 'Creating a new Chunk (HTML Snippet)'),
(335, 1468567126, 1, 'admin', 79, '-', 'CONTENT_2', 'Saving Chunk (HTML Snippet)'),
(336, 1468567126, 1, 'admin', 77, '-', 'Новый чанк', 'Creating a new Chunk (HTML Snippet)'),
(337, 1468567144, 1, 'admin', 79, '-', 'socseti', 'Saving Chunk (HTML Snippet)'),
(338, 1468567144, 1, 'admin', 77, '-', 'Новый чанк', 'Creating a new Chunk (HTML Snippet)'),
(339, 1468567171, 1, 'admin', 76, '-', '-', 'Element management'),
(340, 1468567173, 1, 'admin', 300, '-', 'Новый параметр (TV)', 'Create Template Variable'),
(341, 1468567234, 1, 'admin', 302, '-', 'Единица измерения', 'Save Template Variable'),
(342, 1468567234, 1, 'admin', 76, '-', '-', 'Element management'),
(343, 1468567262, 1, 'admin', 101, '-', 'Новый плагин', 'Create new plugin'),
(344, 1468567306, 1, 'admin', 103, '-', 'Highslide', 'Saving plugin'),
(345, 1468567306, 1, 'admin', 76, '-', '-', 'Element management'),
(346, 1468567312, 1, 'admin', 102, '12', 'Highslide', 'Edit plugin'),
(347, 1468567316, 1, 'admin', 103, '12', 'Highslide', 'Saving plugin'),
(348, 1468567316, 1, 'admin', 76, '-', '-', 'Element management'),
(349, 1468567336, 1, 'admin', 16, '3', 'Обычная страница', 'Editing template'),
(350, 1468567339, 1, 'admin', 96, '3', 'Duplicate of Обычная страница', 'Duplicate Template'),
(351, 1468567339, 1, 'admin', 16, '5', 'Duplicate of Обычная страница', 'Editing template'),
(352, 1468567350, 1, 'admin', 20, '5', 'Главная страница', 'Saving template'),
(353, 1468567350, 1, 'admin', 76, '-', '-', 'Element management'),
(354, 1468572205, 1, 'admin', 23, '-', 'Новый сниппет', 'Creating a new Snippet'),
(355, 1468572212, 1, 'admin', 24, '-', 'WayfinderScorn', 'Saving Snippet'),
(356, 1468572212, 1, 'admin', 76, '-', '-', 'Element management'),
(357, 1468572304, 1, 'admin', 106, '-', '-', 'Viewing Modules'),
(358, 1468572306, 1, 'admin', 107, '-', 'Новый модуль', 'Create new module'),
(359, 1468572312, 1, 'admin', 109, '-', 'З А К А З Ы', 'Saving module'),
(360, 1468572312, 1, 'admin', 106, '-', '-', 'Viewing Modules'),
(361, 1468572320, 1, 'admin', 106, '-', '-', 'Viewing Modules'),
(362, 1468572321, 1, 'admin', 107, '-', 'Новый модуль', 'Create new module'),
(363, 1468572327, 1, 'admin', 109, '-', 'Изменение цен', 'Saving module'),
(364, 1468572327, 1, 'admin', 106, '-', '-', 'Viewing Modules'),
(365, 1468572347, 1, 'admin', 107, '-', 'Новый модуль', 'Create new module'),
(366, 1468572357, 1, 'admin', 109, '-', 'Импорт из MODx', 'Saving module'),
(367, 1468572357, 1, 'admin', 107, '-', 'Новый модуль', 'Create new module'),
(368, 1468572371, 1, 'admin', 109, '-', 'ПОКУПАТЕЛИ', 'Saving module'),
(369, 1468572371, 1, 'admin', 107, '-', 'Новый модуль', 'Create new module'),
(370, 1468572376, 1, 'admin', 112, '3', 'Страница Контакты', 'Execute module'),
(371, 1468572379, 1, 'admin', 112, '7', 'ПОКУПАТЕЛИ', 'Execute module'),
(372, 1468572381, 1, 'admin', 112, '3', 'Страница Контакты', 'Execute module'),
(373, 1468572397, 1, 'admin', 4, '-', 'Новый ресурс', 'Creating a resource'),
(374, 1468572405, 1, 'admin', 4, '-', 'Новый ресурс', 'Creating a resource'),
(375, 1468572420, 1, 'admin', 5, '-', 'Технические страницы', 'Saving resource'),
(376, 1468572421, 1, 'admin', 3, '8', 'Технические страницы', 'Viewing data for resource'),
(377, 1468572424, 1, 'admin', 27, '8', 'Технические страницы', 'Editing resource'),
(378, 1468572425, 1, 'admin', 27, '8', 'Технические страницы', 'Editing resource'),
(379, 1468572426, 1, 'admin', 4, '-', 'Новый ресурс', 'Creating a resource'),
(380, 1468572437, 1, 'admin', 4, '-', 'Новый ресурс', 'Creating a resource'),
(381, 1468572442, 1, 'admin', 5, '-', 'Страница не найдена', 'Saving resource'),
(382, 1468572442, 1, 'admin', 4, '-', 'Новый ресурс', 'Creating a resource'),
(383, 1468572454, 1, 'admin', 4, '-', 'Новый ресурс', 'Creating a resource'),
(384, 1468572458, 1, 'admin', 5, '-', 'Страница не доступна', 'Saving resource'),
(385, 1468572458, 1, 'admin', 4, '-', 'Новый ресурс', 'Creating a resource'),
(386, 1468572470, 1, 'admin', 4, '-', 'Новый ресурс', 'Creating a resource'),
(387, 1468572481, 1, 'admin', 5, '-', 'Магазин', 'Saving resource'),
(388, 1468572481, 1, 'admin', 4, '-', 'Новый ресурс', 'Creating a resource'),
(389, 1468572484, 1, 'admin', 4, '-', 'Новый ресурс', 'Creating a resource'),
(390, 1468572508, 1, 'admin', 5, '-', 'Моя корзина', 'Saving resource'),
(391, 1468572509, 1, 'admin', 76, '-', '-', 'Element management'),
(392, 1468572510, 1, 'admin', 16, '3', 'Обычная страница', 'Editing template'),
(393, 1468572512, 1, 'admin', 96, '3', 'Duplicate of Обычная страница', 'Duplicate Template'),
(394, 1468572512, 1, 'admin', 16, '6', 'Duplicate of Обычная страница', 'Editing template'),
(395, 1468572525, 1, 'admin', 20, '6', 'Обычная страница (без левого меню)', 'Saving template'),
(396, 1468572525, 1, 'admin', 76, '-', '-', 'Element management'),
(397, 1468572527, 1, 'admin', 27, '12', 'Моя корзина', 'Editing resource'),
(398, 1468572531, 1, 'admin', 27, '12', 'Моя корзина', 'Editing resource'),
(399, 1468572532, 1, 'admin', 5, '12', 'Моя корзина', 'Saving resource'),
(400, 1468572533, 1, 'admin', 3, '12', 'Моя корзина', 'Viewing data for resource'),
(401, 1468572534, 1, 'admin', 17, '-', '-', 'Editing settings'),
(402, 1468572548, 1, 'admin', 30, '-', '-', 'Saving settings'),
(403, 1468572569, 1, 'admin', 4, '-', 'Новый ресурс', 'Creating a resource'),
(404, 1468572581, 1, 'admin', 4, '-', 'Новый ресурс', 'Creating a resource'),
(405, 1468572607, 1, 'admin', 4, '-', 'Новый ресурс', 'Creating a resource'),
(406, 1468572609, 1, 'admin', 5, '-', '____action', 'Saving resource'),
(407, 1468572612, 1, 'admin', 3, '13', '____action', 'Viewing data for resource'),
(408, 1468572613, 1, 'admin', 4, '-', 'Новый ресурс', 'Creating a resource'),
(409, 1468572624, 1, 'admin', 5, '-', 'AJAX', 'Saving resource'),
(410, 1468572625, 1, 'admin', 3, '14', 'AJAX', 'Viewing data for resource'),
(411, 1468572635, 1, 'admin', 4, '-', 'Новый ресурс', 'Creating a resource'),
(412, 1468572646, 1, 'admin', 5, '-', 'Страницы', 'Saving resource'),
(413, 1468572647, 1, 'admin', 3, '15', 'Страницы', 'Viewing data for resource'),
(414, 1468572654, 1, 'admin', 4, '-', 'Новый ресурс', 'Creating a resource'),
(415, 1468572662, 1, 'admin', 5, '-', 'Результат поиска', 'Saving resource'),
(416, 1468572663, 1, 'admin', 3, '16', 'Результат поиска', 'Viewing data for resource'),
(417, 1468572665, 1, 'admin', 76, '-', '-', 'Element management'),
(418, 1468572667, 1, 'admin', 16, '5', 'Главная страница', 'Editing template'),
(419, 1468572669, 1, 'admin', 117, '5', '-', 'Editing tv rank'),
(420, 1468572680, 1, 'admin', 117, '5', '-', 'Editing tv rank'),
(421, 1468572680, 1, 'admin', 76, '-', '-', 'Element management'),
(422, 1468572682, 1, 'admin', 16, '4', 'Каталог', 'Editing template'),
(423, 1468572683, 1, 'admin', 117, '4', '-', 'Editing tv rank'),
(424, 1468572708, 1, 'admin', 117, '4', '-', 'Editing tv rank'),
(425, 1468572709, 1, 'admin', 76, '-', '-', 'Element management'),
(426, 1468572710, 1, 'admin', 16, '3', 'Обычная страница', 'Editing template'),
(427, 1468572711, 1, 'admin', 117, '3', '-', 'Editing tv rank'),
(428, 1468572721, 1, 'admin', 117, '3', '-', 'Editing tv rank'),
(429, 1468572721, 1, 'admin', 76, '-', '-', 'Element management'),
(430, 1468572722, 1, 'admin', 16, '6', 'Обычная страница (без левого меню)', 'Editing template'),
(431, 1468572723, 1, 'admin', 117, '6', '-', 'Editing tv rank'),
(432, 1468572733, 1, 'admin', 117, '6', '-', 'Editing tv rank'),
(433, 1468572733, 1, 'admin', 27, '8', 'Технические страницы', 'Editing resource'),
(434, 1468572734, 1, 'admin', 27, '15', 'Страницы', 'Editing resource'),
(435, 1468572748, 1, 'admin', 76, '-', '-', 'Element management'),
(436, 1468572752, 1, 'admin', 22, '19', 'sdfs', 'Editing Snippet'),
(437, 1468572755, 1, 'admin', 25, '19', 'sdfs', 'Deleting Snippet'),
(438, 1468572755, 1, 'admin', 76, '-', '-', 'Element management'),
(439, 1468572787, 1, 'admin', 23, '-', 'Новый сниппет', 'Creating a new Snippet'),
(440, 1468572794, 1, 'admin', 24, '-', 'YandexMap', 'Saving Snippet'),
(441, 1468572794, 1, 'admin', 76, '-', '-', 'Element management'),
(442, 1468572847, 1, 'admin', 23, '-', 'Новый сниппет', 'Creating a new Snippet'),
(443, 1468572864, 1, 'admin', 24, '-', 'AJAX', 'Saving Snippet'),
(444, 1468572864, 1, 'admin', 23, '-', 'Новый сниппет', 'Creating a new Snippet'),
(445, 1468572875, 1, 'admin', 24, '-', 'BasketAction', 'Saving Snippet'),
(446, 1468572875, 1, 'admin', 23, '-', 'Новый сниппет', 'Creating a new Snippet'),
(447, 1468572885, 1, 'admin', 24, '-', 'BasketOrder', 'Saving Snippet'),
(448, 1468572885, 1, 'admin', 23, '-', 'Новый сниппет', 'Creating a new Snippet'),
(449, 1468572895, 1, 'admin', 24, '-', 'BasketPage', 'Saving Snippet'),
(450, 1468572895, 1, 'admin', 23, '-', 'Новый сниппет', 'Creating a new Snippet'),
(451, 1468572907, 1, 'admin', 24, '-', 'BasketSumm', 'Saving Snippet'),
(452, 1468572907, 1, 'admin', 23, '-', 'Новый сниппет', 'Creating a new Snippet'),
(453, 1468572918, 1, 'admin', 24, '-', 'ParentsPagesTitles', 'Saving Snippet'),
(454, 1468572918, 1, 'admin', 23, '-', 'Новый сниппет', 'Creating a new Snippet'),
(455, 1468572926, 1, 'admin', 24, '-', 'TopBasket', 'Saving Snippet'),
(456, 1468572927, 1, 'admin', 23, '-', 'Новый сниппет', 'Creating a new Snippet'),
(457, 1468572948, 1, 'admin', 24, '-', 'Price', 'Saving Snippet'),
(458, 1468572948, 1, 'admin', 23, '-', 'Новый сниппет', 'Creating a new Snippet'),
(459, 1468572961, 1, 'admin', 24, '-', 'ParentsPublishedList', 'Saving Snippet'),
(460, 1468572961, 1, 'admin', 23, '-', 'Новый сниппет', 'Creating a new Snippet'),
(461, 1468572972, 1, 'admin', 24, '-', 'Pagination', 'Saving Snippet'),
(462, 1468572972, 1, 'admin', 23, '-', 'Новый сниппет', 'Creating a new Snippet'),
(463, 1468572983, 1, 'admin', 24, '-', 'CAT_ITEM', 'Saving Snippet'),
(464, 1468572983, 1, 'admin', 23, '-', 'Новый сниппет', 'Creating a new Snippet'),
(465, 1468572998, 1, 'admin', 24, '-', 'Catalog_Birka', 'Saving Snippet'),
(466, 1468572998, 1, 'admin', 23, '-', 'Новый сниппет', 'Creating a new Snippet'),
(467, 1468573011, 1, 'admin', 24, '-', 'CATALOG', 'Saving Snippet'),
(468, 1468573011, 1, 'admin', 23, '-', 'Новый сниппет', 'Creating a new Snippet'),
(469, 1468573014, 1, 'admin', 76, '-', '-', 'Element management'),
(470, 1468573016, 1, 'admin', 22, '43', 'CATALOG', 'Editing Snippet'),
(471, 1468573018, 1, 'admin', 76, '-', '-', 'Element management'),
(472, 1468573025, 1, 'admin', 76, '-', '-', 'Element management'),
(473, 1468573038, 1, 'admin', 53, '-', '-', 'Viewing system info'),
(474, 1468573042, 1, 'admin', 76, '-', '-', 'Element management'),
(475, 1468573058, 1, 'admin', 26, '-', '-', 'Refreshing site'),
(476, 1468666677, 1, 'admin', 58, '-', 'MODX', 'Logged in'),
(477, 1468666679, 1, 'admin', 26, '-', '-', 'Refreshing site'),
(478, 1468666710, 1, 'admin', 31, '-', '-', 'Using file manager'),
(479, 1468666711, 1, 'admin', 31, '-', '-', 'Using file manager'),
(480, 1468666712, 1, 'admin', 31, '-', '-', 'Using file manager'),
(481, 1468666716, 1, 'admin', 31, '-', '/home/u383720/masterstroy-rnd.ru/www/_new/manager/includes/config.inc.php', 'Viewing File');

-- --------------------------------------------------------

--
-- Структура таблицы `ms_manager_users`
--

CREATE TABLE IF NOT EXISTS `ms_manager_users` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `password` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 COMMENT='Contains login information for backend users.' AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `ms_manager_users`
--

INSERT INTO `ms_manager_users` (`id`, `username`, `password`) VALUES
(1, 'admin', 'md5>afc4bc2d87aab853efa7f9e2dcec0ea2d0ded539'),
(2, 'administrator', 'md5>b155b8a581aae325e35c3ebbb87f34e7b7e2288f');

-- --------------------------------------------------------

--
-- Структура таблицы `ms_membergroup_access`
--

CREATE TABLE IF NOT EXISTS `ms_membergroup_access` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `membergroup` int(10) NOT NULL DEFAULT '0',
  `documentgroup` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 COMMENT='Contains data used for access permissions.' AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `ms_membergroup_access`
--

INSERT INTO `ms_membergroup_access` (`id`, `membergroup`, `documentgroup`) VALUES
(1, 1, 1),
(2, 2, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `ms_membergroup_names`
--

CREATE TABLE IF NOT EXISTS `ms_membergroup_names` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 COMMENT='Contains data used for access permissions.' AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `ms_membergroup_names`
--

INSERT INTO `ms_membergroup_names` (`id`, `name`) VALUES
(1, 'admin'),
(2, 'manager');

-- --------------------------------------------------------

--
-- Структура таблицы `ms_member_groups`
--

CREATE TABLE IF NOT EXISTS `ms_member_groups` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_group` int(10) NOT NULL DEFAULT '0',
  `member` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_group_member` (`user_group`,`member`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 COMMENT='Contains data used for access permissions.' AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `ms_member_groups`
--

INSERT INTO `ms_member_groups` (`id`, `user_group`, `member`) VALUES
(1, 2, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `ms_site_content`
--

CREATE TABLE IF NOT EXISTS `ms_site_content` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL DEFAULT 'document',
  `contentType` varchar(50) NOT NULL DEFAULT 'text/html',
  `pagetitle` varchar(255) NOT NULL DEFAULT '',
  `longtitle` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) DEFAULT '',
  `link_attributes` varchar(255) NOT NULL DEFAULT '' COMMENT 'Link attriubtes',
  `published` int(1) NOT NULL DEFAULT '0',
  `pub_date` int(20) NOT NULL DEFAULT '0',
  `unpub_date` int(20) NOT NULL DEFAULT '0',
  `parent` int(10) NOT NULL DEFAULT '0',
  `isfolder` int(1) NOT NULL DEFAULT '0',
  `introtext` text COMMENT 'Used to provide quick summary of the document',
  `content` mediumtext,
  `richtext` tinyint(1) NOT NULL DEFAULT '1',
  `template` int(10) NOT NULL DEFAULT '0',
  `menuindex` int(10) NOT NULL DEFAULT '0',
  `searchable` int(1) NOT NULL DEFAULT '1',
  `cacheable` int(1) NOT NULL DEFAULT '1',
  `createdby` int(10) NOT NULL DEFAULT '0',
  `createdon` int(20) NOT NULL DEFAULT '0',
  `editedby` int(10) NOT NULL DEFAULT '0',
  `editedon` int(20) NOT NULL DEFAULT '0',
  `deleted` int(1) NOT NULL DEFAULT '0',
  `deletedon` int(20) NOT NULL DEFAULT '0',
  `deletedby` int(10) NOT NULL DEFAULT '0',
  `publishedon` int(20) NOT NULL DEFAULT '0' COMMENT 'Date the document was published',
  `publishedby` int(10) NOT NULL DEFAULT '0' COMMENT 'ID of user who published the document',
  `menutitle` varchar(255) NOT NULL DEFAULT '' COMMENT 'Menu title',
  `donthit` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Disable page hit count',
  `haskeywords` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'has links to keywords',
  `hasmetatags` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'has links to meta tags',
  `privateweb` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Private web document',
  `privatemgr` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Private manager document',
  `content_dispo` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-inline, 1-attachment',
  `hidemenu` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Hide document from menu',
  `alias_visible` int(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `parent` (`parent`),
  KEY `aliasidx` (`alias`),
  KEY `typeidx` (`type`),
  FULLTEXT KEY `content_ft_idx` (`pagetitle`,`description`,`content`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 COMMENT='Contains the site document tree.' AUTO_INCREMENT=17 ;

--
-- Дамп данных таблицы `ms_site_content`
--

INSERT INTO `ms_site_content` (`id`, `type`, `contentType`, `pagetitle`, `longtitle`, `description`, `alias`, `link_attributes`, `published`, `pub_date`, `unpub_date`, `parent`, `isfolder`, `introtext`, `content`, `richtext`, `template`, `menuindex`, `searchable`, `cacheable`, `createdby`, `createdon`, `editedby`, `editedon`, `deleted`, `deletedon`, `deletedby`, `publishedon`, `publishedby`, `menutitle`, `donthit`, `haskeywords`, `hasmetatags`, `privateweb`, `privatemgr`, `content_dispo`, `hidemenu`, `alias_visible`) VALUES
(1, 'document', 'text/html', 'Главная', '', '', 'index', '', 1, 0, 0, 3, 0, '', '', 1, 3, 0, 1, 1, 1, 1130304721, 1, 1468501927, 0, 0, 0, 1130304721, 1, '', 0, 0, 0, 0, 0, 0, 0, 1),
(2, 'document', 'text/html', 'Доставка и оплата', '', '', 'dostavka-i-oplata', '', 1, 0, 0, 3, 0, '', '<h2>Оформление заказа</h2>\r\n<p>&nbsp;</p>\r\n<h4>Оформление заказа по телефону</h4>\r\n<p>Выберите нужный вам образец товара из каталога сайта.</p>\r\n<p>Позвоните нам по телефонам и сделайте заказ:&nbsp;863- 206-03-89 </p>\r\n<p>Наши менеджеры уточнят наличие товара на складе, оформят заказ на интересующий вас товар и сообщат общую стоимость, согласуют удобное для Вас время доставки товара.</p>\r\n<h2>Оплата заказа</h2>\r\n<ol>\r\n<li>Оплата наличными (физические лица). Оплата осуществляется непосредственно в нашем магазине  (при самовывозе), либо наличными курьеру при доставке нашей курьерской службой. </li>\r\n<li>Оплата по безналичному расчету (юридические лица):<br />\r\nДля оплаты заказа по безналичному расчету менеджер нашего интернет-магазина высылает Вам счет согласованным с Вами способом. Счет, а также резерв товара действительны в течение пяти банковских дней. Если в течение этого времени Вы не направили средства в оплату счета, он становится недействительным и Вам необходимо получить от нашей компании новый счет. Товар отпускается после зачисления средств на наш расчетный счет. Для получения товара необходимо предоставить оригинал доверенности от организации-плательщика с указанием получаемых материальных ценностей или заверить наш экземпляр товарно-транспортной накладной печатью организации-плательщика. </li>\r\n</ol>\r\n<h2>Получение товара</h2>\r\n<p>Вы можете самостоятельно забрать оплаченный&nbsp;зарезервированный товар в нашем магазине, или воспользоваться службой доставки.</p>\r\n<h4>Доставка товара</h4>\r\n<p>Наша компания обеспечивает доставку товаров по г.Ростову-на-Дону своей курьерской службой в течении 4-6 часов после оформления заказа (если заказ сделан до 12-00 ).</p>\r\n<p><span class="font">При самовывозе  Вы сможете забрать свой товар в пункте выдачи интернет-магазина по адресу: ул.Таганрогская 144 </span></p>\r\n<p>Свои пожелания о времени и дате доставки Вы всегда можете оговорить с менеджером или написать их в форме оформления заказа.</p>\r\n<p>В случае оформления заказа по Интернет в рабочее время, в течение 1-2-х часов с Вами свяжется наш менеджер для уточнения условий доставки.</p>\r\n<p><span class="font">Если заказ оформляется после 16.00 с Вами свяжутся&nbsp; до 12-00 следующего рабочего дня.<br />\r\n</span></p>\r\n<p>Стоимость доставки по г.Ростову-на-Дону &#8212; 200 руб., при заказе свыше 5 000 руб. &#8212; бесплатно.</p>\r\n<p>&nbsp;</p>\r\n<h2>При получении товара.</h2>\r\n<p>При получении товара Вы должны лично убедиться в рабочем состоянии заказываемого товара. Внимательно осмотрите товар, убедитесь в отсутствии видимых механических повреждений, проверьте комплектность, наличие и правильность заполнения документов. Если по каким-то причинам Ваше решение о покупке изменилось, Вы можете отказаться от товара до момента оплаты. Если товар Вас устраивает, Вы ставите свою подпись и печать Вашей организации на товарной накладной или предоставляете доверенность от организации на получение товара. После этого курьер отдаёт Вам пакет документов: товарный чек (при оплате за наличный расчет), ваш экземпляр товарной накладной, счета-фактуры и гарантийные талоны на товары.</p>\r\n<p>Гарантийное и послегарантийное обслуживание инструмента производится в авторизованных сервисных центрах, указанных производителем.</p>\r\n<p>Претензии к качеству приобретенного товара, возникшие после его получения, рассматриваются в соответствии с Законом РФ &#171;О защите прав потребителей&#187; и гарантийными обязательствами компании.</p>\r\n<p>&nbsp;</p>\r\n<h4>Статья 25. Право потребителя на обмен товара надлежащего качества</h4>\r\n<ol>\r\n<li>\r\n<p>Потребитель вправе обменять непродовольственный товар надлежащего качества на аналогичный товар у продавца, у которого этот товар был приобретен, если указанный товар не подошел по форме, габаритам, фасону, расцветке, размеру или комплектации.</p>\r\n<p>(в ред. Федерального закона от 17.12.1999 N 212-ФЗ).</p>\r\n<p>Потребитель имеет право на обмен непродовольственного товара надлежащего качества в течение четырнадцати дней, не считая дня его покупки.</p>\r\n<p>Обмен непродовольственного товара надлежащего качества производится, если указанный товар не был в употреблении, сохранены его товарный вид, потребительские свойства, пломбы, фабричные ярлыки, а также товарный чек или кассовый чек, выданные потребителю вместе с проданным указанным товаром.</p>\r\n<p>Перечень товаров, не подлежащих обмену по основаниям, указанным в настоящей статье, утверждается Правительством Российской Федерации.</p>\r\n</li>\r\n<li>\r\n<p>В случае, если аналогичный товар отсутствует в продаже на день обращения потребителя к продавцу, потребитель вправе по своему выбору расторгнуть договор купли &#8212; продажи и потребовать возврата уплаченной за указанный товар денежной суммы или обменять его на аналогичный товар при первом поступлении соответствующего товара в продажу. Продавец обязан сообщить потребителю, потребовавшему обмена непродовольственного товара надлежащего качества, о его поступлении в продажу.</p>\r\n<p>(в ред. Федерального закона от 17.12.1999 N 212-ФЗ)</p>\r\n</li>\r\n</ol>\r\n<h4>Перечень товаров надлежащего качества, не подлежащих возврату или обмену</h4>\r\n<p>В перечень товаров надлежащего качества, не подлежащих возврату или обмену, включены:\r\n</p>\r\n<ul>\r\n<li>товары для профилактики и лечения заболеваний в домашних условиях (предметы санитарии и гигиены из металла, резины, текстиля и других материалов, инструменты, приборы и аппаратура медицинские, средства гигиены полости рта, линзы очковые, предметы по уходу за детьми);</li>\r\n<li>предметы личной гигиены;</li>\r\n<li>парфюмерно &#8212; косметические товары;</li>\r\n<li>текстильные товары;</li>\r\n<li>швейные и трикотажные изделия;</li>\r\n<li>изделия и материалы, контактирующие с пищевыми продуктами;</li>\r\n<li>товары бытовой химии;</li>\r\n<li>изделия из драгоценных металлов, с драгоценнымикамнями;</li>\r\n<li>из драгоценных металлов со вставками из полудрагоценных и синтетических камней, ограненные драгоценные камни;</li>\r\n<li>мебель бытовая (гарнитуры и комплекты); автомотовелотехника, мобильные средства малой механизации сельхозработ, прогулочные суда и иные плавсредства бытового назначения; </li>\r\n</ul>\r\n<p><span class="font">Технически сложные товары бытового назначения, на которые установлены гарантийные сроки: </span></p>\r\n<ul>\r\n<li>станки металлорежущие и деревообрабатывающие бытовые; </li>\r\n<li>электробытовые машины и приборы;  </li>\r\n<li>кухонное оборудование;</li>\r\n<li>бытовая радиоэлектронная аппаратура; бытовая вычислительная и множительная техника;</li>\r\n<li>фото- и киноаппаратура; </li>\r\n<li>телефонные аппараты и факсимильная аппаратура; </li>\r\n<li>электромузыкальные инструменты; игрушки электронные.</li>\r\n</ul>', 1, 3, 1, 1, 1, 1, 1468499271, 1, 1468503017, 0, 0, 0, 1468499271, 1, '', 0, 0, 0, 0, 0, 0, 0, 1),
(3, 'document', 'text/html', 'Верхнее меню', '', '', 'topmenu', '', 0, 0, 0, 0, 1, '', '', 1, 3, 0, 1, 1, 1, 1468499295, 1, 1468499314, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0),
(4, 'document', 'text/html', 'Статьи', '', '', 'stati', '', 1, 0, 0, 3, 0, '', '', 1, 3, 2, 1, 1, 1, 1468499331, 1, 1468499331, 0, 0, 0, 1468499331, 1, '', 0, 0, 0, 0, 0, 0, 0, 1),
(5, 'document', 'text/html', 'Написать нам', '', '', 'mail', '', 1, 0, 0, 3, 0, '', '[!SuperPuperForms? &form=`1`!]', 1, 3, 3, 1, 1, 1, 1468499340, 1, 1468502713, 0, 0, 0, 1468499340, 1, '', 0, 0, 0, 0, 0, 0, 0, 1),
(6, 'document', 'text/html', 'Контактная информация', '', '', 'contacts', '', 1, 0, 0, 3, 0, '', '[!PageContacts!]', 1, 3, 4, 1, 1, 1, 1468499360, 1, 1468501340, 0, 0, 0, 1468499360, 1, '', 0, 0, 0, 0, 0, 0, 0, 1),
(7, 'document', 'text/html', 'Каталог', '', '', 'catalog', '', 1, 0, 0, 0, 0, '', '', 1, 3, 1, 1, 1, 1, 1468499445, 1, 1468499445, 0, 0, 0, 1468499445, 1, '', 0, 0, 0, 0, 0, 0, 0, 1),
(8, 'document', 'text/html', 'Технические страницы', '', '', 'techpages', '', 0, 0, 0, 0, 1, '', '', 1, 0, 999, 1, 1, 1, 1468572420, 1, 1468572420, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0),
(9, 'document', 'text/html', 'Страница не найдена', '', '', '404', '', 1, 0, 0, 8, 0, '', '<p>Страница не найдена.</p>', 1, 3, 0, 1, 1, 1, 1468572442, 1, 1468572442, 0, 0, 0, 1468572442, 1, '', 0, 0, 0, 0, 0, 0, 0, 1),
(10, 'document', 'text/html', 'Страница не доступна', '', '', 'fail', '', 1, 0, 0, 8, 0, '', '<p>Страница не доступна</p>', 1, 3, 1, 1, 1, 1, 1468572457, 1, 1468572457, 0, 0, 0, 1468572457, 1, '', 0, 0, 0, 0, 0, 0, 0, 1),
(11, 'document', 'text/html', 'Магазин', '', '', 'shop', '', 0, 0, 0, 8, 1, '', '', 1, 3, 2, 1, 1, 1, 1468572481, 1, 1468572481, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0),
(12, 'document', 'text/html', 'Моя корзина', '', '', 'basket', '', 1, 0, 0, 11, 0, '', '', 1, 6, 0, 1, 1, 1, 1468572508, 1, 1468572532, 0, 0, 0, 1468572508, 1, '', 0, 0, 0, 0, 0, 0, 0, 1),
(13, 'document', 'text/html', '____action', '', '', '____action', '', 0, 0, 0, 8, 1, '', '', 1, 0, 999, 1, 1, 1, 1468572609, 1, 1468572609, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0),
(14, 'document', 'text/html', 'AJAX', '', '', 'ajax', '', 1, 0, 0, 13, 0, '', '[!AJAX!]', 1, 0, 0, 1, 1, 1, 1468572624, 1, 1468572624, 0, 0, 0, 1468572624, 1, '', 0, 0, 0, 0, 0, 0, 0, 1),
(15, 'document', 'text/html', 'Страницы', '', '', 'pages', '', 0, 0, 0, 0, 1, '', '', 1, 3, 3, 1, 1, 1, 1468572646, 1, 1468572646, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 1, 0),
(16, 'document', 'text/html', 'Результат поиска', '', '', 'search', '', 1, 0, 0, 15, 0, '', '[!SuperPuperSearch!]', 1, 3, 0, 1, 1, 1, 1468572662, 1, 1468572662, 0, 0, 0, 1468572662, 1, '', 0, 0, 0, 0, 0, 0, 0, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `ms_site_content_metatags`
--

CREATE TABLE IF NOT EXISTS `ms_site_content_metatags` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `metatag_id` int(11) NOT NULL DEFAULT '0',
  KEY `content_id` (`content_id`),
  KEY `metatag_id` (`metatag_id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='Reference table between meta tags and content';

-- --------------------------------------------------------

--
-- Структура таблицы `ms_site_htmlsnippets`
--

CREATE TABLE IF NOT EXISTS `ms_site_htmlsnippets` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT 'Chunk',
  `editor_type` int(11) NOT NULL DEFAULT '0' COMMENT '0-plain text,1-rich text,2-code editor',
  `editor_name` varchar(50) NOT NULL DEFAULT 'none',
  `category` int(11) NOT NULL DEFAULT '0' COMMENT 'category id',
  `cache_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Cache option',
  `snippet` mediumtext,
  `locked` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 COMMENT='Contains the site chunks.' AUTO_INCREMENT=9 ;

--
-- Дамп данных таблицы `ms_site_htmlsnippets`
--

INSERT INTO `ms_site_htmlsnippets` (`id`, `name`, `description`, `editor_type`, `editor_name`, `category`, `cache_type`, `snippet`, `locked`) VALUES
(1, 'mm_rules', 'Default ManagerManager rules.', 2, 'none', 1, 0, '// more example rules are in assets/plugins/managermanager/example_mm_rules.inc.php\r\n// example of how PHP is allowed - check that a TV named documentTags exists before creating rule\r\n\r\nif ($modx->db->getValue($modx->db->select(''count(id)'', $modx->getFullTableName(''site_tmplvars''), "name=''documentTags''"))) {\r\n	mm_widget_tags(''documentTags'', '' ''); // Give blog tag editing capabilities to the ''documentTags (3)'' TV\r\n}\r\nmm_widget_showimagetvs(); // Always give a preview of Image TVs\r\n\r\nmm_moveFieldsToTab( "published,alias_visible", "general" );\r\n	\r\nmm_moveFieldsToTab( ''longtitle,description,menutitle,log,searchable,link_attributes'', ''settings'' );\r\n', 0),
(2, 'HEAD', '', 2, 'none', 8, 0, '<!DOCTYPE html>\r\n<html lang="ru">\r\n	<head>\r\n		<meta charset="[(modx_charset)]" />\r\n		<!--[if lt IE 9]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->\r\n\r\n		<base_and_canonical />\r\n\r\n		<title>[*seo_title*]</title>\r\n		<meta name="description" content="[*seo_description*]" />\r\n		<meta name="keywords" content="[*seo_keywords*]" />\r\n\r\n		<meta name="viewport" content="width=device-width, initial-scale=1" />\r\n\r\n		<link rel="icon" href="favicon.ico" type="image/x-icon" />\r\n		<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />\r\n		<!-- ==================================================================== -->\r\n\r\n		<!-- JS & CSS -->\r\n		<script type="text/javascript" src="[!Compress? &compress=`false` &files=`template/js/jquery/: jquery-2.1.4.min.js, jquery-ui.min.js` &tofile=`template/js/jquery/jquery.js`!]"></script>\r\n		<link rel="stylesheet" type="text/css" href="[!Compress? &files=`template/css/: main.css, dop.css, catalog.css, shop.css` &tofile=`template/css/all.compress.css`!]" />\r\n		<!-- JS & CSS -->\r\n\r\n		<script type="text/javascript">\r\n			$v(function(){\r\n				$v( ".cat-item" ).hover(\r\n					function(){\r\n						$v( ".children", this ).toggle( ''slide'', {}, 100 );\r\n					}\r\n				);\r\n			});\r\n		</script>\r\n\r\n		{{GoogleAnalytics}}\r\n		\r\n		<!-- <a class="highslide" onclick="return hs.expand(this)"> -->\r\n	</head>\r\n	<body id="bdy">\r\n		<div class="mainwrapper [[if? &is=`[*id*]:=:1` &then=`mainwrapper_mainpage` &else=` `]]">\r\n			<!-- ================================================= -->', 0),
(4, 'FOOTER', '', 2, 'none', 8, 0, '<div class="footer_br">&nbsp;</div>\r\n<footer class="wrapper_footer">\r\n   <div itemscope itemtype="http://schema.org/LocalBusiness" class="footer mw1100px">\r\n	   <div class="foot_1 hcont">\r\n		   <div itemprop="address" itemscope itemtype="http://schema.org/PostalAddress" class="hc_addr"><span class="famicon">&nbsp;</span> <span itemprop="postalCode">344000</span>, <span itemprop="addressCountry">Россия</span>, <span itemprop="addressLocality">г. Ростов-на-Дону</span>, <span itemprop="streetAddress">ул. Таганрогская, д. 144</span></div>\r\n\r\n		   <div itemprop="telephone" class="hc_phone"><span class="famicon">&nbsp;</span> +7 (863) 206-03-89</div>\r\n\r\n		   <div class="hc_grafik"><span class="famicon2">&nbsp;</span> пн.-пт. 9:00 &ndash; 18:00</div>\r\n\r\n		   <div class="hc_mail"><span class="famicon">&nbsp;</span> <a class="as3" href="mailto:mrvlhf@mail.ru"><span itemprop="email">mrvlhf@mail.ru</span></a></div>\r\n	   </div>\r\n\r\n	   <div class="foot_3">\r\n		   <div>&copy; <span itemprop="name">«Мастерстрой»</span> &ndash; [[Date? &f=`Y`]]</div>\r\n		   <div>\r\n			   {{COUNTER}}\r\n		   </div>\r\n		   <div class="deltalink"><img src="template/images/deltalink.png" alt="DELTA" title="DELTA" /></div>\r\n	   </div>\r\n\r\n	   <div class="foot_2">\r\n		   <div class="linkstosocseti">\r\n			   <a class="fb" target="_blank" href="https://facebook.com/"><span>Facebook</span></a>\r\n			   <a class="mru" target="_blank" href="http://my.mail.ru/"><span>Mail.ru</span></a>\r\n			   <a class="ok" target="_blank" href="http://ok.ru/"><span>ok.ru</span></a>\r\n			   <a class="vk" target="_blank" href="http://vk.com/"><span>ВКонтакте</span></a>\r\n			   <div class="clr">&nbsp;</div>\r\n		   </div>\r\n	   </div>\r\n\r\n	   <div class="foot_4">\r\n		   <div class="footermenu">\r\n			   <div class="foottit">Информация</div>\r\n			   [[Wayfinder? &startId=`32` &rowTpl=`wf_botmenu_rowTpl`]]\r\n		   </div>\r\n	   </div>\r\n	   <div class="clr">&nbsp;</div>\r\n   </div>\r\n</footer>\r\n\r\n<!-- ================================================= -->\r\n</div>\r\n\r\n<div class="knopavverh">&nbsp;</div>\r\n\r\n<!-- JS & CSS -->\r\n<noscript><link rel="stylesheet" type="text/css" href="template/css/noscript.css" /></noscript>\r\n\r\n<script type="text/javascript" src="template/js/highslide/highslide-with-gallery.min.js"></script>\r\n<link rel="stylesheet" type="text/css" href="[!Compress? &file=`template/js/highslide/highslide.css`!]" />\r\n\r\n<link rel="stylesheet" type="text/css" href="[!Compress? &file=`template/js/poshytip/tip-twitter/tip-twitter.css`!]" />\r\n<script type="text/javascript" src="template/js/poshytip/jquery.poshytip.min.js"></script>\r\n\r\n<script type="text/javascript" src="[!Compress? &files=`template/js/: scroll_animate.js, javascript.js, shop.js` &tofile=`template/js/all.compress.js`!]"></script>\r\n<!-- JS & CSS -->\r\n\r\n[!SuperPuperForms? &popup=`2` &class=`spfs_krzhk,phoneorder`!]\r\n\r\n</body></html>', 0),
(3, 'GoogleAnalytics', '', 2, 'none', 0, 0, '<script>(function(i,s,o,g,r,a,m){i[''GoogleAnalyticsObject'']=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)})(window,document,''script'',''//www.google-analytics.com/analytics.js'',''ga'');ga(''create'', ''UA-71023734-1'', ''auto'');ga(''send'', ''pageview'');</script>', 0),
(5, 'COUNTER', '', 2, 'none', 8, 0, '<!--LiveInternet counter--><script type="text/javascript"><!--\r\ndocument.write("<a href=''//www.liveinternet.ru/click'' "+\r\n"target=_blank><img src=''//counter.yadro.ru/hit?t44.5;r"+\r\nescape(document.referrer)+((typeof(screen)=="undefined")?"":\r\n";s"+screen.width+"*"+screen.height+"*"+(screen.colorDepth?\r\nscreen.colorDepth:screen.pixelDepth))+";u"+escape(document.URL)+\r\n";"+Math.random()+\r\n"'' alt='''' title=''LiveInternet'' "+\r\n"border=''0'' width=''31'' height=''31''><\\/a>")\r\n//--></script><!--/LiveInternet-->\r\n\r\n\r\n<!-- Yandex.Metrika counter -->\r\n<script type="text/javascript">\r\n(function (d, w, c) {\r\n    (w[c] = w[c] || []).push(function() {\r\n        try {\r\n            w.yaCounter16387657 = new Ya.Metrika({id:16387657,\r\n                    webvisor:true,\r\n                    clickmap:true,\r\n                    trackLinks:true,\r\n                    accurateTrackBounce:true});\r\n        } catch(e) { }\r\n    });\r\n\r\n    var n = d.getElementsByTagName("script")[0],\r\n        s = d.createElement("script"),\r\n        f = function () { n.parentNode.insertBefore(s, n); };\r\n    s.type = "text/javascript";\r\n    s.async = true;\r\n    s.src = (d.location.protocol == "https:" ? "https:" : "http:") + "//mc.yandex.ru/metrika/watch.js";\r\n\r\n    if (w.opera == "[object Opera]") {\r\n        d.addEventListener("DOMContentLoaded", f, false);\r\n    } else { f(); }\r\n})(document, window, "yandex_metrika_callbacks");\r\n</script>\r\n<noscript><div><img src="//mc.yandex.ru/watch/16387657" style="position:absolute; left:-9999px;" alt="" /></div></noscript>\r\n<!-- /Yandex.Metrika counter -->\r\n					<!-- PulsCen: company widget --><div style="font: normal 11px/120% arial !important; display: inline-block !important; //display: inline !important;"><div style="border: 1px solid #ffa200; background: url(http://www.pulscen.ru/images/informers/bg_orange.gif) 0 100% repeat-x #fff; height: 29px; overflow: hidden; display: inline-block !important; //display: inline !important;"><table style="width: 88px; margin: 0; border: 0; border-collapse: collapse;"><tr><td style="text-align: center; font: normal 11px/120% arial !important; white-space: nowrap; padding: 1px 2px 0; border: 0;"><nobr><a style="color: #000; text-decoration: none; outline: none;" href="http://masterstroy.pulscen.ru/">Мастерстрой</a></nobr></td></tr><tr><td style="padding: 2px 2px 1px; font: normal 11px/120% arial !important; border: 0;"><span style="float: right; font-size: 10px; padding: 0 !important; margin: -1px 0 0 !important;"><a style="color: #1c53a2; text-decoration: none; outline: none;" href="http://rostov.pulscen.ru/price/150504-yelektrodreli">PulsCen.ru</a></span><img src="http://www.pulscen.ru/cwds?c=918703ea3729ae1c6db95d736f3c8e0e" width="23" height="10" alt="Электродрели в Ростове-на-Дону" title="Электродрели в Ростове-на-Дону" /></td></tr></table></div></div><!-- // PulsCen: company widget -->\r\n', 0),
(6, 'CONTENT_1', '', 2, 'none', 8, 0, '<main class="center">\r\n			<div class="white_block">\r\n<!-- whiteblock whiteblock whiteblock whiteblock whiteblock whiteblock -->\r\n				<div class="pathway">[[Breadcrumbs? &showCurrentCrumb=`0`]]</div>\r\n				\r\n				<div class="pagetitle"><h1>[*seo_h1*]</h1></div>\r\n				\r\n				<div class="content_br">&nbsp;</div>\r\n				<div class="content">\r\n<!-- content content content content content content content content content content content content content content content content -->', 0),
(7, 'CONTENT_2', '', 2, 'none', 8, 0, '<!-- content content content content content content content content content content content content content content content content -->\r\n					{{socseti}}\r\n				</div>\r\n<!-- whiteblock whiteblock whiteblock whiteblock whiteblock whiteblock -->\r\n			</div>\r\n\r\n		</main>', 0),
(8, 'socseti', '', 2, 'none', 9, 0, '<div class="clr">&nbsp;</div>\r\n<div class="socseti">\r\n	<script type="text/javascript" src="//yastatic.net/es5-shims/0.0.2/es5-shims.min.js" charset="utf-8"></script><script type="text/javascript" src="//yastatic.net/share2/share.js" charset="utf-8"></script><div class="ya-share2" data-services="vkontakte,facebook,odnoklassniki,moimir,gplus,twitter,evernote,linkedin,lj,viber,whatsapp" data-counter=""></div>\r\n</div>', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `ms_site_keywords`
--

CREATE TABLE IF NOT EXISTS `ms_site_keywords` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `keyword` varchar(40) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `keyword` (`keyword`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='Site keyword list' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `ms_site_metatags`
--

CREATE TABLE IF NOT EXISTS `ms_site_metatags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `tag` varchar(50) NOT NULL DEFAULT '' COMMENT 'tag name',
  `tagvalue` varchar(255) NOT NULL DEFAULT '',
  `http_equiv` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1 - use http_equiv tag style, 0 - use name',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='Site meta tags' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `ms_site_modules`
--

CREATE TABLE IF NOT EXISTS `ms_site_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '0',
  `editor_type` int(11) NOT NULL DEFAULT '0' COMMENT '0-plain text,1-rich text,2-code editor',
  `disabled` tinyint(4) NOT NULL DEFAULT '0',
  `category` int(11) NOT NULL DEFAULT '0' COMMENT 'category id',
  `wrap` tinyint(4) NOT NULL DEFAULT '0',
  `locked` tinyint(4) NOT NULL DEFAULT '0',
  `icon` varchar(255) NOT NULL DEFAULT '' COMMENT 'url to module icon',
  `enable_resource` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'enables the resource file feature',
  `resourcefile` varchar(255) NOT NULL DEFAULT '' COMMENT 'a physical link to a resource file',
  `createdon` int(11) NOT NULL DEFAULT '0',
  `editedon` int(11) NOT NULL DEFAULT '0',
  `guid` varchar(32) NOT NULL DEFAULT '' COMMENT 'globally unique identifier',
  `enable_sharedparams` tinyint(4) NOT NULL DEFAULT '0',
  `properties` text,
  `modulecode` mediumtext COMMENT 'module boot up code',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 COMMENT='Site Modules' AUTO_INCREMENT=8 ;

--
-- Дамп данных таблицы `ms_site_modules`
--

INSERT INTO `ms_site_modules` (`id`, `name`, `description`, `editor_type`, `disabled`, `category`, `wrap`, `locked`, `icon`, `enable_resource`, `resourcefile`, `createdon`, `editedon`, `guid`, `enable_sharedparams`, `properties`, `modulecode`) VALUES
(1, 'Doc Manager', '<strong>1.1</strong> Quickly perform bulk updates to the Documents in your site including templates, publishing details, and permissions', 0, 0, 2, 0, 0, '', 0, '', 0, 0, 'docman435243542tf542t5t', 1, '', 'include_once(MODX_BASE_PATH.''assets/modules/docmanager/classes/docmanager.class.php'');\ninclude_once(MODX_BASE_PATH.''assets/modules/docmanager/classes/dm_frontend.class.php'');\ninclude_once(MODX_BASE_PATH.''assets/modules/docmanager/classes/dm_backend.class.php'');\n\n$dm = new DocManager($modx);\n$dmf = new DocManagerFrontend($dm, $modx);\n$dmb = new DocManagerBackend($dm, $modx);\n\n$dm->ph = $dm->getLang();\n$dm->ph[''theme''] = $dm->getTheme();\n$dm->ph[''ajax.endpoint''] = MODX_SITE_URL.''assets/modules/docmanager/tv.ajax.php'';\n$dm->ph[''datepicker.offset''] = $modx->config[''datepicker_offset''];\n$dm->ph[''datetime.format''] = $modx->config[''datetime_format''];\n\nif (isset($_POST[''tabAction''])) {\n    $dmb->handlePostback();\n} else {\n    $dmf->getViews();\n    echo $dm->parseTemplate(''main.tpl'', $dm->ph);\n}'),
(2, 'Extras', '<strong>0.1.2</strong> first repository for MODX EVO', 0, 0, 2, 0, 0, '', 0, '', 0, 0, 'store435243542tf542t5t', 1, '', '//AUTHORS: Bumkaka & Dmi3yy \r\ninclude_once(''../assets/modules/store/core.php'');'),
(3, 'Страница Контакты', '', 0, 0, 0, 0, 0, '', 0, '', 0, 0, '31b444acdf77286a51f25dbb865002e2', 1, '', 'include_once( MODX_BASE_PATH .''assets/modules/scorn_page_contacts/_action.php'' );'),
(4, 'З А К А З Ы', '', 0, 0, 0, 0, 0, '', 0, '', 0, 0, 'fea9356130a76dcc7e97c8583643f232', 1, '', 'include_once( MODX_BASE_PATH .''assets/modules/scorn_orders/_action.php'' );'),
(5, 'Изменение цен', '', 0, 0, 0, 0, 0, '', 0, '', 0, 0, '5cdb7652750d4f2182f8ba4f06e07828', 1, '', 'include_once( MODX_BASE_PATH .''assets/modules/scorn_price_change/_action.php'' );'),
(6, 'Импорт из MODx', '', 0, 0, 0, 0, 0, '', 0, '', 0, 0, '4748a3d27fa4732e7cdc6cd9f9caf306', 1, '', 'include_once( MODX_BASE_PATH .''assets/modules/scorn_import_from_modx/_action.php'' );'),
(7, 'ПОКУПАТЕЛИ', '', 0, 0, 0, 0, 0, '', 0, '', 0, 0, '918d48ed9c20b1ca294234088fcb85a2', 1, '', 'include_once( MODX_BASE_PATH .''assets/modules/scorn_webusers/_action.php'' );');

-- --------------------------------------------------------

--
-- Структура таблицы `ms_site_module_access`
--

CREATE TABLE IF NOT EXISTS `ms_site_module_access` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` int(11) NOT NULL DEFAULT '0',
  `usergroup` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='Module users group access permission' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `ms_site_module_depobj`
--

CREATE TABLE IF NOT EXISTS `ms_site_module_depobj` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module` int(11) NOT NULL DEFAULT '0',
  `resource` int(11) NOT NULL DEFAULT '0',
  `type` int(2) NOT NULL DEFAULT '0' COMMENT '10-chunks, 20-docs, 30-plugins, 40-snips, 50-tpls, 60-tvs',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='Module Dependencies' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `ms_site_plugins`
--

CREATE TABLE IF NOT EXISTS `ms_site_plugins` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT 'Plugin',
  `editor_type` int(11) NOT NULL DEFAULT '0' COMMENT '0-plain text,1-rich text,2-code editor',
  `category` int(11) NOT NULL DEFAULT '0' COMMENT 'category id',
  `cache_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Cache option',
  `plugincode` mediumtext,
  `locked` tinyint(4) NOT NULL DEFAULT '0',
  `properties` text COMMENT 'Default Properties',
  `disabled` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Disables the plugin',
  `moduleguid` varchar(32) NOT NULL DEFAULT '' COMMENT 'GUID of module from which to import shared parameters',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 COMMENT='Contains the site plugins.' AUTO_INCREMENT=13 ;

--
-- Дамп данных таблицы `ms_site_plugins`
--

INSERT INTO `ms_site_plugins` (`id`, `name`, `description`, `editor_type`, `category`, `cache_type`, `plugincode`, `locked`, `properties`, `disabled`, `moduleguid`) VALUES
(1, 'CodeMirror', '<strong>1.3</strong> JavaScript library that can be used to create a relatively pleasant editor interface based on CodeMirror 5.6', 0, 2, 0, '$_CM_BASE = ''assets/plugins/codemirror/'';\r\n\r\n$_CM_URL = $modx->config[''site_url''] . $_CM_BASE;\r\n\r\nrequire(MODX_BASE_PATH. $_CM_BASE .''codemirror.plugin.php'');\r\n\r\n', 0, '&theme=Theme;list;default,ambiance,blackboard,cobalt,eclipse,elegant,erlang-dark,lesser-dark,midnight,monokai,neat,night,rubyblue,solarized,twilight,vibrant-ink,xq-dark,xq-light; &indentUnit=Indent unit;int;4 &tabSize=The width of a tab character;int;4 &lineWrapping=lineWrapping;list;true,false;true &matchBrackets=matchBrackets;list;true,false;true &activeLine=activeLine;list;true,false;false &emmet=emmet;list;true,false;true &search=search;list;true,false;false &indentWithTabs=indentWithTabs;list;true,false;true', 0, ''),
(2, 'Forgot Manager Login', '<strong>1.1.6</strong> Resets your manager login when you forget your password via email confirmation', 0, 2, 0, 'require MODX_BASE_PATH.''assets/plugins/forgotmanagerlogin/plugin.forgotmanagerlogin.php'';', 0, '', 0, ''),
(3, 'FileSource', '<strong>0.1</strong> Save snippet and plugins to file', 0, 2, 0, 'require MODX_BASE_PATH.''assets/plugins/filesource/plugin.filesource.php'';', 0, '', 0, ''),
(4, 'ManagerManager', '<strong>0.6.2</strong> Customize the MODX Manager to offer bespoke admin functions for end users.', 0, 2, 0, '// You can put your ManagerManager rules EITHER in a chunk OR in an external file - whichever suits your development style the best\n\n// To use an external file, put your rules in /assets/plugins/managermanager/mm_rules.inc.php \n// (you can rename default.mm_rules.inc.php and use it as an example)\n// The chunk SHOULD have php opening tags at the beginning and end\n\n// If you want to put your rules in a chunk (so you can edit them through the Manager),\n// create the chunk, and enter its name in the configuration tab.\n// The chunk should NOT have php tags at the beginning or end.\n\n// See also user-friendly module for editing ManagerManager configuration file ddMMEditor (http://code.divandesign.biz/modx/ddmmeditor).\n\n// ManagerManager requires jQuery 1.9.1, which is located in /assets/plugins/managermanager/js/ folder.\n\n// You don''t need to change anything else from here onwards\n//-------------------------------------------------------\n\n// Run the main code\ninclude($modx->config[''base_path''].''assets/plugins/managermanager/mm.inc.php'');', 0, '&remove_deprecated_tv_types_pref=Remove deprecated TV types;list;yes,no;yes &config_chunk=Configuration Chunk;text;mm_rules', 0, ''),
(5, 'Quick Manager+', '<strong>1.5.6</strong> Enables QuickManager+ front end content editing support', 0, 2, 0, '// In manager\nif (isset($_SESSION[''mgrValidated''])) {\n\n    $show = TRUE;\n\n    if ($disabled  != '''') {\n        $arr = array_filter(array_map(''intval'', explode('','', $disabled)));\n        if (in_array($modx->documentIdentifier, $arr)) {\n            $show = FALSE;\n        }\n    }\n\n    if ($show) {\n        // Replace [*#tv*] with QM+ edit TV button placeholders\n        if ($tvbuttons == ''true'') {\n            $e = $modx->Event;\n            if ($e->name == ''OnParseDocument'') {\n                 $output = &$modx->documentOutput;\n                 $output = preg_replace(''~\\[\\*#(.*?)\\*\\]~'', ''<!-- ''.$tvbclass.'' $1 -->[*$1*]'', $output);\n                 $modx->documentOutput = $output;\n             }\n         }\n        // In manager\n        if (isset($_SESSION[''mgrValidated''])) {\n            include_once($modx->config[''base_path''].''assets/plugins/qm/qm.inc.php'');\n            $qm = new Qm($modx, $jqpath, $loadmanagerjq, $loadfrontendjq, $noconflictjq, $loadtb, $tbwidth, $tbheight, $hidefields, $hidetabs, $hidesections, $addbutton, $tpltype, $tplid, $custombutton, $managerbutton, $logout, $autohide, $editbuttons, $editbclass, $newbuttons, $newbclass, $tvbuttons, $tvbclass);\n        }\n    }\n}', 0, '&jqpath=Path to jQuery;text;assets/js/jquery.min.js &loadmanagerjq=Load jQuery in manager;list;true,false;false &loadfrontendjq=Load jQuery in front-end;list;true,false;true &noconflictjq=jQuery noConflict mode in front-end;list;true,false;true &loadtb=Load modal box in front-end;list;true,false;true &tbwidth=Modal box window width;text;80% &tbheight=Modal box window height;text;90% &hidefields=Hide document fields from front-end editors;text;parent &hidetabs=Hide document tabs from front-end editors;text; &hidesections=Hide document sections from front-end editors;text; &addbutton=Show add document here button;list;true,false;true &tpltype=New document template type;list;parent,id,selected;parent &tplid=New document template id;int;3 &custombutton=Custom buttons;textarea; &managerbutton=Show go to manager button;list;true,false;true &logout=Logout to;list;manager,front-end;manager &disabled=Plugin disabled on documents;text; &autohide=Autohide toolbar;list;true,false;true &editbuttons=Inline edit buttons;list;true,false;false &editbclass=Edit button CSS class;text;qm-edit &newbuttons=Inline new resource buttons;list;true,false;false &newbclass=New resource button CSS class;text;qm-new &tvbuttons=Inline template variable buttons;list;true,false;false &tvbclass=Template variable button CSS class;text;qm-tv', 1, ''),
(6, 'Search Highlight', '<strong>1.5</strong> Used with AjaxSearch to show search terms highlighted on page linked from search results', 0, 3, 0, '/*\n  ------------------------------------------------------------------------\n  Plugin: Search_Highlight v1.5\n  ------------------------------------------------------------------------\n  Changes:\n  18/03/10 - Remove possibility of XSS attempts being passed in the URL\n           - look-behind assertion improved\n  29/03/09 - Removed urldecode calls;\n           - Added check for magic quotes - if set, remove slashes\n           - Highlights terms searched for when target is a HTML entity\n  18/07/08 - advSearch parameter and pcre modifier added\n  10/02/08 - Strip_tags added to avoid sql injection and XSS. Use of $_REQUEST\n  01/03/07 - Added fies/updates from forum from users mikkelwe/identity\n  (better highlight replacement, additional div around term/removal message)\n  ------------------------------------------------------------------------\n  Description: When a user clicks on the link from the AjaxSearch results\n    the target page will have the terms highlighted.\n  ------------------------------------------------------------------------\n  Created By:  Susan Ottwell (sottwell@sottwell.com)\n               Kyle Jaebker (kjaebker@muddydogpaws.com)\n\n  Refactored by Coroico (www.evo.wangba.fr) and TS\n  ------------------------------------------------------------------------\n  Based off the the code by Susan Ottwell (www.sottwell.com)\n    http://forums.modx.com/thread/47775/plugin-highlight-search-terms\n  ------------------------------------------------------------------------\n  CSS:\n    The classes used for the highlighting are the same as the AjaxSearch\n  ------------------------------------------------------------------------\n  Notes:\n    To add a link to remove the highlighting and to show the searchterms\n    put the following on your page where you would like this to appear:\n\n      <!--search_terms-->\n\n    Example output for this:\n\n      Search Terms: the, template\n      Remove Highlighting\n\n    Set the following variables to change the text:\n\n      $termText - the text before the search terms\n      $removeText - the text for the remove link\n  ------------------------------------------------------------------------\n*/\nglobal $database_connection_charset;\n// Conversion code name between html page character encoding and Mysql character encoding\n// Some others conversions should be added if needed. Otherwise Page charset = Database charset\n$pageCharset = array(\n  ''utf8'' => ''UTF-8'',\n  ''latin1'' => ''ISO-8859-1'',\n  ''latin2'' => ''ISO-8859-2''\n);\n\nif (isset($_REQUEST[''searched'']) && isset($_REQUEST[''highlight''])) {\n\n  // Set these to customize the text for the highlighting key\n  // --------------------------------------------------------\n     $termText = ''<div class="searchTerms">Search Terms: '';\n     $removeText = ''Remove Highlighting'';\n  // --------------------------------------------------------\n\n  $highlightText = $termText;\n  $advsearch = ''oneword'';\n\n  $dbCharset = $database_connection_charset;\n  $pgCharset = array_key_exists($dbCharset,$pageCharset) ? $pageCharset[$dbCharset] : $dbCharset;\n\n  // magic quotes check\n  if (get_magic_quotes_gpc()){\n    $searched = strip_tags(stripslashes($_REQUEST[''searched'']));\n    $highlight = strip_tags(stripslashes($_REQUEST[''highlight'']));\n    if (isset($_REQUEST[''advsearch''])) $advsearch = strip_tags(stripslashes($_REQUEST[''advsearch'']));\n  }\n  else {\n    $searched = strip_tags($_REQUEST[''searched'']);\n    $highlight = strip_tags($_REQUEST[''highlight'']);\n    if (isset($_REQUEST[''advsearch''])) $advsearch = strip_tags($_REQUEST[''advsearch'']);\n  }\n\n  if ($advsearch != ''nowords'') {\n\n    $searchArray = array();\n    if ($advsearch == ''exactphrase'') $searchArray[0] = $searched;\n    else $searchArray = explode('' '', $searched);\n\n    $searchArray = array_unique($searchArray);\n    $nbterms = count($searchArray);\n    $searchTerms = array();\n    for($i=0;$i<$nbterms;$i++){\n      // Consider all possible combinations\n      $word_ents = array();\n      $word_ents[] = $searchArray[$i];\n      $word_ents[] = htmlentities($searchArray[$i], ENT_NOQUOTES, $pgCharset);\n      $word_ents[] = htmlentities($searchArray[$i], ENT_COMPAT, $pgCharset);\n      $word_ents[] = htmlentities($searchArray[$i], ENT_QUOTES, $pgCharset);\n      // Avoid duplication\n      $word_ents = array_unique($word_ents);\n      foreach($word_ents as $word) $searchTerms[]= array(''term'' => $word, ''class'' => $i+1);\n    }\n\n    $output = $modx->documentOutput; // get the parsed document\n    $body = explode("<body", $output); // break out the head\n\n    $highlightClass = explode('' '',$highlight); // break out the highlight classes\n    /* remove possibility of XSS attempts being passed in URL */\n    foreach ($highlightClass as $key => $value) {\n       $highlightClass[$key] = preg_match(''/[^A-Za-z0-9_-]/ms'', $value) == 1 ? '''' : $value;\n    }\n\n    $pcreModifier = ($pgCharset == ''UTF-8'') ? ''iu'' : ''i'';\n    $lookBehind = ''/(?<!&|&[\\w#]|&[\\w#]\\w|&[\\w#]\\w\\w|&[\\w#]\\w\\w\\w|&[\\w#]\\w\\w\\w\\w|&[\\w#]\\w\\w\\w\\w\\w)'';  // avoid a match with a html entity\n    $lookAhead = ''(?=[^>]*<)/''; // avoid a match with a html tag\n\n    $nbterms = count($searchTerms);\n    for($i=0;$i<$nbterms;$i++){\n      $word = $searchTerms[$i][''term''];\n      $class = $highlightClass[0].'' ''.$highlightClass[$searchTerms[$i][''class'']];\n\n      $highlightText .= ($i > 0) ? '', '' : '''';\n      $highlightText .= ''<span class="''.$class.''">''.$word.''</span>'';\n\n      $pattern = $lookBehind . preg_quote($word, ''/'') . $lookAhead . $pcreModifier;\n      $replacement = ''<span class="'' . $class . ''">${0}</span>'';\n      $body[1] = preg_replace($pattern, $replacement, $body[1]);\n    }\n\n    $output = implode("<body", $body);\n\n    $removeUrl = $modx->makeUrl($modx->documentIdentifier);\n    $highlightText .= ''<br /><a href="''.$removeUrl.''" class="ajaxSearch_removeHighlight">''.$removeText.''</a></div>'';\n\n    $output = str_replace(''<!--search_terms-->'',$highlightText,$output);\n    $modx->documentOutput = $output;\n  }\n}', 0, '', 1, ''),
(7, 'TinyMCE Rich Text Editor', '<strong>3.5.11</strong> Javascript WYSIWYG Editor', 0, 2, 0, 'require MODX_BASE_PATH.''assets/plugins/tinymce/plugin.tinymce.php'';\n', 0, '&customparams=Custom Parameters;textarea;valid_elements : "*[*]", &mce_formats=Block Formats;text;p,h1,h2,h3,h4,h5,h6,div,blockquote,code,pre &entity_encoding=Entity Encoding;list;named,numeric,raw;named &entities=Entities;text; &mce_path_options=Path Options;list;Site config,Absolute path,Root relative,URL,No convert;Site config &mce_resizing=Advanced Resizing;list;true,false;true &disabledButtons=Disabled Buttons;text; &link_list=Link List;list;enabled,disabled;enabled &webtheme=Web Theme;list;simple,editor,creative,custom;simple &webPlugins=Web Plugins;text;style,advimage,advlink,searchreplace,contextmenu,paste,fullscreen,xhtmlxtras,media &webButtons1=Web Buttons 1;text;undo,redo,selectall,|,pastetext,pasteword,|,search,replace,|,hr,charmap,|,image,link,unlink,anchor,media,|,cleanup,removeformat,|,fullscreen,code,help &webButtons2=Web Buttons 2;text;bold,italic,underline,strikethrough,sub,sup,|,|,blockquote,bullist,numlist,outdent,indent,|,justifyleft,justifycenter,justifyright,justifyfull,|,styleselect,formatselect,|,styleprops &webButtons3=Web Buttons 3;text; &webButtons4=Web Buttons 4;text; &webAlign=Web Toolbar Alignment;list;ltr,rtl;ltr &width=Width;text;100% &height=Height;text;500', 0, ''),
(8, 'TransAlias', '<strong>1.0.4</strong> Human readible URL translation supporting multiple languages and overrides', 0, 2, 0, 'require MODX_BASE_PATH.''assets/plugins/transalias/plugin.transalias.php'';', 0, '&table_name=Trans table;list;common,russian,dutch,german,czech,utf8,utf8lowercase;russian &char_restrict=Restrict alias to;list;lowercase alphanumeric,alphanumeric,legal characters;lowercase alphanumeric &remove_periods=Remove Periods;list;Yes,No;No &word_separator=Word Separator;list;dash,underscore,none;dash &override_tv=Override TV name;string;', 0, ' '),
(9, 'REDIRECT', '', 0, 9, 0, '$subfolder= ''/_new'';\r\n\r\n$redirect= array(\r\n	1 => array(\r\n		''/index.html'' => ''/'',\r\n		''/index.php'' => ''/'',\r\n		\r\n		''/cont/'' => ''/contacts.html'',\r\n	)\r\n);\r\n\r\n//=================================================================\r\n\r\n$REQUEST_URI= str_replace( $subfolder, '''', $_SERVER[ ''REQUEST_URI'' ] );\r\nif( $redirect[ 1 ][ $REQUEST_URI ] )\r\n{\r\n	header( ''HTTP/1.1 301 Moved Permanently'' );\r\n	header( ''location: ''. $subfolder . $redirect[ 1 ][ $REQUEST_URI ] );\r\n	exit();\r\n}', 0, '', 0, ' '),
(10, 'BaseAndCanonical', '', 0, 9, 0, '//v004\r\n//BaseAndCanonical\r\n//=========================================================================================\r\n//MODX_SITE_URL = http://domain.ru/\r\n	//$_SERVER[ ''REDIRECT_URL'' ] = /sdfsdf/mail.html\r\n	\r\n	//<base href="" />\r\n	//<link rel="canonical" href="http://domain.ru/404.html" />\r\n	//<base_and_canonical>\r\n$html= $modx->documentOutput;\r\nif( true || isset( $_GET[ ''test'' ] ) )\r\n{\r\n	$wsite= rtrim( MODX_SITE_URL, "/" );\r\n	$redirurl= ( ! empty( $_SERVER[ ''REDIRECT_URL'' ] ) ? $_SERVER[ ''REDIRECT_URL'' ] : ''/'' );\r\n	//$redirurl= $modx->makeUrl( $modx->documentIdentifier );\r\n	\r\n	$uri= strpos( $_SERVER[ ''REQUEST_URI'' ], "?" );\r\n	$get= '''';\r\n	if( $uri !== false )\r\n	{\r\n		$get= substr( $_SERVER[ ''REQUEST_URI'' ], $uri );\r\n	}\r\n	\r\n	$canonical= $wsite . $redirurl .( $get ? $get : '''' );\r\n	$base= MODX_SITE_URL;\r\n	\r\n	if( ! empty( $canonical ) && ! empty( $base ) )\r\n	{\r\n		$base_and_canonical .= ''<base href="''. $base .''" />'';\r\n		$base_and_canonical .= "\\r\\n\\t";\r\n		$base_and_canonical .= ''<link rel="canonical" href="''. $canonical .''" />'';\r\n	}\r\n	\r\n	$html= str_replace( "<base_and_canonical />", $base_and_canonical, $html );\r\n	\r\n	/*\r\n	//preg_match_all( "/<link (.*)rel=\\"canonical\\"(.*)href=(\\"(.*)\\"|''(.*)'')(.*)>/imU", $html, $ss );\r\n	preg_match_all( "/<link (.*)rel=\\"canonical\\"(.*)>/imU", $html, $ss );\r\n	\r\n	if( ! empty( $ss[ 0 ][ 0 ] ) )\r\n	{\r\n		preg_match_all( "/href=(\\"(.*)\\"|''(.*)'')/imU", $ss[ 0 ][ 0 ], $sss );\r\n		\r\n		$redirurl= ( ! empty( $_SERVER[ ''REDIRECT_URL'' ] ) ? $_SERVER[ ''REDIRECT_URL'' ] : ''/'' );\r\n		\r\n		print ''Установлен: ''. $sss[ 2 ][ 0 ] ."\\r\\n";\r\n		print ''Нужно:      ''. $wsite . $redirurl ."\\r\\n";\r\n	}\r\n	*/\r\n}\r\n$modx->documentOutput= $html;', 0, '', 0, ' '),
(11, 'Antideer4', 'v4', 0, 0, 0, '// v4\r\n// 24.06.2016\r\n// Antideer\r\n// Для MODx Evo 1.1\r\n//===========================================================================\r\n$tb_1= ''site_content'';\r\n$tb_2= ''site_htmlsnippets'';\r\n$tb_3= ''site_snippets'';\r\n$tb_4= ''site_templates'';\r\n$tb_5= ''site_tmplvar_contentvalues'';\r\n$tb_6= ''site_tmplvars'';\r\n\r\nmysql_query( "CREATE TABLE IF NOT EXISTS ".$modx->getFullTableName( ''aaa_''. $tb_1 )." (\r\n  `idm` int(10) NOT NULL AUTO_INCREMENT,\r\n  `id` int(10) NOT NULL,\r\n  `type` varchar(20) NOT NULL DEFAULT ''document'',\r\n  `contentType` varchar(50) NOT NULL DEFAULT ''text/html'',\r\n  `pagetitle` varchar(255) NOT NULL DEFAULT '''',\r\n  `longtitle` varchar(255) NOT NULL DEFAULT '''',\r\n  `description` varchar(255) NOT NULL DEFAULT '''',\r\n  `alias` varchar(255) DEFAULT '''',\r\n  `link_attributes` varchar(255) NOT NULL DEFAULT '''' COMMENT ''Link attriubtes'',\r\n  `published` int(1) NOT NULL DEFAULT ''0'',\r\n  `pub_date` int(20) NOT NULL DEFAULT ''0'',\r\n  `unpub_date` int(20) NOT NULL DEFAULT ''0'',\r\n  `parent` int(10) NOT NULL DEFAULT ''0'',\r\n  `isfolder` int(1) NOT NULL DEFAULT ''0'',\r\n  `introtext` text COMMENT ''Used to provide quick summary of the document'',\r\n  `content` mediumtext,\r\n  `richtext` tinyint(1) NOT NULL DEFAULT ''1'',\r\n  `template` int(10) NOT NULL DEFAULT ''0'',\r\n  `menuindex` int(10) NOT NULL DEFAULT ''0'',\r\n  `searchable` int(1) NOT NULL DEFAULT ''1'',\r\n  `cacheable` int(1) NOT NULL DEFAULT ''1'',\r\n  `createdby` int(10) NOT NULL DEFAULT ''0'',\r\n  `createdon` int(20) NOT NULL DEFAULT ''0'',\r\n  `editedby` int(10) NOT NULL DEFAULT ''0'',\r\n  `editedon` int(20) NOT NULL DEFAULT ''0'',\r\n  `deleted` int(1) NOT NULL DEFAULT ''0'',\r\n  `deletedon` int(20) NOT NULL DEFAULT ''0'',\r\n  `deletedby` int(10) NOT NULL DEFAULT ''0'',\r\n  `publishedon` int(20) NOT NULL DEFAULT ''0'' COMMENT ''Date the document was published'',\r\n  `publishedby` int(10) NOT NULL DEFAULT ''0'' COMMENT ''ID of user who published the document'',\r\n  `menutitle` varchar(255) NOT NULL DEFAULT '''' COMMENT ''Menu title'',\r\n  `donthit` tinyint(1) NOT NULL DEFAULT ''0'' COMMENT ''Disable page hit count'',\r\n  `haskeywords` tinyint(1) NOT NULL DEFAULT ''0'' COMMENT ''has links to keywords'',\r\n  `hasmetatags` tinyint(1) NOT NULL DEFAULT ''0'' COMMENT ''has links to meta tags'',\r\n  `privateweb` tinyint(1) NOT NULL DEFAULT ''0'' COMMENT ''Private web document'',\r\n  `privatemgr` tinyint(1) NOT NULL DEFAULT ''0'' COMMENT ''Private manager document'',\r\n  `content_dispo` tinyint(1) NOT NULL DEFAULT ''0'' COMMENT ''0-inline, 1-attachment'',\r\n  `hidemenu` tinyint(1) NOT NULL DEFAULT ''0'' COMMENT ''Hide document from menu'',\r\n  `alias_visible` int(2) NOT NULL DEFAULT ''1'',\r\n  PRIMARY KEY (`idm`)\r\n) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;" );\r\n\r\n\r\nmysql_query( "CREATE TABLE IF NOT EXISTS ".$modx->getFullTableName( ''aaa_''. $tb_5 )." (\r\n  `idm` int(11) NOT NULL AUTO_INCREMENT,\r\n  `id` int(11) NOT NULL,\r\n  `tmplvarid` int(10) NOT NULL DEFAULT ''0'' COMMENT ''Template Variable id'',\r\n  `contentid` int(10) NOT NULL DEFAULT ''0'' COMMENT ''Site Content Id'',\r\n  `value` text,\r\n  PRIMARY KEY (`idm`)\r\n) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;" );\r\n\r\n\r\nmysql_query( "CREATE TABLE IF NOT EXISTS ".$modx->getFullTableName( ''aaa_''. $tb_2 )." (\r\n  `idm` int(10) NOT NULL AUTO_INCREMENT,\r\n  `id` int(10) NOT NULL,\r\n  `name` varchar(50) NOT NULL DEFAULT '''',\r\n  `description` varchar(255) NOT NULL DEFAULT ''Chunk'',\r\n  `editor_type` int(11) NOT NULL DEFAULT ''0'' COMMENT ''0-plain text,1-rich text,2-code editor'',\r\n  `editor_name` varchar(50) NOT NULL DEFAULT ''none'',\r\n  `category` int(11) NOT NULL DEFAULT ''0'' COMMENT ''category id'',\r\n  `cache_type` tinyint(1) NOT NULL DEFAULT ''0'' COMMENT ''Cache option'',\r\n  `snippet` mediumtext,\r\n  `locked` tinyint(4) NOT NULL DEFAULT ''0'',\r\n  PRIMARY KEY (`idm`)\r\n) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;" );\r\n\r\n\r\nmysql_query( "CREATE TABLE IF NOT EXISTS ".$modx->getFullTableName( ''aaa_''. $tb_3 )." (\r\n  `idm` int(10) NOT NULL AUTO_INCREMENT,\r\n  `id` int(10) NOT NULL,\r\n  `name` varchar(50) NOT NULL DEFAULT '''',\r\n  `description` varchar(255) NOT NULL DEFAULT ''Snippet'',\r\n  `editor_type` int(11) NOT NULL DEFAULT ''0'' COMMENT ''0-plain text,1-rich text,2-code editor'',\r\n  `category` int(11) NOT NULL DEFAULT ''0'' COMMENT ''category id'',\r\n  `cache_type` tinyint(1) NOT NULL DEFAULT ''0'' COMMENT ''Cache option'',\r\n  `snippet` mediumtext,\r\n  `locked` tinyint(4) NOT NULL DEFAULT ''0'',\r\n  `properties` text COMMENT ''Default Properties'',\r\n  `moduleguid` varchar(32) NOT NULL DEFAULT '''' COMMENT ''GUID of module from which to import shared parameters'',\r\n  PRIMARY KEY (`idm`)\r\n) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;" );\r\n\r\n\r\nmysql_query( "CREATE TABLE IF NOT EXISTS ".$modx->getFullTableName( ''aaa_''. $tb_4 )." (\r\n  `idm` int(10) NOT NULL AUTO_INCREMENT,\r\n  `id` int(10) NOT NULL,\r\n  `templatename` varchar(50) NOT NULL DEFAULT '''',\r\n  `description` varchar(255) NOT NULL DEFAULT ''Template'',\r\n  `editor_type` int(11) NOT NULL DEFAULT ''0'' COMMENT ''0-plain text,1-rich text,2-code editor'',\r\n  `category` int(11) NOT NULL DEFAULT ''0'' COMMENT ''category id'',\r\n  `icon` varchar(255) NOT NULL DEFAULT '''' COMMENT ''url to icon file'',\r\n  `template_type` int(11) NOT NULL DEFAULT ''0'' COMMENT ''0-page,1-content'',\r\n  `content` mediumtext,\r\n  `locked` tinyint(4) NOT NULL DEFAULT ''0'',\r\n  `selectable` tinyint(4) NOT NULL DEFAULT ''1'',\r\n  PRIMARY KEY (`idm`)\r\n) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;" );\r\n\r\n$e= &$modx->Event;\r\n$mid= $e->params[ ''id'' ];\r\n\r\nif( $e->name == "OnBeforeDocFormSave" || $e->name == "OnBeforeDocFormDelete" ) // СТРАНИЦЫ\r\n{\r\n	mysql_query( "INSERT INTO ".$modx->getFullTableName( ''aaa_''. $tb_1 )."\r\n		( `id`,`type`,`contentType`,`pagetitle`,`longtitle`,`description`,`alias`,\r\n		`link_attributes`,`published`,`pub_date`,`unpub_date`,`parent`,`isfolder`,`introtext`,\r\n		`content`,`richtext`,`template`,`menuindex`,`searchable`,`cacheable`,`createdby`,\r\n		`createdon`,`editedby`,`editedon`,`deleted`,`deletedon`,`deletedby`,`publishedon`,\r\n		`publishedby`,`menutitle`,`donthit`,`haskeywords`,`hasmetatags`,`privateweb`,`privatemgr`,`content_dispo`,`hidemenu`,`alias_visible` )\r\n			SELECT * FROM ".$modx->getFullTableName( $tb_1 )." WHERE id={$mid} LIMIT 1" );\r\n	\r\n	$rr= mysql_query( "SELECT id FROM ".$modx->getFullTableName( $tb_6 )." ORDER BY id" );\r\n	\r\n	if( $rr && mysql_num_rows( $rr ) > 0 )\r\n	{\r\n		while( $row= mysql_fetch_assoc( $rr ) )\r\n		{\r\n			mysql_query( "INSERT INTO ".$modx->getFullTableName( ''aaa_''. $tb_5 )." ( `id`, `tmplvarid`, `contentid`, `value` )\r\n				SELECT * FROM ".$modx->getFullTableName( $tb_5 )." WHERE contentid={$mid} AND tmplvarid={$row[id]}" );\r\n		}\r\n	}\r\n//----------------------------\r\n	\r\n}elseif( $e->name == "OnBeforeChunkFormSave" || $e->name == "OnBeforeChunkFormDelete" ){ // ЧАНКИ\r\n	mysql_query( "INSERT INTO ".$modx->getFullTableName( ''aaa_''. $tb_2 )." ( `id`,`name`,`description`,`editor_type`,`editor_name`,`category`,`cache_type`,`snippet`,`locked` )\r\n		SELECT * FROM ".$modx->getFullTableName( $tb_2 )." WHERE id={$mid} LIMIT 1" );\r\n//----------------------------\r\n	\r\n}elseif( $e->name == "OnBeforeSnipFormSave" || $e->name == "OnBeforeSnipFormDelete" ){ // СНИППЕТЫ\r\n	mysql_query( "INSERT INTO ".$modx->getFullTableName( ''aaa_''. $tb_3 )." ( `id`,`name`,`description`,`editor_type`,`category`,`cache_type`,`snippet`,`locked`,`properties`,`moduleguid` )\r\n		SELECT * FROM ".$modx->getFullTableName( $tb_3 )." WHERE id={$mid} LIMIT 1" );\r\n//----------------------------\r\n	\r\n}elseif( $e->name == "OnBeforeTempFormSave" || $e->name == "OnBeforeTempFormDelete" ){ // ШАБЛОНЫ\r\n	mysql_query( "INSERT INTO ".$modx->getFullTableName( ''aaa_''. $tb_4 )." ( `id`,`templatename`,`description`,`editor_type`,`category`,`icon`,`template_type`,`content`,`locked`,`selectable` )\r\n		SELECT * FROM ".$modx->getFullTableName( $tb_4 )." WHERE id={$mid} LIMIT 1" );\r\n}', 0, '', 0, ' '),
(12, 'Highslide', 'v001', 0, 0, 0, '//v001\r\n//26.05.2016\r\n//Highslide\r\n//Event: OnWebPagePrerender\r\n//Snippet: ImgCrop71\r\n//<a class="highslide" onclick="return hs.expand(this)" href><img class="highslidezoom" /></a>\r\n//======================================================================================\r\n$html= $modx->documentOutput;\r\nif( true || isset( $_GET[ ''test'' ] ) )\r\n{\r\n	preg_match_all( ''/<img(.*)class="(.*)highslidezoom(.*)"(.*)>/imU'', $html, $result );\r\n	\r\n	if( $result )\r\n	{\r\n		foreach( $result[ 0 ] AS $row )\r\n		{\r\n			preg_match_all( ''/src="(.*)"/imU'', $row, $src );\r\n			$img= $modx->runSnippet( ''ImgCrop71'', array( ''img''=>$src[ 1 ][ 0 ], ''wm''=>true ) );\r\n			$row2= str_replace( $src[ 1 ][ 0 ], $img, $row );\r\n			if( $src[ 1 ] ) $html= str_replace( $row, ''<a class="highslide" onclick="return hs.expand(this)" href="''. $img .''">''. $row2 .''</a>'', $html );\r\n		}\r\n	}\r\n}\r\n$modx->documentOutput= $html;', 0, '', 0, ' ');

-- --------------------------------------------------------

--
-- Структура таблицы `ms_site_plugin_events`
--

CREATE TABLE IF NOT EXISTS `ms_site_plugin_events` (
  `pluginid` int(10) NOT NULL,
  `evtid` int(10) NOT NULL DEFAULT '0',
  `priority` int(10) NOT NULL DEFAULT '0' COMMENT 'determines plugin run order',
  PRIMARY KEY (`pluginid`,`evtid`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='Links to system events';

--
-- Дамп данных таблицы `ms_site_plugin_events`
--

INSERT INTO `ms_site_plugin_events` (`pluginid`, `evtid`, `priority`) VALUES
(1, 23, 0),
(1, 29, 0),
(1, 35, 0),
(1, 41, 0),
(1, 47, 0),
(1, 73, 0),
(2, 80, 0),
(2, 81, 0),
(2, 93, 0),
(3, 34, 0),
(3, 35, 0),
(3, 36, 0),
(3, 40, 0),
(3, 41, 0),
(3, 42, 0),
(4, 28, 0),
(4, 29, 0),
(4, 30, 0),
(4, 31, 0),
(4, 35, 0),
(4, 53, 0),
(4, 205, 0),
(5, 3, 0),
(5, 13, 0),
(5, 28, 0),
(5, 31, 0),
(5, 92, 0),
(6, 3, 0),
(7, 85, 0),
(7, 87, 0),
(7, 88, 0),
(8, 100, 0),
(9, 90, 1),
(9, 3, 1),
(10, 3, 2),
(11, 26, 1),
(11, 24, 1),
(11, 32, 1),
(11, 30, 1),
(11, 44, 1),
(11, 42, 1),
(11, 50, 1),
(11, 48, 1),
(12, 3, 3);

-- --------------------------------------------------------

--
-- Структура таблицы `ms_site_snippets`
--

CREATE TABLE IF NOT EXISTS `ms_site_snippets` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT 'Snippet',
  `editor_type` int(11) NOT NULL DEFAULT '0' COMMENT '0-plain text,1-rich text,2-code editor',
  `category` int(11) NOT NULL DEFAULT '0' COMMENT 'category id',
  `cache_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Cache option',
  `snippet` mediumtext,
  `locked` tinyint(4) NOT NULL DEFAULT '0',
  `properties` text COMMENT 'Default Properties',
  `moduleguid` varchar(32) NOT NULL DEFAULT '' COMMENT 'GUID of module from which to import shared parameters',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 COMMENT='Contains the site snippets.' AUTO_INCREMENT=44 ;

--
-- Дамп данных таблицы `ms_site_snippets`
--

INSERT INTO `ms_site_snippets` (`id`, `name`, `description`, `editor_type`, `category`, `cache_type`, `snippet`, `locked`, `properties`, `moduleguid`) VALUES
(1, 'DocLister', '<strong>2.1.30</strong> Snippet to display the information of the tables by the description rules. The main goal - replacing Ditto and CatalogView', 0, 4, 0, 'return require MODX_BASE_PATH.''assets/snippets/DocLister/snippet.DocLister.php'';', 0, '', ''),
(2, 'AjaxSearch', '<strong>1.10.1</strong> Ajax and non-Ajax search that supports results highlighting', 0, 3, 0, 'return require MODX_BASE_PATH.''assets/snippets/ajaxSearch/snippet.ajaxSearch.php'';', 0, '', ''),
(3, 'Breadcrumbs', '<strong>1.0.5</strong> Configurable breadcrumb page-trail navigation', 0, 5, 0, 'return require MODX_BASE_PATH.''assets/snippets/breadcrumbs/snippet.breadcrumbs.php'';', 0, '', ''),
(4, 'Ditto', '<strong>2.1.1</strong> Summarizes and lists pages to create blogs, catalogs, PR archives, bio listings and more', 0, 4, 0, 'return require MODX_BASE_PATH.''assets/snippets/ditto/snippet.ditto.php'';', 0, '', ''),
(5, 'eForm', '<strong>1.4.6</strong> Robust form parser/processor with validation, multiple sending options, chunk/page support for forms and reports, and file uploads', 0, 6, 0, 'return require MODX_BASE_PATH.''assets/snippets/eform/snippet.eform.php'';', 0, '', ''),
(6, 'FirstChildRedirect', '<strong>2.0</strong> Automatically redirects to the first child of a Container Resource', 0, 5, 0, 'return require MODX_BASE_PATH.''assets/snippets/firstchildredirect/snippet.firstchildredirect.php'';', 0, '', ''),
(7, 'if', '<strong>1.2</strong> A simple conditional snippet. Allows for eq/neq/lt/gt/etc logic within templates, resources, chunks, etc.', 0, 5, 0, 'return require MODX_BASE_PATH.''assets/snippets/if/snippet.if.php'';', 0, '', ''),
(8, 'Jot', '<strong>1.1.4</strong> User comments with moderation and email subscription', 0, 4, 0, '/*####\n#\n# Author: Armand "bS" Pondman (apondman@zerobarrier.nl)\n#\n# Latest Version: http://modx.com/extras/package/jot\n# Jot Demo Site: http://projects.zerobarrier.nl/modx/\n# Documentation: http://wiki.modxcms.com/index.php/Jot (wiki)\n#\n####*/\n\n$jotPath = $modx->config[''base_path''] . ''assets/snippets/jot/'';\ninclude_once($jotPath.''jot.class.inc.php'');\n\n$Jot = new CJot;\n$Jot->VersionCheck("1.1.4");\n$Jot->Set("path",$jotPath);\n$Jot->Set("action", $action);\n$Jot->Set("postdelay", $postdelay);\n$Jot->Set("docid", $docid);\n$Jot->Set("tagid", $tagid);\n$Jot->Set("subscribe", $subscribe);\n$Jot->Set("moderated", $moderated);\n$Jot->Set("captcha", $captcha);\n$Jot->Set("badwords", $badwords);\n$Jot->Set("bw", $bw);\n$Jot->Set("sortby", $sortby);\n$Jot->Set("numdir", $numdir);\n$Jot->Set("customfields", $customfields);\n$Jot->Set("guestname", $guestname);\n$Jot->Set("canpost", $canpost);\n$Jot->Set("canview", $canview);\n$Jot->Set("canedit", $canedit);\n$Jot->Set("canmoderate", $canmoderate);\n$Jot->Set("trusted", $trusted);\n$Jot->Set("pagination", $pagination);\n$Jot->Set("placeholders", $placeholders);\n$Jot->Set("subjectSubscribe", $subjectSubscribe);\n$Jot->Set("subjectModerate", $subjectModerate);\n$Jot->Set("subjectAuthor", $subjectAuthor);\n$Jot->Set("notify", $notify);\n$Jot->Set("notifyAuthor", $notifyAuthor);\n$Jot->Set("validate", $validate);\n$Jot->Set("title", $title);\n$Jot->Set("authorid", $authorid);\n$Jot->Set("css", $css);\n$Jot->Set("cssFile", $cssFile);\n$Jot->Set("cssRowAlt", $cssRowAlt);\n$Jot->Set("cssRowMe", $cssRowMe);\n$Jot->Set("cssRowAuthor", $cssRowAuthor);\n$Jot->Set("tplForm", $tplForm);\n$Jot->Set("tplComments", $tplComments);\n$Jot->Set("tplModerate", $tplModerate);\n$Jot->Set("tplNav", $tplNav);\n$Jot->Set("tplNotify", $tplNotify);\n$Jot->Set("tplNotifyModerator", $tplNotifyModerator);\n$Jot->Set("tplNotifyAuthor", $tplNotifyAuthor);\n$Jot->Set("tplSubscribe", $tplSubscribe);\n$Jot->Set("debug", $debug);\n$Jot->Set("output", $output);\nreturn $Jot->Run();', 0, '', ''),
(9, 'ListIndexer', '<strong>1.0.1</strong> A flexible way to show the most recent Resources and other Resource lists', 0, 5, 0, 'return require MODX_BASE_PATH.''assets/snippets/listindexer/snippet.listindexer.php'';', 0, '', ''),
(10, 'MemberCheck', '<strong>1.1</strong> Show chunks based on a logged in Web User''s group membership', 0, 7, 0, 'return require MODX_BASE_PATH.''assets/snippets/membercheck/snippet.membercheck.php'';', 0, '', ''),
(11, 'Personalize', '<strong>2.1</strong> Personalize snippet', 0, 7, 0, 'return require MODX_BASE_PATH.''assets/snippets/personalize/snippet.personalize.php'';', 0, '', ''),
(12, 'phpthumb', '<strong>1.2</strong> PHPThumb creates thumbnails and altered images on the fly and caches them', 0, 4, 0, 'return require MODX_BASE_PATH.''assets/snippets/phpthumb/snippet.phpthumb.php'';\r\n', 0, '', ''),
(13, 'Reflect', '<strong>2.1.1</strong> Generates date-based archives using Ditto', 0, 4, 0, '/*\n * Author: \n *      Mark Kaplan for MODX CMF\n * \n * Note: \n *      If Reflect is not retrieving its own documents, make sure that the\n *          Ditto call feeding it has all of the fields in it that you plan on\n *       calling in your Reflect template. Furthermore, Reflect will ONLY\n *          show what is currently in the Ditto result set.\n *       Thus, if pagination is on it will ONLY show that page''s items.\n*/\n \n\n// ---------------------------------------------------\n//  Includes\n// ---------------------------------------------------\n\n$reflect_base = isset($reflect_base) ? $modx->config[''base_path''].$reflect_base : $modx->config[''base_path'']."assets/snippets/reflect/";\n/*\n    Param: ditto_base\n    \n    Purpose:\n    Location of Ditto files\n\n    Options:\n    Any valid folder location containing the Ditto source code with a trailing slash\n\n    Default:\n    [(base_path)]assets/snippets/ditto/\n*/\n\n$config = (isset($config)) ? $config : "default";\n/*\n    Param: config\n\n    Purpose:\n    Load a custom configuration\n\n    Options:\n    "default" - default blank config file\n    CONFIG_NAME - Other configs installed in the configs folder or in any folder within the MODX base path via @FILE\n\n    Default:\n    "default"\n    \n    Related:\n    - <extenders>\n*/\n\nrequire($reflect_base."configs/default.config.php");\nrequire($reflect_base."default.templates.php");\nif ($config != "default") {\n    require((substr($config, 0, 5) != "@FILE") ? $reflect_base."configs/$config.config.php" : $modx->config[''base_path''].trim(substr($config, 5)));\n}\n\n// ---------------------------------------------------\n//  Parameters\n// ---------------------------------------------------\n\n$id = isset($id) ? $id."_" : false;\n/*\n    Param: id\n\n    Purpose:\n    Unique ID for this Ditto instance for connection with other scripts (like Reflect) and unique URL parameters\n\n    Options:\n    Any valid folder location containing the Ditto source code with a trailing slash\n\n    Default:\n    "" - blank\n*/\n$getDocuments = isset($getDocuments) ? $getDocuments : 0;\n/*\n    Param: getDocuments\n\n    Purpose:\n    Force Reflect to get documents\n\n    Options:\n    0 - off\n    1 - on\n    \n    Default:\n    0 - off\n*/\n$showItems = isset($showItems) ? $showItems : 1;\n/*\n    Param: showItems\n\n    Purpose:\n    Show individual items in the archive\n\n    Options:\n    0 - off\n    1 - on\n    \n    Default:\n    1 - on\n*/\n$groupByYears = isset($groupByYears)? $groupByYears : 1;\n/*\n    Param: groupByYears\n\n    Purpose:\n    Group the archive by years\n\n    Options:\n    0 - off\n    1 - on\n    \n    Default:\n    1 - on\n*/\n$targetID = isset($targetID) ? $targetID : $modx->documentObject[''id''];\n/*\n    Param: targetID\n\n    Purpose:\n    ID for archive links to point to\n\n    Options:\n    Any MODX document with a Ditto call setup with extenders=`dateFilter`\n    \n    Default:\n    Current MODX Document\n*/\n$dateSource = isset($dateSource) ? $dateSource : "createdon";\n/*\n    Param: dateSource\n\n    Purpose:\n    Date source to display for archive items\n\n    Options:\n    # - Any UNIX timestamp from MODX fields or TVs such as createdon, pub_date, or editedon\n    \n    Default:\n    "createdon"\n    \n    Related:\n    - <dateFormat>\n*/\n$dateFormat = isset($dateFormat) ? $dateFormat : "%d-%b-%y %H:%M";  \n/*\n    Param: dateFormat\n\n    Purpose:\n    Format the [+date+] placeholder in human readable form\n\n    Options:\n    Any PHP valid strftime option\n\n    Default:\n    "%d-%b-%y %H:%M"\n    \n    Related:\n    - <dateSource>\n*/\n$yearSortDir = isset($yearSortDir) ? $yearSortDir : "DESC";\n/*\n    Param: yearSortDir\n\n    Purpose:\n    Direction to sort documents\n\n    Options:\n    ASC - ascending\n    DESC - descending\n\n    Default:\n    "DESC"\n    \n    Related:\n    - <monthSortDir>\n*/\n$monthSortDir = isset($monthSortDir) ? $monthSortDir : "ASC";\n/*\n    Param: monthSortDir\n\n    Purpose:\n    Direction to sort the months\n\n    Options:\n    ASC - ascending\n    DESC - descending\n\n    Default:\n    "ASC"\n    \n    Related:\n    - <yearSortDir>\n*/\n$start = isset($start)? intval($start) : 0;\n/*\n    Param: start\n\n    Purpose:\n    Number of documents to skip in the results\n    \n    Options:\n    Any number\n\n    Default:\n    0\n*/  \n$phx = (isset($phx))? $phx : 1;\n/*\n    Param: phx\n\n    Purpose:\n    Use PHx formatting\n\n    Options:\n    0 - off\n    1 - on\n    \n    Default:\n    1 - on\n*/\n$emptymsg = isset($emptymsg)? $emptymsg : "The Ditto object is invalid. Please check it.";\n/*\n    Param: emptymsg\n\n    Purpose:\n    Message to return if error\n\n    Options:\n    Any string\n    \n    Default:\n    The Ditto object is invalid. Please check it.\n*/\n\n// ---------------------------------------------------\n//  Initialize Ditto\n// ---------------------------------------------------\n$placeholder = ($id != false && $getDocuments == 0) ? true : false;\nif ($placeholder === false) {\n    $rID = "reflect_".rand(1,1000);\n    $itemTemplate = isset($tplItem) ? $tplItem: "@CODE:".$defaultTemplates[''item''];\n    $dParams = array(\n        "id" => "$rID",\n        "save" => "3",  \n        "summarize" => "all",\n        "tpl" => $itemTemplate,\n    );\n    \n    $source = $dittoSnippetName;\n    $params = $dittoSnippetParameters;\n        // TODO: Remove after 3.0\n        \n    if (isset($params)) {\n        $givenParams = explode("|",$params);\n        foreach ($givenParams as $parameter) {\n            $p = explode(":",$parameter);\n            $dParams[$p[0]] = $p[1];\n        }\n    }\n    /*\n        Param: params\n\n        Purpose:\n        Pass parameters to the Ditto instance used to retreive the documents\n\n        Options:\n        Any valid ditto parameters in the format name:value \n        with multiple parameters separated by a pipe (|)\n        \n        Note:\n        This parameter is only needed for config, start, and phx as you can\n        now simply use the parameter as if Reflect was Ditto\n\n        Default:\n        [NULL]\n    */\n    \n    $reflectParameters = array(''reflect_base'',''config'',''id'',''getDocuments'',''showItems'',''groupByYears'',''targetID'',''yearSortDir'',''monthSortDir'',''start'',''phx'',''tplContainer'',''tplYear'',''tplMonth'',''tplMonthInner'',''tplItem'',''save'');\n    $params =& $modx->event->params;\n    if(is_array($params)) {\n        foreach ($params as $param=>$value) {\n            if (!in_array($param,$reflectParameters) && substr($param,-3) != ''tpl'') {\n                $dParams[$param] = $value;\n            }\n        }\n    }\n\n    $source = isset($source) ? $source : "Ditto";\n    /*\n        Param: source\n\n        Purpose:\n        Name of the Ditto snippet to use\n\n        Options:\n        Any valid snippet name\n\n        Default:\n        "Ditto"\n    */\n    $snippetOutput = $modx->runSnippet($source,$dParams);\n    $ditto = $modx->getPlaceholder($rID."_ditto_object");\n    $resource = $modx->getPlaceholder($rID."_ditto_resource");\n} else {\n    $ditto = $modx->getPlaceholder($id."ditto_object");\n    $resource = $modx->getPlaceholder($id."ditto_resource");\n}\nif (!is_object($ditto) || !isset($ditto) || !isset($resource)) {\n    return !empty($snippetOutput) ? $snippetOutput : $emptymsg;\n}\n\n// ---------------------------------------------------\n//  Templates\n// ---------------------------------------------------\n\n$templates[''tpl''] = isset($tplContainer) ? $ditto->template->fetch($tplContainer): $defaultTemplates[''tpl''];\n/*\n    Param: tplContainer\n\n    Purpose:\n    Container template for the archive\n\n    Options:\n    - Any valid chunk name\n    - Code via @CODE:\n    - File via @FILE:\n\n    Default:\n    See default.tempates.php\n*/\n$templates[''year''] = isset($tplYear) ? $ditto->template->fetch($tplYear): $defaultTemplates[''year''];\n/*\n    Param: tplYear\n\n    Purpose:\n    Template for the year item\n\n    Options:\n    - Any valid chunk name\n    - Code via @CODE:\n    - File via @FILE:\n\n    Default:\n    See default.tempates.php\n*/\n$templates[''year_inner''] = isset($tplYearInner) ? $ditto->template->fetch($tplYearInner): $defaultTemplates[''year_inner''];\n/*\n    Param: tplYearInner\n\n    Purpose:\n    Template for the year item (the ul to hold the year template)\n\n    Options:\n    - Any valid chunk name\n    - Code via @CODE:\n    - File via @FILE:\n\n    Default:\n    See default.tempates.php\n*/\n$templates[''month''] = isset($tplMonth) ? $ditto->template->fetch($tplMonth): $defaultTemplates[''month''];\n/*\n    Param: tplMonth\n\n    Purpose:\n    Template for the month item\n\n    Options:\n    - Any valid chunk name\n    - Code via @CODE:\n    - File via @FILE:\n\n    Default:\n    See default.tempates.php\n*/\n$templates[''month_inner''] = isset($tplMonthInner) ? $ditto->template->fetch($tplMonthInner): $defaultTemplates[''month_inner''];\n/*\n    Param: tplMonthInner\n\n    Purpose:\n    Template for the month item  (the ul to hold the month template)\n\n    Options:\n    - Any valid chunk name\n    - Code via @CODE:\n    - File via @FILE:\n\n    Default:\n    See default.tempates.php\n*/\n$templates[''item''] = isset($tplItem) ? $ditto->template->fetch($tplItem): $defaultTemplates[''item''];\n/*\n    Param: tplItem\n\n    Purpose:\n    Template for the individual item\n\n    Options:\n    - Any valid chunk name\n    - Code via @CODE:\n    - File via @FILE:\n\n    Default:\n    See default.tempates.php\n*/\n\n$ditto->addField("date","display","custom");\n    // force add the date field if receiving data from a Ditto instance\n\n// ---------------------------------------------------\n//  Reflect\n// ---------------------------------------------------\n\nif (function_exists("reflect") === FALSE) {\nfunction reflect($templatesDocumentID, $showItems, $groupByYears, $resource, $templatesDateSource, $dateFormat, $ditto, $templates,$id,$start,$yearSortDir,$monthSortDir) {\n    global $modx;\n    $cal = array();\n    $output = '''';\n    $ph = array(''year''=>'''',''month''=>'''',''item''=>'''',''out''=>'''');\n    $build = array();\n    $stop = count($resource);\n\n    // loop and fetch all the results\n    for ($i = $start; $i < $stop; $i++) {\n        $date = getdate($resource[$i][$templatesDateSource]);\n        $year = $date["year"];\n        $month = $date["mon"];\n        $cal[$year][$month][] = $resource[$i];\n    }\n    if ($yearSortDir == "DESC") {\n        krsort($cal);\n    } else {\n        ksort($cal);\n    }\n    foreach ($cal as $year=>$months) {\n        if ($monthSortDir == "ASC") {\n            ksort($months);\n        } else {\n            krsort($months);\n        }\n        $build[$year] = $months;\n    }\n    \n    foreach ($build as $year=>$months) {\n        $r_year = '''';\n        $r_month = '''';\n        $r_month_2 = '''';\n        $year_count = 0;\n        $items = array();\n        \n        foreach ($months as $mon=>$month) {\n            $month_text = strftime("%B", mktime(10, 10, 10, $mon, 10, $year));\n            $month_url = $ditto->buildURL("month=".$mon."&year=".$year."&day=false&start=0",$templatesDocumentID,$id);\n            $month_count = count($month);\n            $year_count += $month_count;\n            $r_month = $ditto->template->replace(array("year"=>$year,"month"=>$month_text,"url"=>$month_url,"count"=>$month_count),$templates[''month'']);\n            if ($showItems) {\n                foreach ($month as $item) {\n                    $items[$year][$mon][''items''][] = $ditto->render($item, $templates[''item''], false, $templatesDateSource, $dateFormat, array(),$phx);\n                }\n                $r_month_2 = $ditto->template->replace(array(''wrapper'' => implode('''',$items[$year][$mon][''items''])),$templates[''month_inner'']);\n                $items[$year][$mon] = $ditto->template->replace(array(''wrapper'' => $r_month_2),$r_month);\n            } else {\n                $items[$year][$mon] = $r_month;\n            }\n        }\n        if ($groupByYears) {\n            $year_url = $ditto->buildURL("year=".$year."&month=false&day=false&start=0",$templatesDocumentID,$id);\n            $r_year =  $ditto->template->replace(array("year"=>$year,"url"=>$year_url,"count"=>$year_count),$templates[''year'']);\n            $var = $ditto->template->replace(array(''wrapper''=>implode('''',$items[$year])),$templates[''year_inner'']);\n            $output .= $ditto->template->replace(array(''wrapper''=>$var),$r_year);\n        } else {\n            $output .= implode('''',$items[$year]);\n        }\n    }\n\n    $output = $ditto->template->replace(array(''wrapper''=>$output),$templates[''tpl'']);\n    $modx->setPlaceholder($id.''reset'',$ditto->buildURL(''year=false&month=false&day=false'',$templatesDocumentID,$id));\n\nreturn $output;\n    \n}\n}\n\nreturn reflect($targetID, $showItems, $groupByYears, $resource, $dateSource, $dateFormat, $ditto, $templates,$id,$start,$yearSortDir,$monthSortDir);\n', 0, '', ''),
(14, 'UltimateParent', '<strong>2.0</strong> Travels up the document tree from a specified document and returns its "ultimate" non-root parent', 0, 5, 0, 'return require MODX_BASE_PATH.''assets/snippets/ultimateparent/snippet.ultimateparent.php'';', 0, '', ''),
(15, 'Wayfinder', '<strong>2.0.4</strong> Completely template-driven and highly flexible menu builder', 0, 5, 0, 'return require MODX_BASE_PATH.''assets/snippets/wayfinder/snippet.wayfinder.php'';\n', 0, '', ''),
(16, 'WebChangePwd', '<strong>1.0.1</strong> Allows Web User to change their password from the front-end of the website', 0, 7, 0, '# Created By Raymond Irving April, 2005\n#::::::::::::::::::::::::::::::::::::::::\n# Params:	\n#\n#	&tpl			- (Optional)\n#		Chunk name or document id to use as a template\n#				  \n#	Note: Templats design:\n#			section 1: change pwd template\n#			section 2: notification template \n#\n# Examples:\n#\n#	[[WebChangePwd? &tpl=`ChangePwd`]] \n\n# Set Snippet Paths \n$snipPath  = (($modx->isBackend())? "../":"");\n$snipPath .= "assets/snippets/";\n\n# check if inside manager\nif ($m = $modx->isBackend()) {\n	return ''''; # don''t go any further when inside manager\n}\n\n\n# Snippet customize settings\n$tpl		= isset($tpl)? $tpl:"";\n\n# System settings\n$isPostBack		= count($_POST) && isset($_POST[''cmdwebchngpwd'']);\n\n# Start processing\ninclude_once $snipPath."weblogin/weblogin.common.inc.php";\ninclude_once $snipPath."weblogin/webchangepwd.inc.php";\n\n# Return\nreturn $output;\n\n\n\n', 0, '', ''),
(17, 'WebLogin', '<strong>1.1.1</strong> Allows webusers to login to protected pages in the website, supporting multiple user groups', 0, 7, 0, '# Created By Raymond Irving 2004\n#::::::::::::::::::::::::::::::::::::::::\n# Params:	\n#\n#	&loginhomeid 	- (Optional)\n#		redirects the user to first authorized page in the list.\n#		If no id was specified then the login home page id or \n#		the current document id will be used\n#\n#	&logouthomeid 	- (Optional)\n#		document id to load when user logs out	\n#\n#	&pwdreqid 	- (Optional)\n#		document id to load after the user has submited\n#		a request for a new password\n#\n#	&pwdactid 	- (Optional)\n#		document id to load when the after the user has activated\n#		their new password\n#\n#	&logintext		- (Optional) \n#		Text to be displayed inside login button (for built-in form)\n#\n#	&logouttext 	- (Optional)\n#		Text to be displayed inside logout link (for built-in form)\n#	\n#	&tpl			- (Optional)\n#		Chunk name or document id to as a template\n#				  \n#	Note: Templats design:\n#			section 1: login template\n#			section 2: logout template \n#			section 3: password reminder template \n#\n#			See weblogin.tpl for more information\n#\n# Examples:\n#\n#	[[WebLogin? &loginhomeid=`8` &logouthomeid=`1`]] \n#\n#	[[WebLogin? &loginhomeid=`8,18,7,5` &tpl=`Login`]] \n\n# Set Snippet Paths \n$snipPath = $modx->config[''base_path''] . "assets/snippets/";\n\n# check if inside manager\nif ($m = $modx->isBackend()) {\n	return ''''; # don''t go any further when inside manager\n}\n\n# deprecated params - only for backward compatibility\nif(isset($loginid)) $loginhomeid=$loginid;\nif(isset($logoutid)) $logouthomeid = $logoutid;\nif(isset($template)) $tpl = $template;\n\n# Snippet customize settings\n$liHomeId	= isset($loginhomeid)? array_filter(array_map(''intval'', explode('','', $loginhomeid))):array($modx->config[''login_home''],$modx->documentIdentifier);\n$loHomeId	= isset($logouthomeid)? $logouthomeid:$modx->documentIdentifier;\n$pwdReqId	= isset($pwdreqid)? $pwdreqid:0;\n$pwdActId	= isset($pwdactid)? $pwdactid:0;\n$loginText	= isset($logintext)? $logintext:''Login'';\n$logoutText	= isset($logouttext)? $logouttext:''Logout'';\n$tpl		= isset($tpl)? $tpl:"";\n\n# System settings\n$webLoginMode = isset($_REQUEST[''webloginmode''])? $_REQUEST[''webloginmode'']: '''';\n$isLogOut		= $webLoginMode==''lo'' ? 1:0;\n$isPWDActivate	= $webLoginMode==''actp'' ? 1:0;\n$isPostBack		= count($_POST) && (isset($_POST[''cmdweblogin'']) || isset($_POST[''cmdweblogin_x'']));\n$txtPwdRem 		= isset($_REQUEST[''txtpwdrem''])? $_REQUEST[''txtpwdrem'']: 0;\n$isPWDReminder	= $isPostBack && $txtPwdRem==''1'' ? 1:0;\n\n$site_id = isset($site_id)? $site_id: '''';\n$cookieKey = substr(md5($site_id."Web-User"),0,15);\n\n# Start processing\ninclude_once $snipPath."weblogin/weblogin.common.inc.php";\ninclude_once ($modx->config[''site_manager_path''] . "includes/crypt.class.inc.php");\n\nif ($isPWDActivate || $isPWDReminder || $isLogOut || $isPostBack) {\n	# include the logger class\n	include_once $modx->config[''site_manager_path''] . "includes/log.class.inc.php";\n	include_once $snipPath."weblogin/weblogin.processor.inc.php";\n}\n\ninclude_once $snipPath."weblogin/weblogin.inc.php";\n\n# Return\nreturn $output;\n', 0, '&loginhomeid=Login Home Id;string; &logouthomeid=Logout Home Id;string; &logintext=Login Button Text;string; &logouttext=Logout Button Text;string; &tpl=Template;string;', ''),
(18, 'WebSignup', '<strong>1.1.1</strong> Basic Web User account creation/signup system', 0, 7, 0, '# Created By Raymond Irving April, 2005\n#::::::::::::::::::::::::::::::::::::::::\n# Usage:     \n#    Allows a web user to signup for a new web account from the website\n#    This snippet provides a basic set of form fields for the signup form\n#    You can customize this snippet to create your own signup form\n#\n# Params:    \n#\n#    &tpl        - (Optional) Chunk name or document id to use as a template\n#	    		   If custom template AND captcha on AND using WebSignup and \n#                  WebLogin on the same page make sure you have a field named\n#                  cmdwebsignup. In the default template it is the submit button \n#                  One can use a hidden field.\n#    &groups     - Web users groups to be assigned to users\n#    &useCaptcha - (Optional) Determine to use (1) or not to use (0) captcha\n#                  on signup form - if not defined, will default to system\n#                  setting. GD is required for this feature. If GD is not \n#                  available, useCaptcha will automatically be set to false;\n#                  \n#    Note: Templats design:\n#        section 1: signup template\n#        section 2: notification template \n#\n# Examples:\n#\n#    [[WebSignup? &tpl=`SignupForm` &groups=`NewsReaders,WebUsers`]] \n\n# Set Snippet Paths \n$snipPath = $modx->config[''base_path''] . "assets/snippets/";\n\n# check if inside manager\nif ($m = $modx->isBackend()) {\n    return ''''; # don''t go any further when inside manager\n}\n\n\n# Snippet customize settings\n$tpl = isset($tpl)? $tpl:"";\n$useCaptcha = isset($useCaptcha)? $useCaptcha : $modx->config[''use_captcha''] ;\n// Override captcha if no GD\nif ($useCaptcha && !gd_info()) $useCaptcha = 0;\n\n# setup web groups\n$groups = isset($groups) ? array_filter(array_map(''trim'', explode('','', $groups))):array();\n\n# System settings\n$isPostBack        = count($_POST) && isset($_POST[''cmdwebsignup'']);\n\n$output = '''';\n\n# Start processing\ninclude_once $snipPath."weblogin/weblogin.common.inc.php";\ninclude_once $snipPath."weblogin/websignup.inc.php";\n\n# Return\nreturn $output;', 0, '&tpl=Template;string;', ''),
(30, 'YandexMap', '', 0, 0, 0, '\r\n$points= $modx->runSnippet( ''PageContacts'', array( ''array''=>true ) );\r\n//return print_r($points);\r\n?>\r\n<style>#yandexmap{width:100%;height:500px;}</style>\r\n<script src="//api-maps.yandex.ru/2.1/?lang=ru_RU" type="text/javascript"></script>\r\n<div id="yandexmap"></div>\r\n<script type="text/javascript">\r\nymaps.ready(init);\r\nvar yandexmap;\r\nfunction init(){\r\n    yandexmap= new ymaps.Map( ''yandexmap'',\r\n        {\r\n            center: [47.23107859368434,39.722849411069355],\r\n            zoom: 11,\r\n        }\r\n    );\r\n	\r\n	yandexmap.geoObjects\r\n	<?php\r\nforeach( $points AS $row )\r\n{\r\n	$info= '''';\r\n	foreach( $row AS $row2 )\r\n	{\r\n		//if( $row2[''left''] == ''Адрес:'' ) $address= $row2[''left''] .'' ''. $row2[''right''];\r\n		if( $row2[''type''] != 7 && $row2[''type''] != 8 ) $info .= $row2[''left''] .'' ''. $row2[''right''] .''<br />'';\r\n		if( $row2[''type''] != 8 ) continue;\r\n		print ''.add(new ymaps.Placemark(''.$row2[''right''].'',{\r\n			balloonContent: "''.addslashes($info).''"\r\n		},{\r\n			preset: "islands#dotIcon",\r\n			iconColor: "#18277C"\r\n		}))'';\r\n	}\r\n}\r\n	?>\r\n	;\r\n}\r\n</script>\r\n<?php\r\n//\r\n', 0, '', ' '),
(20, 'PageContacts', '', 0, 0, 0, '\r\n//v045\r\n//PageContacts\r\n//07.07.2016\r\n//=====================================================================================\r\n$print .= ''<link rel="stylesheet" type="text/css" href="template/css/pagecontacts.css" />'';\r\nif( $blocks )\r\n{\r\n	$blocks_qq= "";\r\n	$blocks= explode( '','', $blocks );\r\n	foreach( $blocks AS $row )\r\n	{\r\n		$blocks_qq .= ( ! empty( $blocks_qq ) ? " OR " : "" ) ."block=". intval($row);\r\n	}\r\n}\r\n$rr= mysql_query( "SELECT * FROM ".$modx->getFullTableName( ''page_contacts'' )." ".( $blocks_qq ? "WHERE ".$blocks_qq : "" )." ORDER BY block, `index`" );\r\nif( $rr && mysql_num_rows( $rr ) > 0 )\r\n{\r\n	$block= 0;\r\n	$ii= 0;\r\n	while( $row= mysql_fetch_assoc( $rr ) )\r\n	{\r\n		if( $row[ ''block'' ] && $row[ ''block'' ] != $block )\r\n		{\r\n			if( $onlymain ) break;\r\n			\r\n			$ii++;\r\n			if( $block ) $print .= ''</div>''; // закрываем предыдущий BLOCK\r\n			$block= $row[ ''block'' ];\r\n			if( $ii%2!=0 ) $print .= ''<div class="clr">&nbsp;</div>'';\r\n			$print .= ''<div class="cont_block cont_block_''. $block .'' ''.( $ii%2==0 ? ''cont_block_alt'' : '''' ).''">''; // открываем новый BLOCK\r\n		}\r\n		\r\n		if( $onlyblock && ! $block ) continue;\r\n		\r\n		if( $array )\r\n		{\r\n			$result_array[ $row[''block''] ][]= $row;\r\n			continue;\r\n		}\r\n		\r\n		if( $row[ ''type'' ] == 7 )\r\n		{\r\n			$print .= ''<div class="cont_img"><a class="highslide" onclick="return hs.expand(this)" href="''. $row[ ''right'' ] .''"><img src="''.$modx->runSnippet( ''ImgCrop6'', array( ''img''=>$row[ ''right'' ], ''w''=>90, ''h''=>90, ''fill''=>true, ''ellipse''=>''max'', ''degstep''=>15, ''dopimg''=>''template/images/kruzhok1.png'', ''dopimg_xy''=>''0:0'' ) ).''" /></a></div>'';\r\n			\r\n		}elseif( $row[ ''type'' ] == 8 ){\r\n			\r\n		}elseif( $row[ ''type'' ] != 3 ){\r\n			$print .= ''<div class="cont_1">''. $row[ ''left'' ] .''</div>'';\r\n			\r\n			$print .= ''<div class="cont_2 ''.( $row[ ''br'' ] == ''1'' ? ''cont_br'' : '''' ).''" ''.( $row[ ''type'' ] == ''4'' ? ''style="font-size: 24px;"'' : '''' ).'' ''.( $row[ ''type'' ] == ''6'' ? ''style="font-weight:bold;"'' : '''' ).''>'';\r\n			\r\n			if( $row[ ''type'' ] == 1 || $row[ ''type'' ] == 4 || $row[ ''type'' ] == 6 ) $print .= $row[ ''right'' ];\r\n			if( $row[ ''type'' ] == 2 ) $print .= ''<a class="as1 padd2" target="_blank" href="mailto:''. $row[ ''right'' ] .''">''. $row[ ''right'' ] .''</a>'';\r\n			if( $row[ ''type'' ] == 5 ) $print .= ''<h3>''. $row[ ''right'' ] .''</h3>'';\r\n			\r\n			$print .= ''</div><div class="clr">&nbsp;</div>'';\r\n			\r\n		}else{\r\n			$print .= ''<br /><div class="map">''. $row[ ''right'' ] .''</div>'';\r\n			if( $row[ ''br'' ] == ''1'' ) $print .= ''<br /><br />'';\r\n		}\r\n	}\r\n	if( $block ) $print .= ''</div><div class="clr">&nbsp;</div>''; // закрываем последний BLOCK\r\n}\r\nif( $array ) return $result_array;\r\nreturn $print;\r\n', 0, '', ' '),
(21, 'SuperPuperForms', 'v003', 0, 0, 0, '\r\n//SuperPuperForms\r\n//v003\r\n//===============================================================================\r\n/*\r\n&form=`2`\r\n&popup=`1;2`\r\n&class=`className1;className21,className22`\r\n[!SuperPuperForms? &form=`2`!]\r\n[!SuperPuperForms? &popup=`1;2` &class=`className1;className21,className22`!]\r\n*/\r\n//\r\n//\r\n//\r\n//\r\n//\r\n//\r\n//===============================================================================\r\n$js= ''template/js/superpuperforms/superpuperforms.js''; // Путь к файлу JS\r\n$css= ''template/js/superpuperforms/superpuperforms.css''; // Путь к файлу CSS\r\n$telefonchik__flag= true; // Прыгающий телефончик\r\n$veriword__flag[ 1 ]= true; // Captcha 1-й формы\r\n$veriword__flag[ 2 ]= true; // Captcha 2-й формы\r\n//===============================================================================\r\n//smtp//mail//default//\r\n$mailtype= ''smtp'';\r\n\r\n//КОМУ (через запятую)\r\n$mailto= ''sergey.it7@gmail.com'';\r\n\r\n//Видимые копии (через запятую)\r\n$mailcc= false;\r\n\r\n//Скрытые копии (через запятую)\r\n$mailbcc= false;\r\n\r\n//ОТ (если SMTP, то это поле - логин)\r\n$mailfrom= ''feedback.noreply@yandex.ru'';\r\n\r\n//Пароль от почты (если SMTP)\r\n$mailpassw= ''XSbKjp7ZjdoaesD_o_0j'';\r\n//Любимый киногерой: JXosI6J30_Qy_gINenXh //Секретный вопрос от почты\r\n\r\n//Сервер SMTP (если SMTP)\r\n$smtp= ''smtp.yandex.ru'';\r\n\r\n//Порт SMTP (если SMTP)\r\n$smtpport= 465;\r\n\r\n//SNIPPET SuperPuperForms //SNIPPET BasketOrder //MODULE scorn_orders //SNIPPET _LK_Restore_Password //SNIPPET _LK_Reg //MODULE scorn_subscription\r\n//===============================================================================\r\n//\r\n//\r\n//\r\n//\r\n//\r\n//\r\n//\r\n//\r\n//\r\n//\r\n//===============================================================================\r\ninclude_once( MODX_MANAGER_PATH .''includes/controls/class.phpmailer.php'' );\r\n$popup= explode( '';'', $popup );\r\n$class= explode( '';'', $class );\r\nif( $popup ) foreach( $popup AS $key => $row ) if( intval( trim( $row ) ) ) $popup_forms[ intval( trim( $row ) ) ]= trim( $class[ $key ] );\r\n$form= intval( trim( $form ) );\r\nif( $form ) $form_flag= true;\r\n//===============================================================================\r\n\r\nif( $_GET[ ''act'' ] == ''superpuperforms_captcha'' )\r\n{\r\n	print ''{"result":"ok","text":"template/js/superpuperforms/dmt_captcha/veriword.php?id=''. addslashes( $_GET[ ''dmtcaptchaid'' ] ) .''"}'';\r\n	if( isset( $_GET[ ''ajax'' ] ) ){ exit(); }\r\n}\r\nif( $_GET[ ''act'' ] == ''superpuperforms_send'' )\r\n{\r\n	$spfs_formid= intval( $_POST[ ''spfs_formid'' ] );\r\n	$spfs_name= addslashes( trim( $_POST[ ''spfs_name'' ] ) );\r\n	$spfs_email= addslashes( trim( $_POST[ ''spfs_email'' ] ) );\r\n	$spfs_phone= addslashes( trim( $_POST[ ''spfs_phone'' ] ) );\r\n	$spfs_kogda= addslashes( trim( $_POST[ ''spfs_kogda'' ] ) );\r\n	$spfs_pageid= intval( $_POST[ ''spfs_pageid'' ] );\r\n	$spfs_text= addslashes( trim( $_POST[ ''spfs_text'' ] ) );\r\n	$spfs_text2= str_replace( "\\r\\n", "<br />", $spfs_text );\r\n	\r\n	if( $veriword__flag[ $spfs_formid ] && $_POST[ ''spfs_veriword'' ] != $_SESSION[ ''DMTCaptcha'' ][ ''superpuperforms_''.$spfs_formid ] )\r\n	{\r\n		$result= ''{"result":"error","text":"Введен неверный текст с картинки!"}'';\r\n	}elseif( ! $spfs_email && ! $spfs_phone ){\r\n		$result= ''{"result":"error","text":"Необходимо указать контактные данные!"}'';\r\n	}\r\n	if( ! $result )\r\n	{\r\n		$subject= ( $spfs_formid == 2 ? ''Заказ звонка'' : ''Письмо'' ) ." с сайта www.". $_SERVER[ ''HTTP_HOST'' ];\r\n		\r\n		$message= ''<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><title>''. $subject .''</title></head><body><h2>''. $subject .''</h2>'';\r\n		\r\n		if( $spfs_pageid ) $message .= ''<p><b>Отправлено со страницы:</b> ''. $modx->makeUrl( $spfs_pageid, '''', '''', ''full'' ) .''</p>'';\r\n		\r\n		if( $spfs_name ) $message .= ''<p><b>Имя Отчество:</b> ''. $spfs_name .''</p>'';\r\n		\r\n		if( $spfs_email ) $message .= ''<p><b>E-mail:</b> ''. $spfs_email .''</p>'';\r\n		\r\n		if( $spfs_phone ) $message .= ''<p><b>Контактный телефон:</b> ''. $spfs_phone .''</p>'';\r\n		\r\n		if( $spfs_kogda ) $message .= ''<p><b>Когда позвонить?</b> ''. $spfs_kogda .''</p>'';\r\n		\r\n		$message .= ''<p><b>Дата и время сообщения:</b> ''. date( ''d.m.Y - H:i'' ) .''</p>'';\r\n		\r\n		if( $spfs_text2 ) $message .= ''<p><b>Сообщение:</b><br />''. $spfs_text2 .''</p>'';\r\n		\r\n		$message .= ''</body></html>'';\r\n\r\n// ============================================================================\r\n					if( $mailtype == ''smtp'' || $mailtype == ''mail'' )\r\n					{\r\n						$phpmailer= new PHPMailer();\r\n						if( false )\r\n						{\r\n							$phpmailer->SMTPDebug= 2;\r\n							$phpmailer->Debugoutput = ''html'';\r\n						}\r\n						if( $mailtype == ''smtp'' )\r\n						{\r\n							$phpmailer->isSMTP();\r\n							$phpmailer->Host= $smtp;\r\n							$phpmailer->Port= $smtpport;\r\n							$phpmailer->SMTPAuth= true;\r\n							$phpmailer->SMTPSecure= ''ssl'';\r\n							$phpmailer->Username= $mailfrom;\r\n							$phpmailer->Password= $mailpassw;\r\n						}\r\n						$phpmailer->CharSet= ''utf-8'';\r\n						$phpmailer->From= $mailfrom;\r\n						$phpmailer->FromName= "";\r\n						$phpmailer->isHTML( true );\r\n						$phpmailer->Subject= $subject;\r\n						$phpmailer->Body= $message;\r\n						$mailto= explode( '','', $mailto ); foreach( $mailto AS $row ) $phpmailer->addAddress( trim( $row ) );\r\n						if( $mailcc ){ $mailcc= explode( '','', $mailcc ); foreach( $mailcc AS $row ) $phpmailer->addCC( trim( $row ) ); }\r\n						if( $mailbcc ){ $mailbcc= explode( '','', $mailbcc ); foreach( $mailbcc AS $row ) $phpmailer->addBCC( trim( $row ) ); }\r\n						$phpmailer_result= $phpmailer->send();\r\n					}else{\r\n						$headers= "Content-type: text/html; charset=utf-8\\n";\r\n						$headers .= "From: <". $mailfrom .">\\n";\r\n						$phpmailer_result= mail( $mailto, $subject, $message, $headers );\r\n					}\r\n// ============================================================================	\r\n		\r\n		if( $phpmailer_result )\r\n		{\r\n			$result= ''{"result":"ok","text":"Сообщение успешно отправлено!<br />С Вами свяжется наш специалист."}'';\r\n		}else{\r\n			$result= ''{"result":"error","text":"Ошибка сервера! Повторите попытку позже."}'';\r\n		}\r\n	}\r\n	print $result;\r\n	if( isset( $_GET[ ''ajax'' ] ) ){ header( ''Content-Type:text/html; charset=UTF-8'' ); exit(); }\r\n}\r\n?>\r\n<link rel="stylesheet" type="text/css" href="<?= $css ?>" />\r\n<script type="text/javascript" src="<?= $js ?>"></script>\r\n<script type="text/javascript">\r\n(function($){$(document).ready(function(){\r\n<?php\r\n	if( ! $form_flag )\r\n	{\r\n		foreach( $popup_forms AS $formId => $className )\r\n		{\r\n			$className= str_replace( '','', '', .'', $className );\r\n			print ''$( ".''. $className .''" ).click(function(){ superpuperforms_show( ''. $formId .'' ); return false; });'';\r\n		}\r\n	}\r\n?>\r\n});})(jQuery);\r\n</script>\r\n\r\n<?php if( $telefonchik__flag && ! $form_flag ){ ?>\r\n	<div class="superpuperforms_wrapper superpuperforms_wrapper_krzhk"><div class="spfs_krzhk">&nbsp;</div></div>\r\n<?php } ?>\r\n\r\n<div class="superpuperforms_wrapper <?=( ! $form_flag ? ''superpuperforms_wrapper_popup'' : ''superpuperforms_wrapper_default'' )?>">\r\n	<?php if( ! $form_flag ){ ?>\r\n	<div class="spfs_black"><div class="spfs_white"><div class="spfs_krestik"><span>Закрыть</span></div>\r\n	<?php } ?>\r\n	\r\n	<?php if( ( $form_flag && $form == 1 ) || ( ! $form_flag && $popup_forms[ 1 ] ) ){ ?>\r\n		<div class="spfs_formwrapper spfs_formwrapper_1 <?=( ! $form_flag ? ''spfs_formwrapper_popup'' : '''' )?>" data-formid="1">\r\n			<?=( $form_flag ? ''<div class="spfs_label"> </div>'' : '''' )?><div class="spfs_tit">Напишите нам</div><div class="clr">&nbsp;</div>\r\n			<div class="spfs_result"></div>\r\n			<form action="<?= $modx->makeUrl( $modx->documentIdentifier ); ?>" method="post">\r\n				<div class="spfs_label">Имя Отчество:</div><div class="spfs_input"><input class="form_elem" type="text" name="spfs_name" /></div>\r\n				<div class="clr">&nbsp;</div>\r\n				<div class="spfs_label"><?=( $form_flag ? ''Адрес электронной почты'' : ''E-mail'' )?>:<div class="zvd">*</div></div><div class="spfs_input"><input class="form_elem" type="text" name="spfs_email" /></div>\r\n				<div class="clr">&nbsp;</div>\r\n				<div class="spfs_label">Номер телефона:<div class="zvd">*</div></div><div class="spfs_input"><input class="form_elem" type="text" name="spfs_phone" /></div>\r\n				<div class="clr">&nbsp;</div>\r\n				<div class="spfs_label">Сообщение:</div><div class="spfs_input">\r\n					<textarea class="form_elem" name="spfs_text"><?php print $mail_text;?></textarea>\r\n				</div>\r\n				<div class="clr">&nbsp;</div>\r\n				<?php if( $veriword__flag[ 1 ] ){ ?>\r\n				<div class="spfs_captcha">\r\n					<div class="spfs_label spfs_br"><img src="template/js/superpuperforms/dmt_captcha/veriword.php?id=superpuperforms_1" /><div class="spfs_change">Изменить число</div><div class="zvd">*</div></div>\r\n					<div class="spfs_input spfs_br">Введите текст с картинки:<br /><input class="form_elem" type="text" name="spfs_veriword" /></div>\r\n					<div class="clr">&nbsp;</div>\r\n				</div>\r\n				<?php } ?>\r\n				<div class="spfs_label"><div class="zvd">*</div></div><div class="spfs_input">- поля обязательные для заполнения!</div>\r\n				<div class="clr">&nbsp;</div>\r\n				<input class="spfs_pageid" type="hidden" name="spfs_pageid" value="[*id*]" />\r\n				<input type="hidden" name="spfs_formid" value="1" />\r\n				<div class="spfs_label"> </div><div class="spfs_input"><button class="spfs_submit" type="button">Отправить сообщение</button></div>\r\n				<div class="clr">&nbsp;</div>\r\n			</form>\r\n		</div>\r\n	<?php } ?>\r\n		\r\n		\r\n		\r\n		\r\n		\r\n	<?php if( ( $form_flag && $form == 2 ) || ( ! $form_flag && $popup_forms[ 2 ] ) ){ ?>\r\n		<div class="spfs_formwrapper spfs_formwrapper_2 <?=( ! $form_flag ? ''spfs_formwrapper_popup'' : '''' )?>" data-formid="2">\r\n			<?=( $form_flag ? ''<div class="spfs_label"> </div>'' : '''' )?><div class="spfs_tit">Заказ обратного звонка</div>\r\n			<div class="spfs_result"></div>\r\n			<form action="<?= $modx->makeUrl( $modx->documentIdentifier ); ?>" method="post">\r\n				<div class="spfs_label">Имя Отчество:</div><div class="spfs_input"><input class="form_elem" type="text" name="spfs_name" /></div>\r\n				<div class="clr">&nbsp;</div>\r\n				<div class="spfs_label">Номер телефона:<div class="spfs_txt">с кодом города</div></div><div class="spfs_input"><input class="form_elem" type="text" name="spfs_phone" /></div>\r\n				<div class="clr">&nbsp;</div>\r\n				<div class="spfs_label">Когда позвонить?</div><div class="spfs_input"><input class="form_elem" type="text" name="spfs_kogda" /></div>\r\n				<div class="clr">&nbsp;</div>\r\n				<?php if( $veriword__flag[ 2 ] ){ ?>\r\n				<div class="spfs_captcha">\r\n					<div class="spfs_label spfs_br"><img src="template/js/superpuperforms/dmt_captcha/veriword.php?id=superpuperforms_2" /><div class="spfs_change">Изменить число</div></div>\r\n					<div class="spfs_input spfs_br">Введите текст с картинки:<br /><input class="form_elem" type="text" name="spfs_veriword" /></div>\r\n					<div class="clr">&nbsp;</div>\r\n				</div>\r\n				<?php } ?>\r\n				<input class="spfs_pageid" type="hidden" name="spfs_pageid" value="[~[*id*]~]" />\r\n				<input type="hidden" name="spfs_formid" value="2" />\r\n				<div class="spfs_label"> </div><div class="spfs_input"><button class="spfs_submit" type="button">Отправить заявку</button></div>\r\n				<div class="clr">&nbsp;</div>\r\n			</form>\r\n		</div>\r\n	<?php } ?>\r\n		\r\n	<?php if( ! $form_flag ){ ?>\r\n	</div></div>\r\n	<?php } ?>\r\n</div>\r\n<?php\r\n//\r\n?>\r\n', 0, '', ' ');
INSERT INTO `ms_site_snippets` (`id`, `name`, `description`, `editor_type`, `category`, `cache_type`, `snippet`, `locked`, `properties`, `moduleguid`) VALUES
(22, 'Compress', 'v11', 0, 0, 0, '\r\n$varsion= ''v11'';\r\n//18.06.2016\r\n//Compress\r\n/*	&compress=true/false\r\n	&file - компрессит в filename.compress.css один файл\r\n	&files - компрессит в all.compress.css все указанные файлы\r\n	&tofile - файл, в который комперссить все указанные файлы\r\n	&print=false/true - выводить код, а не путь к файлу\r\n	&r=false/true - принудительно пересоздает компресс-файлы\r\n	&rvars=false/true - замена переменных\r\n	[!Compress? &file=`css/styles.css`!]\r\n	[!Compress? &files=`css: styles.css, catalog.css; css2: shop.css; css3/dop.css` &tofile=`css/all.compress.css`!]\r\n*/\r\n//============================================================================\r\n$strtr[ ''.css'' ]= array(\r\n);\r\n$strtr[ ''.js'' ]= array(\r\n);\r\n$pregreplace[ ''.css'' ][0]= array(\r\n	"/\\/\\*(.*)\\*\\//sU" => "",\r\n	"/[\\s]{2,}/" => " ",\r\n	"/[\\s]*([\\(\\){\\}\\[\\];:])[\\s]*/" => ''${1}'',\r\n	"/[\\s]*([,>])[\\s]*/" => ''${1}'',\r\n	"/([^0-9])0px/" => ''${1}0'',\r\n	"/;\\}/" => ''}'',\r\n);\r\n$pregreplace[ ''.css'' ][1]= array(\r\n);\r\n$pregreplace[ ''.js'' ][0]= array(\r\n	"/\\/\\/(.*)$/mU" => "",\r\n	"/\\/\\*(.*)\\*\\//sU" => "",\r\n);\r\n$pregreplace[ ''.js'' ][1]= array(\r\n	"/[\\s]{2,}/" => " ",\r\n	"/[\\s]*([\\(\\){\\}\\[\\];:])[\\s]*/" => ''${1}'',\r\n	"/[\\s]*([<,:>])[\\s]*/" => ''${1}'',\r\n	"/[\\s]*([=+!\\/-])[\\s]*/" => ''${1}'',\r\n	"/[\\s]*([?|\\*])[\\s]*/" => ''${1}'',\r\n);\r\n//============================================================================\r\nif( true )\r\n{\r\n	$slash= ( substr( ( $file ? $file : $files ), 0, 1 ) == "/" ? false : true );\r\n	$root= rtrim( MODX_BASE_PATH, "/\\\\" ) . ( $slash ? ''/'' : '''' );\r\n	if( $file )\r\n	{\r\n		$filetype= substr( $file, strrpos( $file, ''.'' ) );\r\n		$file_to= substr( $file, 0, strrpos( $file, ''.'' ) ) .''.compress''. $filetype;\r\n		$filesarray[]= $file;\r\n		if( ! file_exists( $root . $file_to ) || filemtime( $root . $file ) > filemtime( $root . $file_to ) ) $refresh= true;\r\n	}else{\r\n		$filetype= substr( $files, strrpos( $files, ''.'' ) );\r\n		$file_to= ( $tofile ? $tofile : ''all.compress''.$filetype );\r\n		$tmp1= explode( '';'', $files );\r\n		foreach( $tmp1 AS $row1 )\r\n		{\r\n			$tmp2= explode( '':'', trim( $row1 ) );\r\n			if( count( $tmp2 ) == 1 )\r\n			{\r\n				$filepath= trim( $row1 );\r\n				$filesarray[]= $filepath;\r\n				if( ! file_exists( $root . $file_to ) || filemtime( $root . $filepath ) > filemtime( $root . $file_to ) ) $refresh= true;\r\n			}else{\r\n				$tmp3= explode( '','', $tmp2[ 1 ] );\r\n				foreach( $tmp3 AS $row3 )\r\n				{\r\n					$filepath= $tmp2[ 0 ] . trim( $row3 );\r\n					$filesarray[]= $tmp2[ 0 ] . trim( $row3 );\r\n					if( ! file_exists( $root . $file_to ) || filemtime( $root . $filepath ) > filemtime( $root . $file_to ) ) $refresh= true;\r\n				}\r\n			}\r\n		}\r\n	}\r\n	if( isset( $strtr[ $filetype ] ) ) $strtr_type= $strtr[ $filetype ];\r\n	if( isset( $pregreplace[ $filetype ][0] ) ) $pregreplace_type_0= $pregreplace[ $filetype ][0];\r\n	if( isset( $pregreplace[ $filetype ][1] ) ) $pregreplace_type_1= $pregreplace[ $filetype ][1];\r\n}\r\n//============================================================================\r\n$refresh= ( $refresh || ! empty( $r ) ? true : false );\r\nif( $refresh && $filesarray )\r\n{\r\n	$size_before= 0;\r\n	$file_to_handle= fopen( $root . $file_to, ''w'' );\r\n	if( $files ) fwrite( $file_to_handle, "/*{$files}*/\\n\\n" );\r\n	foreach( $filesarray AS $filerow )\r\n	{\r\n		$size_before += filesize( $root . $filerow );\r\n	}\r\n	foreach( $filesarray AS $filerow )\r\n	{\r\n		$filecontent= "";\r\n		$file_handle= fopen( $root . $filerow, ''r'' );\r\n		if( $file_handle )\r\n		{\r\n			while( ! feof( $file_handle ) ) $filecontent .= fread( $file_handle, 1024*64 );\r\n			fclose( $file_handle );\r\n			if( $filecontent )\r\n			{\r\n				if( $compress !== ''false'' )\r\n				{\r\n					if( $pregreplace_type_0 )\r\n					{\r\n						foreach( $pregreplace_type_0 AS $pattern => $replacement )\r\n							$filecontent= preg_replace( $pattern, $replacement, $filecontent );\r\n					}\r\n					if( $filetype == ''.css'' ) if( $strtr_type ) $filecontent= strtr( $filecontent, $strtr_type );\r\n					\r\n					if( $filetype != ''.css'' )\r\n					{\r\n						$parts= array();\r\n						$kovpos= $curpos= 0;\r\n						$string_flag= false;\r\n						while( true )\r\n						{\r\n							$kov1= ( $string_flag === ''2'' ? false : strpos( $filecontent, "\\"", $curpos+1 ) );\r\n							$kov2= ( $string_flag === ''1'' ? false : strpos( $filecontent, "''", $curpos+1 ) );\r\n							if( $kov1 === false && $kov2 === false )\r\n							{\r\n								$parts[]= array( substr( $filecontent, $kovpos ).( $string_flag === ''1'' ? "\\"" : ( $string_flag === ''2'' ? "''" : '''' ) ), ( $string_flag ? $string_flag : false ) );\r\n								break;\r\n							}else{\r\n								if( $kov1 === false ) $kov1= $kov2 + 1;\r\n								if( $kov2 === false ) $kov2= $kov1 + 1;\r\n								$curpos= ( $kov1 < $kov2 ? $kov1 : $kov2 );\r\n								$ii= 1; $cc= 0;\r\n								if( $string_flag )\r\n								{\r\n									while( substr( $filecontent, $curpos-$ii, 1 ) == "\\\\" )\r\n									{\r\n										$ii++; $cc++;\r\n									}\r\n								}\r\n								$vse_eshe_text= ( $string_flag && $cc%2!=0 ? true : false );\r\n								if( ! $string_flag || ( ! $parts[count($parts)-1][1] && ! $vse_eshe_text ) )\r\n								{\r\n									$parts[]= array( substr( $filecontent, $kovpos+( $string_flag ? 1 : 0 ), $curpos-($kovpos+( $string_flag ? 1 : -1 )) ),\r\n												( $string_flag ? $string_flag : false ) );\r\n									$string_flag= ( $string_flag ? false : ( $kov1 < $kov2 ? ''1'' : ''2'' ) );\r\n									$kovpos= $curpos;\r\n								}\r\n							}\r\n						}\r\n						\r\n						if( $rvars === ''true'' )\r\n						{\r\n							preg_match_all( "/var [a-zA-Z0-9_]+?/U", $filecontent, $matches );\r\n							if( $matches )\r\n							{\r\n								foreach( $matches[0] AS $row )\r\n								{\r\n									$var= str_replace( ''var '', '''', $row );\r\n									$vars[ $var ]= true;\r\n								}\r\n								foreach( $matches[0] AS $row )\r\n								{\r\n									$var= str_replace( ''var '', '''', $row );\r\n									do{ $varnum++; }while( $vars[ ''_''.$varnum ] );\r\n									$pregreplace_type_1[ "/([^a-zA-Z0-9_])(". $var .")([^a-zA-Z0-9_])/U" ]= ''${1}_''.$varnum.''${3}'';\r\n								}\r\n							}\r\n						}\r\n						\r\n						$filecontent= '''';\r\n						if( $parts )\r\n						{\r\n							foreach( $parts AS $part )\r\n							{\r\n								if( ! $part[1] )\r\n								{\r\n									if( $pregreplace_type_1 )\r\n									{\r\n										foreach( $pregreplace_type_1 AS $pattern => $replacement )\r\n											$part[0]= preg_replace( $pattern, $replacement, $part[0] );\r\n									}\r\n									if( $strtr_type ) $part[0]= strtr( $part[0], $strtr_type );\r\n								}\r\n								$filecontent .= $part[0];\r\n							}\r\n						}\r\n					}\r\n				}\r\n				fwrite( $file_to_handle, "/*{$filerow}*/\\n".$filecontent."\\n\\n" );\r\n			}\r\n		}\r\n	}\r\n	$size_after= filesize( $root . $file_to );\r\n	//$md5_after= md5_file( $root . $file_to );\r\n	fwrite( $file_to_handle, "/*Compress {$varsion} - ".round( $size_after * 100 / $size_before )."%".( $md5_after ? " - ".$md5_after : "" )."*/" );\r\n	fclose( $file_to_handle );\r\n}\r\n//============================================================================\r\nif( $print === ''true'' )\r\n{\r\n	$filecontent= '''';\r\n	$file_to_handle= fopen( $root . $file_to, ''r'' );\r\n	while( ! feof( $file_to_handle ) ) $filecontent .= fread( $file_to_handle, 1024*64 );\r\n	fclose( $file_to_handle );\r\n	return $filecontent;\r\n}else return $file_to;\r\n?>\r\n', 0, '', ' '),
(23, 'GenerAlias', 'v02', 0, 0, 0, '\r\n//v02\r\n//GenerAlias\r\n//==================================================================================\r\n$trans = array("а"=>"a", "б"=>"b", "в"=>"v", "г"=>"g", "д"=>"d", "е"=>"e",\r\n        "ё"=>"jo", "ж"=>"zh", "з"=>"z", "и"=>"i", "й"=>"jj", "к"=>"k", "л"=>"l",\r\n        "м"=>"m", "н"=>"n", "о"=>"o", "п"=>"p", "р"=>"r", "с"=>"s", "т"=>"t", "у"=>"u",\r\n        "ф"=>"f", "х"=>"kh", "ц"=>"c", "ч"=>"ch", "ш"=>"sh", "щ"=>"shh", "ы"=>"y",\r\n        "э"=>"eh", "ю"=>"yu", "я"=>"ya", "А"=>"a", "Б"=>"b", "В"=>"v", "Г"=>"g",\r\n        "Д"=>"d", "Е"=>"e", "Ё"=>"jo", "Ж"=>"zh", "З"=>"z", "И"=>"i", "Й"=>"jj",\r\n        "К"=>"k", "Л"=>"l", "М"=>"m", "Н"=>"n", "О"=>"o", "П"=>"p", "Р"=>"r", "С"=>"s",\r\n        "Т"=>"t", "У"=>"u", "Ф"=>"f", "Х"=>"kh", "Ц"=>"c", "Ч"=>"ch", "Ш"=>"sh",\r\n        "Щ"=>"shh", "Ы"=>"y", "Э"=>"eh", "Ю"=>"yu", "Я"=>"ya", " "=>"-", "."=>"-",\r\n        ","=>"-", "_"=>"-", "+"=>"-", ":"=>"-", ";"=>"-", "!"=>"-", "?"=>"-");\r\n		\r\n	$alias= addslashes( $txt );\r\n	$alias= strip_tags( strtr( $alias, $trans ) );\r\n	$alias= preg_replace( ''/&.+?;/'', '''', $alias );\r\n	$alias= preg_replace( "/[^a-zA-Z0-9-]/", "", $alias );\r\n	$alias= preg_replace( ''/([-]){2,}/'', ''\\1'', $alias );\r\n	$alias= trim( $alias, ''-'' );\r\n	\r\n	if( strlen( $alias ) > 20 )\r\n	{\r\n		$alias= trim( substr( $alias, 0, 20 ), "-" );\r\n	}\r\n	\r\n	do{\r\n		$rr= mysql_query( "SELECT id FROM ". $modx->getFullTableName( ''site_content'' ) ." WHERE alias=''{$alias}'' LIMIT 1" );\r\n		\r\n		if( $rr && mysql_num_rows( $rr ) == 1 ) $alias .= rand( 1, 9 );\r\n		\r\n	}while( ( $rr && mysql_num_rows( $rr ) == 1 ) || ! $rr );\r\n	\r\n	if( ! $rr ) $alias= false;\r\n	\r\n	return $alias;\r\n?>\r\n', 0, '', ' '),
(24, 'GetDoc61', '6.1', 0, 0, 0, '\r\n// 6.1 ver.\r\n//==========================================================================\r\n	\r\n	// idslist - только эти документы\r\n	// slice - срез итогового массива документов - функция array_slice();\r\n	\r\n// id = 1,2,5,255\r\n	// type = this | childs | all\r\n	// depth = 0 | 3 | 1,2,4 : 4-макс.уровень, а 1 и 2 игнорируются\r\n	// fields = ''pagetitle,content''\r\n	// tvfields = ''image,price''\r\n	// sort = ''field DESC, field_2 ASC''\r\n	// tpl = 0 | 10 | 6,-7,8\r\n	// isf\r\n	// param\r\n	// query\r\n	// limit\r\n	// clone - Клонировать в категории (ID TV параметра) значение параметра: ,345,123,56,\r\n	// publ\r\n	// del\r\n\r\n// ВЫЧЛЕНЕНИЕ ДОКУМЕНТОВ\r\n	//function getdoc50( $ids=''0,1'', $type=''childs'', $depth=0, $fields='''', $tvfields='''', $sort=''isfolder DESC, menuindex'', $tpl=0, $isf=''all'', $param='''', $query='''', $limit=0, $clone='''' )\r\n	//{\r\n	\r\n	$table1= ''site_content'';\r\n	$table2= ''site_tmplvars'';\r\n	$table3= ''site_tmplvar_contentvalues'';\r\n	\r\n	$docs= explode( '','', $ids );\r\n	\r\n	if( count( $docs ) > 0 )\r\n	{\r\n		$type= ( $type && ( $type == ''this'' || $type == ''all'' ) ? $type : ''childs'' );\r\n		\r\n		if( ! empty( $fields ) )\r\n		{\r\n			$arr_fields= explode( '','', $fields );\r\n		}\r\n		\r\n		if( ! empty( $tvfields ) )\r\n		{\r\n			$tvfields= explode( '','', $tvfields );\r\n			$tvfields_flag= true;\r\n			foreach( $tvfields AS $val )\r\n			{\r\n				if( $qq_tvfields != "" ) $qq_tvfields .= " OR ";\r\n				$qq_tvfields .= "tv.`name`=''{$val}''";\r\n			}\r\n			if( $qq_tvfields ) $qq_tvfields= "AND ( {$qq_tvfields} )";\r\n		}\r\n			\r\n		if( $tpl )\r\n		{\r\n			$flag_tpl= ( strstr( $tpl, "-" ) ? false : true );\r\n			$tpl= trim( $tpl, "-" );\r\n			$arr_tpl= explode( '','', $tpl );\r\n			foreach( $arr_tpl AS $key => $val )\r\n			{\r\n				if( $val == 0 )\r\n				{\r\n					$qq_tpl= "";\r\n					break 1;\r\n				}else{\r\n					if( $qq_tpl != '''' ) $qq_tpl .= ( $flag_tpl ? " OR " : " AND " );\r\n					$qq_tpl .= "template ".( $flag_tpl ? "=" : "<>" )." {$val}";\r\n				}\r\n			}\r\n			if( $qq_tpl ) $qq_tpl= "AND ( {$qq_tpl} )";\r\n		}\r\n		\r\n		if( empty( $isf ) ) $isf= "0";\r\n		if( $isf != ''all'' )\r\n		{\r\n			$qq_isf= "AND isfolder=". ( $isf ? "1" : "0" );\r\n		}\r\n		\r\n		$qq_published= "AND published=";\r\n		if( $publ == ''0'' ) $qq_published .= "0"; else $qq_published .= "1";\r\n		if( $publ == ''all'' ) $qq_published= "";\r\n		\r\n		$qq_deleted= "AND deleted=";\r\n		if( $del == ''1'' ) $qq_deleted .= "1"; else $qq_deleted .= "0";\r\n		if( $del == ''all'' ) $qq_deleted= "";\r\n		\r\n		$query= ( ! empty( $query ) ? "AND ". $query : "" );\r\n		\r\n		if( $type != ''this'' )\r\n		{\r\n			if( $depth )\r\n			{\r\n				$depths= explode( '','', $depth );\r\n				\r\n				if( count( $depths ) >= 2 )\r\n				{\r\n					$maxlvl= $depths[ count( $depths )-1 ];\r\n					foreach( $depths AS $key => $val ) if( $key != count( $depths )-1 ) $ignore_lvl[ $val ]= true;\r\n					\r\n				}elseif( count( $depths ) == 1 ){\r\n					$maxlvl= $depth;\r\n				}\r\n			}\r\n			if( ! $maxlvl ) $maxlvl= 999;\r\n			\r\n			$qq_sort= ( ! empty( $sort ) ? "ORDER BY ". $sort : "" );\r\n			\r\n			$qq_limit= ( ! empty( $limit ) ? "LIMIT ". $limit : "" );\r\n			\r\n			if( $slice ) $slice= explode( ",", $slice );\r\n		}\r\n		\r\n		\r\n//======================================================\r\n		\r\n		foreach( $docs AS $row )\r\n		{\r\n			if( ! $ignore_lvl[ 0 ] )\r\n			{\r\n				$ids_for_result[ $row ]= array( $row, 0, true );\r\n			}\r\n			$ids_for_check[ $row ]= array( $row, 0, true );\r\n			\r\n			if( $type != ''this'' )\r\n			{\r\n				if( ! empty( $clone ) )\r\n				{\r\n					$rr= mysql_query( "SELECT * FROM ". $modx->getFullTableName( $table3 ) ." WHERE tmplvarid={$clone} AND `value` LIKE ''%,{$row},%''" );\r\n					if( $rr && mysql_num_rows( $rr ) > 0 )\r\n					{\r\n						while( $cln= mysql_fetch_assoc( $rr ) )\r\n						{\r\n							$clones[ $cln[ ''contentid'' ] ]= $cln[ ''contentid'' ];\r\n						}\r\n					}\r\n				}\r\n			}\r\n		}\r\n		\r\n		$idslist= explode( '','', $idslist );\r\n		$qq_onlyids= "";\r\n		if( ! empty( $idslist ) )\r\n		{\r\n			foreach( $idslist AS $val )\r\n			{\r\n				if( $val ) $qq_onlyids .= ( $qq_onlyids ? " OR " : "AND ( " ) ."id={$val}";\r\n			}\r\n			if( ! empty( $qq_onlyids ) ) $qq_onlyids .= " )";\r\n		}\r\n		\r\n		if( $type != ''this'' )\r\n		{\r\n			while( count( $ids_for_check ) > 0 )\r\n			{\r\n				$row= array_shift( $ids_for_check );\r\n				$rr= mysql_query( "SELECT id FROM ". $modx->getFullTableName( $table1 ) ." WHERE parent={$row[0]} AND isfolder=1 {$qq_published} {$qq_deleted}" );\r\n				if( $rr && mysql_num_rows( $rr ) > 0 )\r\n				{\r\n					$lvlii= $row[ 1 ] + 1;\r\n					for( $kk=0; $kk<mysql_num_rows( $rr ); $kk++ )\r\n					{\r\n						if( $lvlii <= $maxlvl )\r\n						{\r\n							$ids_for_result[ mysql_result( $rr, $kk, ''id'' ) ]= array( mysql_result( $rr, $kk, ''id'' ), $lvlii );\r\n							$ids_for_check[ mysql_result( $rr, $kk, ''id'' ) ]= array( mysql_result( $rr, $kk, ''id'' ), $lvlii );\r\n						}\r\n					}\r\n				}\r\n			}\r\n		}\r\n		\r\n		if( count( $ids_for_result ) > 0 )\r\n		{\r\n			foreach( $ids_for_result AS $key => $val )\r\n			{\r\n				$lvlii= $val[ 1 ];\r\n				$lvliii= $lvlii + 1;\r\n				\r\n				$tmp1= ( ! $ignore_lvl[ $lvlii ] && $lvlii <= $maxlvl && ( $type != ''childs'' || ! $val[ 2 ] ) ? "id={$key}" : "" );\r\n				$tmp2= ( ! $ignore_lvl[ $lvliii ] && $lvliii <= $maxlvl && ( ! $isf || $isf == ''all'' ) ? ( $tmp1 ? " OR " : "" ) ."parent={$key}" : "" );\r\n				\r\n				if( $tmp1 || $tmp2 )\r\n				{\r\n					if( $qq_ids != '''' ) $qq_ids .= " OR ";\r\n					$qq_ids .= "( {$tmp1}{$tmp2} )";\r\n				}\r\n			}\r\n		}\r\n		\r\n		if( ! empty( $clones ) )\r\n		{\r\n			foreach( $clones AS $cln )\r\n			{\r\n				$qq_ids .= ( ! empty( $qq_ids ) ? " OR " : "" ) ."( id={$cln} )";\r\n			}\r\n		}\r\n		\r\n		$qq= "SELECT id".( $fields ? ",".$fields : "" )." FROM ". $modx->getFullTableName( $table1 ) ."\r\n			WHERE ( {$qq_ids} ) {$qq_onlyids} {$qq_tpl} {$qq_isf} {$query} {$qq_published} {$qq_deleted}\r\n				{$qq_sort} {$qq_limit}";\r\n		\r\n		$rr= mysql_query( $qq );\r\n		$qq_ids= "";\r\n		if( $rr )\r\n		{\r\n			while( $row= mysql_fetch_assoc( $rr ) )\r\n			{\r\n				$itogo[ $row[ ''id'' ] ]= $row;\r\n				\r\n				if( $tvfields_flag )\r\n				{\r\n					if( $qq_ids != "" ) $qq_ids .= " OR ";\r\n					$qq_ids .= "tvc.contentid={$row[id]}";\r\n				}\r\n			}\r\n		}\r\n		\r\n		if( $tvfields_flag && ! empty( $itogo ) )\r\n		{\r\n			if( $qq_ids ) $qq_ids= "AND ( {$qq_ids} )";\r\n			\r\n			$rr= mysql_query( "SELECT id, name, default_text FROM ". $modx->getFullTableName( $table2 ) ." AS tv WHERE 1=1 {$qq_tvfields}" );\r\n			if( $rr )\r\n			{\r\n				while( $row= mysql_fetch_assoc( $rr ) )\r\n				{\r\n					$tvdefault[ $row[ ''name'' ] ]= $row[ ''default_text'' ];\r\n				}\r\n			}\r\n			\r\n			$rr= mysql_query( "SELECT tv.default_text,tv.`name`,tvc.contentid,tvc.`value` FROM ". $modx->getFullTableName( $table2 ) ." AS tv, ". $modx->getFullTableName( $table3 ) ." AS tvc\r\n				WHERE tv.id=tvc.tmplvarid {$qq_tvfields} {$qq_ids} ORDER BY tv.id" );\r\n			if( $rr )\r\n			{\r\n				while( $row= mysql_fetch_assoc( $rr ) )\r\n				{\r\n					$itogo[ $row[ ''contentid'' ] ][ $row[ ''name'' ] ]= $row[ ''value'' ];\r\n				}\r\n			}\r\n			\r\n			foreach( $itogo AS $key => $val )\r\n			{\r\n				foreach( $tvfields AS $key2 => $val2 )\r\n				{\r\n					if( ! isset( $val[ $val2 ] ) || empty( $val[ $val2 ] ) )\r\n						$itogo[ $key ][ $val2 ]= $tvdefault[ $val2 ];\r\n				}\r\n			}\r\n		}\r\n		\r\n		if( $slice )\r\n		{\r\n			$itogo= array_slice( $itogo, $slice[ 0 ], ( $slice[ 1 ] ? $slice[ 1 ] : null ) );\r\n		}\r\n	}\r\n	\r\n	return $itogo;\r\n//}\r\n\r\n\r\n	// СОРТИРОВКА ПО TV-параметрам\r\n	/*if( $docs2 )\r\n	{\r\n		foreach( $docs2 AS $row )\r\n		{\r\n			$tmp= intval( $row[ ''price'' ] );\r\n			$tmp= str_pad( $tmp, 10, ''0'', STR_PAD_LEFT );\r\n			$sortirovka[ $tmp .''__''. $row[ ''pagetitle'' ] .''__''. $row[ ''id'' ] ]= $row;\r\n		}\r\n		ksort( $sortirovka );\r\n		$docs2= array_slice( $sortirovka, $page_s, $MaxItemsInPage );\r\n	}*/\r\n	// СОРТИРОВКА ПО TV-параметрам\r\n?>\r\n', 0, '', ' '),
(25, 'GetIdOnLvl', 'v005', 0, 0, 0, '\r\n//v005\r\n//GetIdOnLvl\r\n//================== Список ИД всех родителей ====================\r\n$doc= $modx->getDocument( $id, ''id,parent''.( $fields ? '','' : '''' ).$fields );\r\n\r\n$list[]= $doc;\r\n\r\nwhile( $id != $koren && $doc[ ''parent'' ] != $koren && $doc[ ''parent'' ] != 0 )\r\n{\r\n	$doc= $modx->getDocument( $doc[ ''parent'' ], ''id,parent''.( $fields ? '','' : '''' ).$fields );\r\n	$list[]= $doc;\r\n}\r\n\r\nif( $doc[ ''parent'' ] == 0 )\r\n{\r\n	$list[]= array( ''id''=>0 );\r\n}elseif( $doc[ ''parent'' ] == $koren ){\r\n	$doc= $modx->getDocument( $doc[ ''parent'' ], ''id,parent''.( $fields ? '','' : '''' ).$fields );\r\n	$list[]= $doc;\r\n}\r\n\r\n$list[]= false;\r\n$list= array_reverse( $list );\r\n\r\nreturn ( $lvl ? $list[ $lvl ][ ( $prm ? $prm : ''id'' ) ] : $list );\r\n//====================================================================\r\n?>\r\n', 0, '', ' '),
(26, 'GetLvl', 'v002', 0, 0, 0, '\r\n//v002\r\n//GetLvl\r\n//================== Определение уровня вложенности ====================\r\n	if( $id == $koren )\r\n	{\r\n		print ''1'';\r\n	\r\n	}else{\r\n		$lvl= 2;\r\n		$doc= $modx->getDocument( $id, ''parent'' );\r\n		\r\n		while( $doc[ ''parent'' ] != $koren && $doc[ ''parent'' ] != 0 )\r\n		{\r\n			$lvl++;\r\n			$doc= $modx->getDocument( $doc[ ''parent'' ], ''parent'' );\r\n		}\r\n		\r\n		if( $koren != 0 && $doc[ ''parent'' ] == 0 )\r\n		{\r\n			print ''0'';\r\n		}else{\r\n			print $lvl;	\r\n		}\r\n	}\r\n//====================================================================\r\n?>\r\n', 0, '', ' '),
(27, 'ImgCrop71', 'v71', 0, 0, 0, '\r\n// v71\r\n// 14.07.2016\r\n// ImgCrop\r\n/*\r\n	$img= assets/images/img.jpg\r\n	$w= (int)156\r\n	$h= (int)122\r\n	$backgr= 0/1\r\n	$fill= 0/1\r\n	$x= center/left/right\r\n	$y= center/top/bottom\r\n	$bgcolor= R,G,B,A / x:y / fill:a;b;c;d|b;c;d\r\n	$wm= 0/1\r\n	$filter= a;b;c;d|b;c;d\r\n	$png= 0/1\r\n	$r= 0/1\r\n	$ellipse= max / (int)56\r\n	$degstep= (int)5\r\n	$dopimg= assets/images/dopimg.jpg\r\n	$dopimg_xy= x:y\r\n	$toimg= assets/images/toimg.jpg\r\n	$quality= (int)80\r\n*/\r\n//==========================================================================================\r\n	$ipathnotphoto= ''template/images/notphoto.png''; // БЕЗ СЛЕША В НАЧАЛЕ\r\n	$ipathwatermark= ''template/images/watermark.png''; // БЕЗ СЛЕША В НАЧАЛЕ // ТОЛЬКО .PNG\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n//==========================================================================================\r\n	\r\n	$img= urldecode( $img );\r\n	$w= ( empty( $w ) ? 0 : intval($w) );\r\n	$h= ( empty( $h ) ? 0 : intval($h) );\r\n	$backgr= ( empty( $backgr ) ? false : $backgr );\r\n	$fill= ( empty( $fill ) ? false : $fill );\r\n	$x= ( empty( $x ) ? ''center'' : $x );\r\n	$y= ( empty( $y ) ? ''center'' : $y );\r\n	$bgcolor= ( empty( $bgcolor ) ? ''255,255,255,127'' : $bgcolor );\r\n	$wm= ( empty( $wm ) ? false : $wm );\r\n	$png= ( empty( $png ) ? false : $png );\r\n	$filter= ( empty( $filter ) ? -1 : $filter );\r\n	$refresh= ( empty( $r ) ? false : true );\r\n	$slash= ( substr( $img, 0, 1 ) != DIRECTORY_SEPARATOR ? true : false );\r\n	$root= rtrim( MODX_BASE_PATH, "/\\\\" ) . ( $slash ? DIRECTORY_SEPARATOR : '''' );\r\n	$img= trim( $img );\r\n	\r\n	$ipathnotphoto= ( $slash ? '''' : DIRECTORY_SEPARATOR ) . $ipathnotphoto;\r\n	$ipathwatermark= ( $slash ? '''' : DIRECTORY_SEPARATOR ) . $ipathwatermark;\r\n\r\n	$quality= intval( $quality );\r\n	$quality= ( empty($quality) || $quality < 0 || $quality > 100 ? 80 : $quality );\r\n\r\n	$ellipse= ( $ellipse == ''max'' ? ''max'' : intval( $ellipse ) );\r\n\r\n	if( $dopimg )\r\n	{\r\n		$dopimg= trim( urldecode( $dopimg ) );\r\n		$dopimg= ltrim( $dopimg, "/\\\\" );\r\n		$dopimg= $root . ( $slash ? '''' : DIRECTORY_SEPARATOR ) . $dopimg;\r\n	}\r\n	if( $toimg )\r\n	{\r\n		$toimg= trim( urldecode( $toimg ) );\r\n		$toimg= ltrim( $toimg, "/\\\\" );\r\n		$toimg= ( $slash ? '''' : DIRECTORY_SEPARATOR ) . $toimg;\r\n	}\r\n	\r\n	if( ! file_exists( $root . $img ) || ! is_file( $root . $img ) )\r\n	{\r\n		$img= $ipathnotphoto;\r\n		if( $fill ){ $fill= false; $backgr= true; $bgcolor= ''1:1''; }\r\n	}\r\n	if( ! file_exists( $root . $img ) || ! is_file( $root . $img ) ) return false;\r\n	if( $wm && ( ! file_exists( $root . $ipathwatermark ) || ! is_file( $root . $ipathwatermark ) ) )\r\n	{\r\n		$wm= false;\r\n		$img= $ipathnotphoto;\r\n	}\r\n\r\n	if( ! $toimg )\r\n	{\r\n		$imgrassh= substr( $img, strrpos( $img, ''.'' ) );\r\n		$newimg= ''_th''. md5( $img . $w . $h . $backgr . $fill . $x . $y . $bgcolor . $wm . $filter . $ellipse . $dopimg . $quality ) . ( $png ? ''.png'' : $imgrassh );\r\n		\r\n		$imgarr= explode( DIRECTORY_SEPARATOR, $img );\r\n		unset( $imgarr[ count( $imgarr )-1 ] );\r\n		foreach( $imgarr AS $val )\r\n		{\r\n			$newimg_dir .= $val . DIRECTORY_SEPARATOR;\r\n		}\r\n		$newimg_dir .= ''.th''. DIRECTORY_SEPARATOR;\r\n		if( ! file_exists( $root . $newimg_dir ) ) mkdir( $root . $newimg_dir, 0777 );\r\n		\r\n		$newimg_path= $root . $newimg_dir . $newimg;\r\n		$newimg_path_return= ( $fullpath ? MODX_SITE_URL : '''' ) . $newimg_dir . $newimg;\r\n		\r\n	}else{\r\n		$newimg_path= $toimg;\r\n		$newimg_path_return= ( $fullpath ? MODX_SITE_URL : '''' ) . $toimg;\r\n	}\r\n	if( ! file_exists( $newimg_path ) || filemtime( $root . $img ) > filemtime( $newimg_path ) ) $refresh= true;\r\n	if( filesize( $root . $img ) > 1024*1024*10 ) return $img;\r\n// ======================================================\r\n\r\n	if( $refresh )\r\n	{\r\n		$img1_info= getimagesize( $root . $img );\r\n		if( ! $img1_info[ 1 ] ) return false;\r\n		$ot= $img1_info[ 0 ] / $img1_info[ 1 ];\r\n		$dstW= ( $w > 0 ? $w : $img1_info[ 0 ] );\r\n		$dstH= ( $h > 0 ? $h : $img1_info[ 1 ] );\r\n		$dstX= 0;\r\n		$dstY= 0;\r\n		$srcW= $img1_info[ 0 ];\r\n		$srcH= $img1_info[ 1 ];\r\n		$srcX= 0;\r\n		$srcY= 0;\r\n		if( $fill )\r\n		{\r\n			$srcW= $img1_info[ 0 ];\r\n			$srcH= round( $img1_info[ 0 ] / ( $dstW / $dstH ) );\r\n			if( $srcH > $img1_info[ 1 ] )\r\n			{\r\n				$srcW= round( $img1_info[ 1 ] / ( $dstH / $dstW ) );\r\n				$srcH= $img1_info[ 1 ];\r\n			}\r\n			if( $x == ''center'' ) $srcX= round( ( $img1_info[ 0 ] - $srcW ) / 2 );\r\n			if( $x == ''right'' ) $srcX= $img1_info[ 0 ] - $srcW;\r\n			if( $y == ''center'' ) $srcY= round( ( $img1_info[ 1 ] - $srcH ) / 2 );\r\n			if( $y == ''bottom'' ) $srcY= $img1_info[ 1 ] - $srcH;\r\n		}else{\r\n			if( ( $img1_info[ 0 ] > $w && $w > 0 ) || ( $img1_info[ 1 ] > $h && $h > 0 ) )\r\n			{\r\n				$dstH= round( $dstW / $ot );\r\n				\r\n				if( $dstH > $h && $h > 0 )\r\n				{\r\n					$dstH= $h;\r\n					$dstW= round( $dstH * $ot );\r\n				}\r\n			}else{\r\n				$dstW= $img1_info[ 0 ];\r\n				$dstH= $img1_info[ 1 ];\r\n			}\r\n			if( $backgr )\r\n			{\r\n				if( $dstW < $w )\r\n				{\r\n					if( $x == ''center'' ) $dstX= round( ( $w - $dstW ) / 2 );\r\n					if( $x == ''right'' ) $dstX= $w - $dstW;\r\n				}\r\n				if( $dstH < $h )\r\n				{\r\n					if( $y == ''center'' ) $dstY= round( ( $h - $dstH ) / 2 );\r\n					if( $y == ''bottom'' ) $dstY= $h - $dstH;\r\n				}\r\n			}\r\n		}\r\n		$crW= ( $backgr && $w > 0 ? $w : $dstW );\r\n		$crH= ( $backgr && $h > 0 ? $h : $dstH );\r\n		if( strstr( $bgcolor, "," ) )\r\n		{\r\n			$rgba_arr= explode( ",", $bgcolor );\r\n			for( $kk=0; $kk<=3; $kk++ )\r\n			{\r\n				$rgba_arr[ $kk ]= intval( $rgba_arr[ $kk ] );\r\n				if( $kk <= 2 && ( $rgba_arr[ $kk ] < 0 || $rgba_arr[ $kk ] > 255 ) ) $rgba_arr[ $kk ]= 255;\r\n				if( $kk == 3 && ( $rgba_arr[ $kk ] < 0 || $rgba_arr[ $kk ] > 127 ) ) $rgba_arr[ $kk ]= 127;\r\n			}\r\n			$bgcolor= ''rgba'';\r\n		}elseif( strpos( $bgcolor, ''fill:'' ) === 0 ){\r\n			$effect= substr( $bgcolor, strpos( $bgcolor, '':'' )+1 );\r\n			$bgcolor= ''fill'';\r\n		}else{\r\n			$coord_arr= explode( ":", $bgcolor );\r\n			$bgcolor= ''coord'';\r\n		}\r\n//========================================================================================\r\n		\r\n		if( $img1_info[ 2 ] == 1 ) $img1= imagecreatefromgif( $root . $img );\r\n			\r\n		elseif( $img1_info[ 2 ] == 2 ) $img1= imagecreatefromjpeg( $root . $img );\r\n			\r\n		elseif( $img1_info[ 2 ] == 3 ){\r\n			$img1= imagecreatefrompng( $root . $img );\r\n			$png= true;\r\n		}\r\n		\r\n		if( $bgcolor == ''coord'' )\r\n		{\r\n			$col= imagecolorat( $img1, $coord_arr[ 0 ], $coord_arr[ 1 ] );\r\n			$bgcolor= imagecolorsforindex( $img1, $col );\r\n			$rgba_arr[ 0 ]= $bgcolor[ ''red'' ];\r\n			$rgba_arr[ 1 ]= $bgcolor[ ''green'' ];\r\n			$rgba_arr[ 2 ]= $bgcolor[ ''blue'' ];\r\n			$rgba_arr[ 3 ]= $bgcolor[ ''alpha'' ];\r\n		}\r\n		\r\n		$img2= ImageCreateTrueColor( $crW, $crH );\r\n		\r\n		if( $png )\r\n		{\r\n			imagealphablending( $img2, true );\r\n			imagesavealpha( $img2, true );\r\n			$col= imagecolorallocatealpha( $img2, $rgba_arr[ 0 ], $rgba_arr[ 1 ], $rgba_arr[ 2 ], $rgba_arr[ 3 ] );\r\n		}else{\r\n			$col= imagecolorallocate( $img2, $rgba_arr[ 0 ], $rgba_arr[ 1 ], $rgba_arr[ 2 ] );\r\n		}\r\n		\r\n		if( $bgcolor == ''fill'' )\r\n		{\r\n			imagecopyresampled( $img2, $img1, 0, 0, 0, 0, $crW, $crH, $img1_info[0], $img1_info[1] );\r\n			$effect= explode( ''|'', $effect );\r\n			if( ! empty( $effect ) )\r\n			{\r\n				foreach( $effect AS $row )\r\n				{\r\n					$tmp= explode( '';'', $row );\r\n					if( $tmp[ 0 ] == 2 || $tmp[ 0 ] == 3 || $tmp[ 0 ] == 10 ) imagefilter( $img2, $tmp[ 0 ], $tmp[ 1 ] );\r\n					elseif( $tmp[ 0 ] == 4 ) imagefilter( $img2, $tmp[ 0 ], $tmp[ 1 ], $tmp[ 2 ], $tmp[ 3 ], $tmp[ 4 ] );\r\n					elseif( $tmp[ 0 ] == 11 ) imagefilter( $img2, $tmp[ 0 ], $tmp[ 1 ], $tmp[ 2 ] );\r\n					else imagefilter( $img2, $tmp[ 0 ] );\r\n				}\r\n			}\r\n		}else{\r\n			imagefill( $img2, 0,0, $col );\r\n		}\r\n		\r\n		imagecopyresampled( $img2, $img1, $dstX, $dstY, $srcX, $srcY, $dstW, $dstH, $srcW, $srcH );\r\n		\r\n		if( $wm )\r\n		{\r\n			$wm_info= getimagesize( $root . $ipathwatermark );\r\n			$img3= imagecreatefrompng( $root . $ipathwatermark );\r\n			$wm_ot= $wm_info[ 0 ] / $wm_info[ 1 ];\r\n			$wmW= $wm_info[ 0 ];\r\n			$wmH= $wm_info[ 1 ];\r\n			if( $crW < $wm_info[ 0 ] )\r\n			{\r\n				$wmW= $crW - round( $crW / 30 );\r\n				$wmH= round( $wmW / $wm_ot );\r\n			}\r\n			if( $crH < $wmH )\r\n			{\r\n				$wmH= $crH - round( $crH / 30 );\r\n				$wmW= round( $wmH * $wm_ot );\r\n			}\r\n			$wmX= round( ( $crW - $wmW ) / 2 );\r\n			$wmY= round( ( $crH - $wmH ) / 2 );\r\n			imagecopyresampled( $img2, $img3, $wmX, $wmY, 0, 0, $wmW, $wmH, $wm_info[ 0 ], $wm_info[ 1 ] );\r\n			imagedestroy( $img3 );\r\n		}\r\n		\r\n		$filter= explode( ''|'', $filter );\r\n		if( ! empty( $filter ) )\r\n		{\r\n			foreach( $filter AS $row )\r\n			{\r\n				$tmp= explode( '';'', $row );\r\n				if( $tmp[ 0 ] == 2 || $tmp[ 0 ] == 3 || $tmp[ 0 ] == 10 ) imagefilter( $img2, $tmp[ 0 ], $tmp[ 1 ] );\r\n				elseif( $tmp[ 0 ] == 4 ) imagefilter( $img2, $tmp[ 0 ], $tmp[ 1 ], $tmp[ 2 ], $tmp[ 3 ], $tmp[ 4 ] );\r\n				elseif( $tmp[ 0 ] == 11 ) imagefilter( $img2, $tmp[ 0 ], $tmp[ 1 ], $tmp[ 2 ] );\r\n				else imagefilter( $img2, $tmp[ 0 ] );\r\n			}\r\n		}\r\n		\r\n		if( $ellipse )\r\n		{\r\n			$degstep= ( $degstep ? intval( $degstep ) : 5 );\r\n			$w= ( $crW > $crH ? $crH : $crW );\r\n			$cntr= ($w/2);\r\n			$coord= array();\r\n			$opacitycolor= imagecolorallocatealpha( $img2, 255, 255, 255, 127 );\r\n			if( $ellipse == ''max'' ) $ellipse_r= $cntr-1; else $ellipse_r= $ellipse;\r\n			for( $part=1; $part<=4; $part++ )\r\n			{\r\n				for( $deg=0; $deg<90; $deg+=$degstep )\r\n				{\r\n					$mydeg= $deg;\r\n					if( $part == 2 || $part == 4 ) $mydeg= 90 - $deg;\r\n					if( ! $coord[ $mydeg ][ ''x'' ] ) $coord[ $mydeg ][ ''x'' ]= round( $ellipse_r * cos( deg2rad( $mydeg ) ) );\r\n					if( ! $coord[ $mydeg ][ ''y'' ] ) $coord[ $mydeg ][ ''y'' ]= round( $ellipse_r * sin( deg2rad( $mydeg ) ) );\r\n					$x= $coord[ $mydeg ][ ''x'' ];\r\n					$y= $coord[ $mydeg ][ ''y'' ];\r\n					if( $part == 4 ){ $y *= -1; }\r\n					if( $part == 3 ){ $x *= -1; $y *= -1; }\r\n					if( $part == 2 ){ $x *= -1; }\r\n					$points[]= $cntr + $x;\r\n					$points[]= $cntr + $y;\r\n				}\r\n			}\r\n			$points[]= $cntr + $ellipse_r; $points[]= $cntr;\r\n			$points[]= $w; $points[]= $cntr;\r\n			$points[]= $w; $points[]= $w;\r\n			$points[]= 0; $points[]= $w;\r\n			$points[]= 0; $points[]= 0;\r\n			$points[]= $w; $points[]= 0;\r\n			$points[]= $w; $points[]= $cntr;\r\n			$png= true;\r\n			imagealphablending( $img2, false );\r\n			imagesavealpha( $img2, true );\r\n			imagefilledpolygon( $img2, $points, count($points)/2, $opacitycolor );\r\n			//$autrum= imagecolorallocate( $img2, 216, 181, 85 );\r\n			//imageellipse( $img2, $cntr, $cntr, $ellipse_r*2, $ellipse_r*2, $autrum );\r\n		}\r\n		\r\n		if( $dopimg )\r\n		{\r\n			if( $dopimg_xy )\r\n			{\r\n				$dopimg_xy= explode( ":", $dopimg_xy );	\r\n			}\r\n			imagealphablending( $img2, true );\r\n			imagesavealpha( $img2, true );\r\n			$dopimg_info= getimagesize( $dopimg );\r\n			$img3= imagecreatefrompng( $dopimg );\r\n			$diX= round( ( $crW - $dopimg_info[ 0 ] ) / 2 ) + ( $dopimg_xy[ 0 ] ? intval( $dopimg_xy[ 0 ] ) : 0 );\r\n			$diY= round( ( $crH - $dopimg_info[ 1 ] ) / 2 ) + ( $dopimg_xy[ 1 ] ? intval( $dopimg_xy[ 1 ] ) : 0 );\r\n			imagecopyresampled( $img2, $img3, $diX, $diY, 0, 0, $dopimg_info[ 0 ], $dopimg_info[ 1 ], $dopimg_info[ 0 ], $dopimg_info[ 1 ] );\r\n			imagedestroy( $img3 );\r\n		}\r\n		\r\n		if( $png ){\r\n			imagepng( $img2, $newimg_path );\r\n		}elseif( $img1_info[ 2 ] == 1 ){\r\n			imagegif( $img2, $newimg_path, $quality );\r\n		}elseif( $img1_info[ 2 ] == 2 ){\r\n			imagejpeg( $img2, $newimg_path, $quality );\r\n		}\r\n		chmod( $newimg_path, 0777 );\r\n		imagedestroy( $img1 );\r\n		imagedestroy( $img2 );\r\n	}\r\n\r\n	return $newimg_path_return;\r\n?>\r\n', 0, '', ' '),
(28, 'Date', '', 0, 0, 0, '\r\n$array= array(\r\n	''m2'' => array(\r\n		''01'' => ''января'', ''02'' => ''февраля'', ''03'' => ''марта'', ''04'' => ''апреля'',\r\n		''05'' => ''мая'', ''06'' => ''июня'', ''07'' => ''июля'', ''08'' => ''августа'',\r\n		''09'' => ''сентября'', ''10'' => ''октября'', ''11'' => ''ноября'', ''12'' => ''декабря''\r\n	)\r\n);\r\nif( ! empty( $array[ $ff ] ) ) return $array[ $ff ][ date( ( ! empty( $f ) ? $f : ''d.m.Y'' ), ( ! empty( $d ) ? $d : time() ) ) ];\r\nreturn date( ( ! empty( $f ) ? $f : ''d.m.Y'' ), ( ! empty( $d ) ? $d : time() ) );\r\n', 0, '', ' '),
(29, 'WayfinderScorn', '', 0, 0, 0, '\r\nif(!defined(''MODX_BASE_PATH'')){die(''What are you doing? Get out of here!'');}\r\n/*\r\n::::::::::::::::::::::::::::::::::::::::\r\n Snippet name: Wayfinder\r\n Short Desc: builds site navigation\r\n Version: 2.0.1\r\n Authors: \r\n	Kyle Jaebker (muddydogpaws.com)\r\n	Ryan Thrash (vertexworks.com)\r\n Date: February 27, 2006\r\n::::::::::::::::::::::::::::::::::::::::\r\nDescription:\r\n    Totally refactored from original DropMenu nav builder to make it easier to\r\n    create custom navigation by using chunks as output templates. By using templates,\r\n    many of the paramaters are no longer needed for flexible output including tables,\r\n    unordered- or ordered-lists (ULs or OLs), definition lists (DLs) or in any other\r\n    format you desire.\r\n::::::::::::::::::::::::::::::::::::::::\r\nExample Usage:\r\n    [[Wayfinder? &startId=`0`]]\r\n::::::::::::::::::::::::::::::::::::::::\r\n*/\r\n\r\n$wayfinder_sc_base = $modx->config[''base_path'']."assets/snippets/wayfinder_scorn/";\r\n\r\n//Include a custom config file if specified\r\n$config = (isset($config)) ? "{$wayfinder_sc_base}configs/{$config}.config.php" : "{$wayfinder_sc_base}configs/default.config.php";\r\nif (file_exists($config)) {\r\n	include("$config");\r\n}\r\n\r\ninclude_once("{$wayfinder_sc_base}wayfinder.inc.php");\r\n\r\nif (class_exists(''ScornWayfinder'')) {\r\n   $wf = new ScornWayfinder();\r\n} else {\r\n    return ''error: Wayfinder class not found'';\r\n}\r\n\r\n$wf->_config = array(\r\n	''id'' => isset($startId) ? $startId : $modx->documentIdentifier,\r\n	''level'' => isset($level) ? $level : 0,\r\n	''includeDocs'' => isset($includeDocs) ? $includeDocs : 0,\r\n	''excludeDocs'' => isset($excludeDocs) ? $excludeDocs : 0,\r\n	''ph'' => isset($ph) ? $ph : FALSE,\r\n	''debug'' => isset($debug) ? TRUE : FALSE,\r\n	''ignoreHidden'' => isset($ignoreHidden) ? $ignoreHidden : FALSE,\r\n	''hideSubMenus'' => isset($hideSubMenus) ? $hideSubMenus : FALSE,\r\n	''useWeblinkUrl'' => isset($useWeblinkUrl) ? $useWeblinkUrl : TRUE,\r\n	''fullLink'' => isset($fullLink) ? $fullLink : FALSE,\r\n	''nl'' => isset($removeNewLines) ? '''' : "\\n",\r\n	''sortOrder'' => isset($sortOrder) ? strtoupper($sortOrder) : ''ASC'',\r\n	''sortBy'' => isset($sortBy) ? $sortBy : ''menuindex'',\r\n	''limit'' => isset($limit) ? $limit : 0,\r\n	''cssTpl'' => isset($cssTpl) ? $cssTpl : FALSE,\r\n	''jsTpl'' => isset($jsTpl) ? $jsTpl : FALSE,\r\n	''rowIdPrefix'' => isset($rowIdPrefix) ? $rowIdPrefix : FALSE,\r\n	''textOfLinks'' => isset($textOfLinks) ? $textOfLinks : ''menutitle'',\r\n	''titleOfLinks'' => isset($titleOfLinks) ? $titleOfLinks : ''pagetitle'',\r\n	''displayStart'' => isset($displayStart) ? $displayStart : FALSE,\r\n	''entityEncode'' => isset($entityEncode) ? $entityEncode : TRUE,\r\n	\r\n	''prefFC'' => isset($prefClass) ? $prefClass : '''',\r\n	''only'' => $onlyThis == ''folders'' ? ''folders'' : FALSE,\r\n	''onlyStart'' => isset($onlyThisStart) ? $onlyThisStart : FALSE,\r\n	''onlyForReg'' => isset($onlyForReg) ? $onlyForReg : FALSE,\r\n);\r\n\r\n//get user class definitions\r\n$wf->_css = array(\r\n	''first'' => isset($firstClass) ? $prefClass . $firstClass : '''',\r\n	''last'' => isset($lastClass) ? $prefClass . $lastClass : $prefClass . ''last'',\r\n	''here'' => isset($hereClass) ? $prefClass . $hereClass : $prefClass . ''active'',\r\n	''parent'' => isset($parentClass) ? $prefClass . $parentClass : '''',\r\n	''row'' => isset($rowClass) ? $prefClass . $rowClass : '''',\r\n	''outer'' => isset($outerClass) ? $prefClass . $outerClass : '''',\r\n	''inner'' => isset($innerClass) ? $prefClass . $innerClass : '''',\r\n	''level'' => isset($levelClass) ? $prefClass . $levelClass: '''',\r\n	''self'' => isset($selfClass) ? $prefClass . $selfClass : $prefClass . ''iam'',\r\n	''weblink'' => isset($webLinkClass) ? $prefClass . $webLinkClass : '''',\r\n	\r\n	''open'' => isset($openClass) ? $prefClass . $openClass : $prefClass . ''open'',\r\n	''empty'' => isset($emptyClass) ? $prefClass . $emptyClass : $prefClass . ''empty'',\r\n	''link'' => isset($linkClass) ? $linkClass : '''',\r\n);\r\n\r\n//get user templates\r\n$wf->_templates = array(\r\n	''outerTpl'' => isset($outerTpl) ? $outerTpl : '''',\r\n	''rowTpl'' => isset($rowTpl) ? $rowTpl : '''',\r\n	''parentRowTpl'' => isset($parentRowTpl) ? $parentRowTpl : '''',\r\n	''parentRowHereTpl'' => isset($parentRowHereTpl) ? $parentRowHereTpl : '''',\r\n	''hereTpl'' => isset($hereTpl) ? $hereTpl : '''',\r\n	''innerTpl'' => isset($innerTpl) ? $innerTpl : '''',\r\n	''innerRowTpl'' => isset($innerRowTpl) ? $innerRowTpl : '''',\r\n	''innerHereTpl'' => isset($innerHereTpl) ? $innerHereTpl : '''',\r\n	''activeParentRowTpl'' => isset($activeParentRowTpl) ? $activeParentRowTpl : '''',\r\n	''categoryFoldersTpl'' => isset($categoryFoldersTpl) ? $categoryFoldersTpl : '''',\r\n	''startItemTpl'' => isset($startItemTpl) ? $startItemTpl : '''',\r\n);\r\n\r\n//Process Wayfinder\r\n$output = $wf->run();\r\n\r\nif ($wf->_config[''debug'']) {\r\n	$output .= $wf->renderDebugOutput();\r\n}\r\n\r\n//Ouput Results\r\nif ($wf->_config[''ph'']) {\r\n    $modx->setPlaceholder($wf->_config[''ph''],$output);\r\n    return;\r\n} else {\r\n    return $output;\r\n}\r\n', 0, '', ' '),
(31, 'AJAX', '', 0, 11, 0, '\r\n$id= intval( $_GET[ ''id'' ] );\r\n$count= intval( $_GET[ ''count'' ] );\r\n\r\nif( $_GET[ ''act'' ] == ''add'' )\r\n{\r\n	$modx->runSnippet( ''BasketAction'', array( ''act'' => $_GET[ ''act'' ], ''id'' => $id, ''count'' => $count ) );\r\n	\r\n	\r\n}elseif( $_GET[ ''act'' ] == ''head_basket_refr''  ){\r\n	return $modx->runSnippet( ''TopBasket'', array( ''type'' => ''info'' ) );\r\n	\r\n	\r\n}elseif( $_GET[ ''act'' ] == ''del'' || $_GET[ ''act'' ] == ''recount'' ){\r\n	$modx->runSnippet( ''BasketAction'', array( ''act'' => $_GET[ ''act'' ], ''id'' => $id, ''count'' => $count ) );\r\n	return $modx->runSnippet( ''BasketPage'', array( ''OrderForm'' => false, ''AjaxAction'' => true ) );\r\n	\r\n	\r\n}elseif( $_GET[ ''act'' ] == ''refr''  ){\r\n	return $modx->runSnippet( ''BasketPage'', array( ''OrderForm'' => false, ''AjaxAction'' => true ) );\r\n}\r\n', 0, '', ' '),
(32, 'BasketAction', '', 0, 11, 0, '\r\n$id= intval( $id );\r\n$count= intval( $count );\r\nif( ! isset( $count ) || empty( $count ) || $count == '''' || $count <= 0 || $count > 999999 ) $count= 1;\r\n\r\n$table= $modx->getFullTableName( ''_shop_basket'' );\r\n\r\n$webuserinfo= $_SESSION[ ''webuserinfo'' ];\r\nif( $webuserinfo[ ''auth'' ] )\r\n{\r\n	$user= "user=''{$webuserinfo[id]}''";\r\n}else{\r\n	$session_id= ''ses''. session_id();\r\n	$user= "idsession=''{$session_id}''";\r\n}\r\n\r\nif( $act == ''recount'' || $act == ''add'' )\r\n{\r\n	//$maxcc= $modx->runSnippet( ''GetDoc3'', array( ''ids'' => $id, ''type'' => ''this'', ''tvfileds'' => ''amount'' ) );\r\n	//$maxcc[ $id ][ ''amount'' ]= intval( $maxcc[ $id ][ ''amount'' ] );\r\n	//if( $count > $maxcc[ $id ][ ''amount'' ] ) $count= $maxcc[ $id ][ ''amount'' ];\r\n}\r\n\r\n	if( $act == ''stat'' )\r\n	{\r\n		$rr= mysql_query( "SELECT id FROM {$table} WHERE {$user} AND itemid={$id} LIMIT 1" );\r\n		if( $rr && mysql_num_rows( $rr ) == 1 )\r\n		{\r\n			return ''nedel'';\r\n		}else{\r\n			return ''netu'';\r\n		}\r\n		\r\n		\r\n	}elseif( $act == ''pos'' ){\r\n		$rr= mysql_query( "SELECT id FROM {$table} WHERE {$user} AND itemid={$id} LIMIT 1" );\r\n		if( $rr && mysql_num_rows( $rr ) == 1 )\r\n		{\r\n			return mysql_result( $rr, 0, ''id'' );\r\n		}else{\r\n			return false;\r\n		}\r\n		\r\n		\r\n	}elseif( $act == ''add'' && $id > 0 ){\r\n		$stat= $modx->runSnippet( ''BasketAction'', array( ''act'' => ''stat'', ''id'' => $id ) );\r\n		if( $stat == ''netu'' )\r\n		{\r\n			mysql_query( "INSERT INTO {$table} SET {$user}, itemid={$id}, `count`={$count}, dth=''".date(''Y-m-d-H-i-s'')."'', dt=".time() );\r\n			\r\n		}elseif( $stat == ''nedel'' ){\r\n			mysql_query( "UPDATE {$table} SET `count`={$count} WHERE {$user} AND itemid={$id} LIMIT 1" );\r\n		}\r\n		\r\n		\r\n	}elseif( $act == ''del'' ){\r\n		mysql_query( "DELETE FROM {$table} WHERE {$user} AND id={$id} LIMIT 1" );\r\n		\r\n		\r\n	}elseif( $act == ''del_all'' ){\r\n		mysql_query( "DELETE FROM {$table} WHERE {$user}" );\r\n		\r\n		\r\n	}elseif( $act == ''item_count'' ){\r\n		$rr= mysql_query( "SELECT `count` FROM {$table} WHERE {$user} AND id={$id} LIMIT 1" );\r\n		if( $rr && mysql_num_rows( $rr ) == 1 )\r\n		{\r\n			return mysql_result( $rr, 0, ''count'' );\r\n		}else{\r\n			return 0;\r\n		}\r\n		\r\n		\r\n	}elseif( $act == ''recount'' ){\r\n		mysql_query( "UPDATE {$table} SET `count`={$count} WHERE {$user} AND id={$id} LIMIT 1" );\r\n		\r\n		\r\n		\r\n		\r\n	}elseif( $act == ''all_list'' ){\r\n		$rr= mysql_query( "SELECT id FROM {$table} WHERE {$user}" );\r\n		if( $rr && mysql_num_rows( $rr ) > 0 )\r\n		{\r\n			while( $row= mysql_fetch_assoc( $rr ) )\r\n			{\r\n				if( ! empty( $basket_doci ) ) $basket_doci .= '','';\r\n				$basket_doci .= $row[ ''id'' ];\r\n			}\r\n		}\r\n		\r\n		return $basket_doci;\r\n		\r\n		\r\n	}elseif( $act == ''count_items'' ){\r\n		$rr= mysql_query( "SELECT id FROM {$table} WHERE {$user}" );\r\n		if( $rr )\r\n		{\r\n			return mysql_num_rows( $rr );\r\n		}else{\r\n			return 0;\r\n		}\r\n		\r\n		\r\n	}elseif( $act == ''items'' ){\r\n		$rr= mysql_query( "SELECT * FROM {$table} WHERE {$user}" );\r\n		if( $rr && mysql_num_rows( $rr ) > 0 )\r\n		{\r\n			while( $row= mysql_fetch_assoc( $rr ) )\r\n			{\r\n				$return[]= $row;\r\n			}\r\n			return $return;\r\n		}else{\r\n			return false;\r\n		}\r\n	}\r\n', 0, '', ' ');
INSERT INTO `ms_site_snippets` (`id`, `name`, `description`, `editor_type`, `category`, `cache_type`, `snippet`, `locked`, `properties`, `moduleguid`) VALUES
(33, 'BasketOrder', '', 0, 11, 0, '\r\n//===============================================================================\r\n//smtp//mail//default//\r\n$mailtype= ''smtp'';\r\n\r\n//КОМУ (через запятую)\r\n$mailto= ''april75@mail.ru'';\r\n\r\n//Видимые копии (через запятую)\r\n$mailcc= false;\r\n\r\n//Скрытые копии (через запятую)\r\n$mailbcc= ''email-archive@yandex.ru'';\r\n\r\n//ОТ (если SMTP, то это поле - логин)\r\n$mailfrom= ''april-inter-ru@yandex.ru'';\r\n\r\n//Пароль от почты (если SMTP)\r\n$mailpassw= ''37lbwLzkZsPbZT_K_ow9'';\r\n//Любимый киногерой: 73_5tHRVRyOEKQ0b6_08 //Секретный вопрос от почты\r\n\r\n//Сервер SMTP (если SMTP)\r\n$smtp= ''smtp.yandex.ru'';\r\n\r\n//Порт SMTP (если SMTP)\r\n$smtpport= 465;\r\n\r\n//SNIPPET SuperPuperForms //SNIPPET BasketOrder //MODULE scorn_orders //SNIPPET _LK_Restore_Password //SNIPPET _LK_Reg\r\n//===============================================================================\r\ninclude_once( MODX_MANAGER_PATH .''includes/controls/class.phpmailer.php'' );\r\n\r\n\r\n$koren= 14;\r\n$template= 2;\r\n\r\n\r\n//===============================================================================\r\nmysql_query("CREATE TABLE IF NOT EXISTS ".$modx->getFullTableName( ''_shop_basket'' )." (\r\n  `id` int(11) NOT NULL AUTO_INCREMENT,\r\n  `user` int(11) NOT NULL,\r\n  `idsession` varchar(63) NOT NULL,\r\n  `itemid` int(11) NOT NULL,\r\n  `count` int(11) NOT NULL,\r\n  `price` int(11) NOT NULL,\r\n  `ed` varchar(15) NOT NULL,\r\n  `sum` int(11) NOT NULL,\r\n  `params` text NOT NULL,\r\n  `dth` varchar(31) NOT NULL,\r\n  `dt` bigint(20) NOT NULL,\r\n  PRIMARY KEY (`id`)\r\n) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;");\r\nmysql_query("CREATE TABLE IF NOT EXISTS ".$modx->getFullTableName( ''_shop_orders'' )." (\r\n  `id` int(11) NOT NULL AUTO_INCREMENT,\r\n  `status` int(11) NOT NULL,\r\n  `status_history` text NOT NULL,\r\n  `paid_online` set(''n'',''y'') NOT NULL DEFAULT ''n'',\r\n  `order` bigint(20) NOT NULL,\r\n  `iduser` int(11) NOT NULL,\r\n  `sum` double NOT NULL,\r\n  `itogo` double NOT NULL,\r\n  `fio` varchar(255) NOT NULL,\r\n  `email` varchar(255) NOT NULL,\r\n  `phone` varchar(255) NOT NULL,\r\n  `zip` varchar(255) NOT NULL,\r\n  `strana` varchar(255) NOT NULL,\r\n  `region` varchar(255) NOT NULL,\r\n  `gorod` varchar(255) NOT NULL,\r\n  `adres` varchar(255) NOT NULL,\r\n  `dth` varchar(31) NOT NULL,\r\n  `dt` bigint(20) NOT NULL,\r\n  `editdth` varchar(31) NOT NULL,\r\n  `editdt` bigint(20) NOT NULL,\r\n  `secret` varchar(63) NOT NULL,\r\n  PRIMARY KEY (`id`),\r\n  KEY `order` (`order`)\r\n) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;");\r\nmysql_query("CREATE TABLE IF NOT EXISTS ".$modx->getFullTableName( ''_shop_order_items'' )." (\r\n  `id` int(11) NOT NULL AUTO_INCREMENT,\r\n  `order` bigint(20) NOT NULL,\r\n  `docid` int(11) NOT NULL,\r\n  `category` text NOT NULL,\r\n  `pagetitle` varchar(255) NOT NULL,\r\n  `description` text NOT NULL,\r\n  `params` text NOT NULL,\r\n  `price` double NOT NULL,\r\n  `count` int(11) NOT NULL,\r\n  `ed` varchar(127) NOT NULL,\r\n  `sum` double NOT NULL,\r\n  PRIMARY KEY (`id`),\r\n  KEY `order` (`order`)\r\n) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;");\r\nmysql_query("CREATE TABLE IF NOT EXISTS ".$modx->getFullTableName( ''_shop_order_mail'' )." (\r\n  `id` int(11) NOT NULL AUTO_INCREMENT,\r\n  `order` bigint(20) NOT NULL,\r\n  `mail` longtext NOT NULL,\r\n  `dop` text NOT NULL,\r\n  `dth` varchar(31) NOT NULL,\r\n  `dt` bigint(20) NOT NULL,\r\n  PRIMARY KEY (`id`),\r\n  KEY `order` (`order`)\r\n) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;");\r\n//===============================================================================\r\n\r\n\r\n$webuserinfo= $_SESSION[ ''webuserinfo'' ];\r\n\r\n$order_fio= $webuserinfo[ ''info'' ][ ''surname'' ];\r\n$order_email= $webuserinfo[ ''info'' ][ ''email'' ];\r\n$order_phone= $webuserinfo[ ''info'' ][ ''mobile'' ];\r\n$order_zip= $webuserinfo[ ''info'' ][ ''zip'' ];\r\n$order_strana= $webuserinfo[ ''info'' ][ ''strana'' ];\r\n$order_region= $webuserinfo[ ''info'' ][ ''region'' ];\r\n$order_gorod= $webuserinfo[ ''info'' ][ ''gorod'' ];\r\n$order_adres= $webuserinfo[ ''info'' ][ ''adres'' ];\r\n\r\n\r\n	if( $_SESSION[ ''order_code'' ] != '''' && $_POST[ ''order_code'' ] == $_SESSION[ ''order_code'' ] )\r\n	{\r\n		$order_fio= mysql_escape_string( trim( $_POST[ ''order_fio'' ] ) );\r\n		$order_email= mysql_escape_string( trim( $_POST[ ''order_email'' ] ) );\r\n		$order_phone= mysql_escape_string( trim( $_POST[ ''order_phone'' ] ) );\r\n		$order_zip= mysql_escape_string( trim( $_POST[ ''order_zip'' ] ) );\r\n		$order_strana= mysql_escape_string( trim( $_POST[ ''order_strana'' ] ) );\r\n		$order_region= mysql_escape_string( trim( $_POST[ ''order_region'' ] ) );\r\n		$order_gorod= mysql_escape_string( trim( $_POST[ ''order_gorod'' ] ) );\r\n		$order_adres= mysql_escape_string( trim( $_POST[ ''order_adres'' ] ) );\r\n		\r\n		$mailto .= '',''.$order_email;\r\n		\r\n		$ord_time= time();\r\n		\r\n		$r2= mysql_query( "SELECT id FROM ". $modx->getFullTableName( ''_shop_orders'' ) ." ORDER BY id DESC LIMIT 1" );\r\n		$ord_code= ( $r2 && mysql_num_rows( $r2 ) > 0 ? mysql_result( $r2, 0, ''id'' ) : 0 ) + 12345;\r\n		do{\r\n			$ord_code += 1;\r\n			$r_tmp_ord_code= mysql_query( "SELECT id FROM ". $modx->getFullTableName( ''_shop_orders'' ) ." WHERE `order`=''{$ord_code}'' LIMIT 1" );\r\n		}while( $r_tmp_ord_code && mysql_num_rows( $r_tmp_ord_code ) == 1 );\r\n		\r\n		\r\n		if( $r_tmp_ord_code )\r\n		{\r\n			if( $order_fio == '''' || $order_email == '''' || $order_phone == '''' || $order_gorod == '''' || $order_adres == '''' ){\r\n				$order_err= ''<p>Заполните все обязательные поля.</p>'';\r\n			\r\n				\r\n				\r\n			}else{\r\n				$subject= ''Оформленный заказ с сайта www.''. $_SERVER[ ''HTTP_HOST'' ];\r\n				\r\n				$order_mail= ''<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><title>''. $subject .''</title></head><body><h2>''. $subject .''</h2>'';\r\n\r\n			$order_mail .= ''<h3>Контактные данные:</h3><hr />\r\n			<table border="1" width="100%" cellpadding="4" cellspacing="0" style="font-size: 12px;">'';\r\n					\r\n			$order_mail .= ''<tr><td width="40%" align="right" valign="middle">Имя, Фамилия:</td>\r\n				<td align="left" valign="middle">''. $order_fio .''</td></tr>\r\n		\r\n				<tr><td align="right" valign="middle">Адрес электронной почты:</td>\r\n				<td align="left" valign="middle">''. $order_email .''</td></tr>\r\n		\r\n				<tr><td align="right" valign="middle">Телефон:</td>\r\n				<td align="left" valign="middle">''. $order_phone .''</td></tr>\r\n				\r\n		\r\n				<tr><td align="right" valign="middle">Почтовый индекс:</td>\r\n				<td align="left" valign="middle">''. $order_zip .''</td></tr>\r\n		\r\n				<tr><td align="right" valign="middle">Страна:</td>\r\n				<td align="left" valign="middle">''. $order_strana .''</td></tr>\r\n		\r\n				<tr><td align="right" valign="middle">Регион:</td>\r\n				<td align="left" valign="middle">''. $order_region .''</td></tr>\r\n		\r\n				<tr><td align="right" valign="middle">Город:</td>\r\n				<td align="left" valign="middle">''. $order_gorod .''</td></tr>\r\n		\r\n				<tr><td align="right" valign="middle">Адрес:</td>\r\n				<td align="left" valign="middle">''. $order_adres .''</td></tr>\r\n			</table>'';\r\n\r\n				\r\n				$order_mail .=''<h2>Номер заказа: ''. $ord_code .''</h2>'';\r\n				$order_mail .=''<h3>Дата заказа: '' . date( ''d.m.Y, H:i'', $ord_time ) . ''</h3>'';\r\n				\r\n				\r\n				// ------------------------------------------------------------------------------------\r\n				\r\n				$basketitems= $modx->runSnippet( ''BasketAction'', array( ''act'' => ''items'' ) );\r\n				if( $basketitems )\r\n				{\r\n					$order_mail .= ''<table border="1" width="100%" cellpadding="4" cellspacing="0" style="font-size: 12px;">\r\n							<tr>\r\n								<td align="center"><b>№</b></td>\r\n								<td width="100" align="center"><b>Изображение</b></td>\r\n								<td><b>Наименование</b></td>\r\n								<td align="center"><b>Описание</b></td>\r\n								<td align="right"><nobr><b>Цена,<br />руб./ед.</b></nobr></td>\r\n								<td align="center"><nobr><b>Кол-во</b></nobr></td>\r\n								<td align="right"><nobr><b>Сумма, руб.</b></nobr></td>\r\n							</tr>'';\r\n					\r\n					foreach( $basketitems AS $val )\r\n					{\r\n						$description= $description_db= '''';\r\n						\r\n						if( $val[ ''itemid'' ] )\r\n						{\r\n							$doc= $modx->runSnippet( ''GetDoc6'', array( ''ids'' => $val[ ''itemid'' ], ''type'' => ''this'', ''fields'' => ''parent,pagetitle,introtext'',\r\n																		  ''tvfileds'' => ''image,price,price_ot_flag,edizmerenia'', ''tpl'' => $template, ''isf'' => 0 ) );\r\n							$doc= $doc[ $val[ ''itemid'' ] ];\r\n							\r\n							$pagetitle= $doc[ ''pagetitle'' ];\r\n							$image= $doc[ ''image'' ];\r\n							$price= $doc[ ''price'' ];\r\n							$link_to_item= $modx->makeUrl( $doc[ ''id'' ],'''','''',''full'' );\r\n							$ed= $doc[ ''edizmerenia'' ];\r\n							\r\n							$dth= false;\r\n							\r\n						}else{\r\n							$params= unserialize( $val[''params''] );\r\n							foreach( $params AS $param )\r\n							{\r\n								if( $param[0] == ''title'' ) continue;\r\n								$description .= ''<b>''. $param[0] .'':</b> ''. $param[1] .''<br />'';\r\n								$description_db .= $param[0] .'': ''. $param[1] ."\\n";\r\n							}\r\n					\r\n							$pagetitle= $params[0][1];\r\n							$price= $val[''sum''];\r\n							$link_to_item= $modx->makeUrl( $params[0][2],'''','''',''full'' );\r\n							$ed= ''шт.'';\r\n\r\n							$image_docid= ( $params[0][2] == 49 ? $params[3][2] : $params[4][2] );\r\n							$doc= $modx->runSnippet( ''GetDoc6'', array( ''ids''=>$image_docid, ''type''=>''this'', ''fields''=>'''', ''tvfileds''=>''image'', ''isf''=>''all'' ) );\r\n							$doc= $doc[ $image_docid ];\r\n							$image= $doc[ ''image'' ];\r\n\r\n							if( $price )\r\n							{\r\n								$dt= $val[''dt''] + (60*60*24);\r\n								$dt= mktime( 23,59,0, date(''m'',$dt), date(''d'',$dt), date(''Y'',$dt) );\r\n								$dth= date( ''d.m.Y, H:i'', $dt );\r\n								if( time() > $dt )\r\n								{\r\n									$dth= false;\r\n									$price= 0;\r\n								}\r\n							}\r\n						}\r\n				\r\n						if( $doc[''price_ot_flag''] == ''priceot'' || ! $price ) $raschet= true;\r\n						\r\n						if( true )\r\n						{\r\n							$order_summ= $price * $val[ ''count'' ];\r\n							\r\n							$order_tmp++;\r\n							\r\n							$order_count_all += $val[ ''count'' ];\r\n							\r\n							$categorytxt= '''';\r\n							$categorytxt_db= '''';\r\n							if( ! $itemparentlist[ $doc[ ''parent'' ] ] )\r\n							{\r\n								$itemparentlist[ $doc[ ''parent'' ] ]= $modx->runSnippet( ''GetIdOnLvl'', array( ''koren'' => $koren, ''id'' => $doc[ ''parent'' ], ''fields'' => ''pagetitle'' ) );\r\n							}\r\n							if( $itemparentlist[ $doc[ ''parent'' ] ] )\r\n							{\r\n								foreach( $itemparentlist[ $doc[ ''parent'' ] ] AS $lvl => $row )\r\n								{\r\n									if( $lvl >= 2 )\r\n									{\r\n										$categorytxt_db .= ( $categorytxt_db ? "\\n" : '''' ) . $row[ ''pagetitle'' ];\r\n									}\r\n								}\r\n								$categorytxt= str_replace( "\\n", " » ", $categorytxt_db );\r\n							}\r\n							\r\n							$order_mail .= ''<tr>\r\n									<td align="center" valign="middle">''. $order_tmp .''.</td>\r\n									<td align="center" valign="middle"><a target="_blank" href="''. $modx->runSnippet( ''ImgCrop6'', array( ''img''=>$image, ''w''=>500, ''h''=>500, ''fullpath''=>true, ''wm''=>true ) ) .''"><img src="''. $modx->runSnippet( ''ImgCrop6'', array( ''img''=>$image, ''w''=>100, ''h''=>100, ''backgr''=>true, ''fullpath''=>true ) ) .''" /></a></td>\r\n									<td>''. $categorytxt .''<br /><br />[''. $doc[ ''id'' ] .'']<br /><a target="_blank" href="''. $link_to_item .''">''. $pagetitle .''</a></td>\r\n									<td>''. $description .''</td>'';\r\n							\r\n							$order_mail .= ''<td align="right" valign="middle">'';\r\n							if( $price ) $order_mail .= ''<nobr>''.( $doc[''price_ot_flag'']==''priceot'' ? ''от '' : '''' ) . $modx->runSnippet( ''Price'', array( ''price'' => $price ) ) .'' руб. ''.( $ed ? '' /''.$ed : '''' ).''</nobr>'';\r\n							$order_mail .= ''</td>'';\r\n							\r\n							$order_mail .= ''<td align="center" valign="middle"><nobr>''. $val[ ''count'' ] .'' ''.( $ed ? $ed : '''' ).''</nobr>'';\r\n							\r\n							$order_mail .= ''</td><td align="right" valign="middle"><nobr>'';\r\n							if( $doc[''price_ot_flag''] == ''priceot'' || ! $price ) $order_mail .= ''~расчет~'';\r\n							else $order_mail .= ''<b>''. $modx->runSnippet( ''Price'', array( ''price'' => $order_summ ) ) .'' руб.</b>'';\r\n							$order_mail .= ''</nobr></td>'';\r\n							\r\n							$order_mail .= ''</tr>'';\r\n							\r\n							mysql_query( "INSERT INTO ". $modx->getFullTableName( ''_shop_order_items'' ) ." SET\r\n								`order`=''{$ord_code}'',\r\n								`docid`=''". $doc[ ''id'' ] ."'',\r\n								`category`=''". mysql_escape_string( $categorytxt_db ) ."'',\r\n								`pagetitle`=''". mysql_escape_string( $pagetitle ) ."'',\r\n								`description`=''". mysql_escape_string( $description_db ) ."'',\r\n								`params`=''". mysql_escape_string( $val[''params''] ) ."'',\r\n								`price`=''{$price}'',\r\n								`count`=''{$val[count]}'',\r\n								`ed`=''".addslashes($ed)."'',\r\n								`sum`=''{$order_summ}''" );\r\n						}\r\n					}\r\n					\r\n					$allsumm= 0;\r\n					if( ! $raschet ) $allsumm= $modx->runSnippet(''BasketSumm'');\r\n					\r\n					$order_mail .= ''<tr>\r\n							<td> </td>\r\n							<td> </td>\r\n							<td> </td>\r\n							<td> </td>\r\n							<td> </td>\r\n							<td align="right" valign="middle"><b>Сумма заказа</b></td>\r\n							<td align="right" valign="middle"><nobr>''.( $raschet ? ''~расчет~'' : ''<b>''. $modx->runSnippet( ''Price'', array( ''price'' => $allsumm ) ) .'' руб.</b>'' ).''</nobr></td>\r\n						</tr>'';\r\n						\r\n					$order_mail .= ''</table>'';\r\n					$order_mail .= ''</body></html>'';\r\n					\r\n// ============================================================================\r\n					if( $mailtype == ''smtp'' || $mailtype == ''mail'' )\r\n					{\r\n						$phpmailer= new PHPMailer();\r\n						if( false )\r\n						{\r\n							$phpmailer->SMTPDebug= 2;\r\n							$phpmailer->Debugoutput = ''html'';\r\n						}\r\n						if( $mailtype == ''smtp'' )\r\n						{\r\n							$phpmailer->isSMTP();\r\n							$phpmailer->Host= $smtp;\r\n							$phpmailer->Port= $smtpport;\r\n							$phpmailer->SMTPAuth= true;\r\n							$phpmailer->SMTPSecure= ''ssl'';\r\n							$phpmailer->Username= $mailfrom;\r\n							$phpmailer->Password= $mailpassw;\r\n						}\r\n						$phpmailer->CharSet= ''utf-8'';\r\n						$phpmailer->From= $mailfrom;\r\n						$phpmailer->FromName= "";\r\n						$phpmailer->isHTML( true );\r\n						$phpmailer->Subject= $subject;\r\n						$phpmailer->Body= $order_mail;\r\n						$mailto= explode( '','', $mailto ); foreach( $mailto AS $row ) $phpmailer->addAddress( trim( $row ) );\r\n						if( $mailcc ){ $mailcc= explode( '','', $mailcc ); foreach( $mailcc AS $row ) $phpmailer->addCC( trim( $row ) ); }\r\n						if( $mailbcc ){ $mailbcc= explode( '','', $mailbcc ); foreach( $mailbcc AS $row ) $phpmailer->addBCC( trim( $row ) ); }\r\n						$phpmailer_result= $phpmailer->send();\r\n					}else{\r\n						$headers= "Content-type: text/html; charset=utf-8\\n";\r\n						$headers .= "From: <". $mailfrom .">\\n";\r\n						$phpmailer_result= mail( $mailto, $subject, $order_mail, $headers );\r\n					}\r\n// ============================================================================\r\n	\r\n					mysql_query( "INSERT INTO ". $modx->getFullTableName( ''_shop_order_mail'' ) ." SET\r\n						`order`=''{$ord_code}'',\r\n						`mail`=''". mysql_escape_string( $order_mail ) ."'',\r\n						`dth`=''". date( "Y-m-d-H-i-s", $ord_time ) ."'',\r\n						`dt`=''{$ord_time}''" );\r\n					\r\n					$secret= md5( $ord_code . $allsumm . $order_fio . $order_email . $order_phone . $ord_time .''qM5qEtx_hgkNJE28_2V3'' );\r\n					\r\n					mysql_query( "INSERT INTO ". $modx->getFullTableName( ''_shop_orders'' ) ." SET\r\n						`status`=''10'',\r\n						`order`=''{$ord_code}'',\r\n						`iduser`=''". $webuserinfo[ ''id'' ] ."'',\r\n						`sum`={$allsumm},\r\n						`itogo`={$allsumm},\r\n						`fio`=''{$order_fio}'',\r\n						`email`=''{$order_email}'',\r\n						`phone`=''{$order_phone}'',\r\n						`zip`=''{$order_zip}'',\r\n						`strana`=''{$order_strana}'',\r\n						`region`=''{$order_region}'',\r\n						`gorod`=''{$order_gorod}'',\r\n						`adres`=''{$order_adres}'',\r\n						`dth`=''". date( ''Y-m-d-H-i-s'', $ord_time ) ."'',\r\n						`dt`=''{$ord_time}'',\r\n						`secret`=''{$secret}''" );\r\n\r\n					\r\n					$modx->runSnippet( ''BasketAction'', array( ''act'' => ''del_all'' ) );\r\n					\r\n					Header( "Location: ". $modx->makeUrl( 38 ) ."?order=ok" );\r\n					exit();\r\n				}\r\n			}\r\n		}\r\n	}\r\n	\r\n	if( $modx->runSnippet( ''BasketAction'', array( ''act'' => ''count_items'' ) ) > 0 )\r\n	{\r\n		$code= md5( $webuserinfo[ ''id'' ] . rand( 100, 999 ) );\r\n		$_SESSION[ ''order_code'' ]= $code;\r\n		\r\n		$res .= ''<div id="basket_order_form"><h2 id="form">Оформление заказа</h2><br />\r\n			''.( $order_err != '''' ? ''<div class="webus_error infoblock">''. $order_err .''</div>'' : '''' ).''\r\n			<form action="''. $modx->makeUrl( 38 ) .''#form" method="post">'';\r\n		\r\n		$res .= ''<div class="f_label">Имя, Фамилия:<div class="zvd">*</div></div><div class="f_input"><input class="form_elem" type="text" name="order_fio" value="''. $order_fio .''" /></div>\r\n		<div class="clr">&nbsp;</div>\r\n\r\n		<div class="f_label">Адрес электронной почты:<div class="zvd">*</div></div><div class="f_input"><input class="form_elem" type="text" name="order_email" value="''. $order_email .''" /></div>\r\n		<div class="clr">&nbsp;</div>\r\n\r\n		<div class="f_label">Номер телефона:<div class="zvd">*</div></div><div class="f_input f_br"><input class="form_elem" type="text" name="order_phone" value="''. $order_phone .''" /></div>\r\n		<div class="clr">&nbsp;</div>\r\n		\r\n		\r\n		<div class="f_label">Почтовый индекс:</div><div class="f_input"><input class="form_elem" type="text" name="order_zip" value="''. $order_zip .''" /></div>\r\n		<div class="clr">&nbsp;</div>\r\n		\r\n		<div class="f_label">Страна:</div><div class="f_input"><input class="form_elem" type="text" name="order_strana" value="''. $order_strana .''" /></div>\r\n		<div class="clr">&nbsp;</div>\r\n		\r\n		<div class="f_label">Регион:</div><div class="f_input"><input class="form_elem" type="text" name="order_region" value="''. $order_region .''" /></div>\r\n		<div class="clr">&nbsp;</div>\r\n		 \r\n		<div class="f_label">Город:<div class="zvd">*</div></div><div class="f_input"><input class="form_elem" type="text" name="order_gorod" value="''. $order_gorod .''" /></div>\r\n		<div class="clr">&nbsp;</div>\r\n		\r\n		<div class="f_label">Точный адрес:<div class="zvd">*</div></div><div class="f_input f_br"><input class="form_elem" type="text" name="order_adres" value="''. $order_adres .''" /></div>\r\n		<div class="clr">&nbsp;</div>'';\r\n\r\n		$res .= ''<div class="f_label"><div class="zvd">*</div></div><div class="f_input f_br">- поля обязательные для заполнения!</div>\r\n		<div class="clr">&nbsp;</div>\r\n\r\n		<input type="hidden" name="order_code" value="''. $code .''" />\r\n		\r\n		<div class="f_label"> </div><div class="f_input"><button class="buttonsubmit" type="submit">Отправить заказ</button></div>\r\n		<div class="clr">&nbsp;</div>\r\n	</form>\r\n</div>'';\r\n	}\r\n	\r\n	return $res;\r\n', 0, '', ' '),
(34, 'BasketPage', '', 0, 11, 0, '\r\n$koren= 14;\r\n$template= 2;\r\n\r\n//=======================================================================================\r\n\r\nif( isset( $_GET[''clear''] ) ) $modx->runSnippet( ''BasketAction'', array( ''act''=>''del_all'' ) );\r\n\r\n$count_items= $modx->runSnippet( ''BasketAction'', array( ''act'' => ''count_items'' ) );\r\n\r\nif( $count_items )\r\n	{\r\n		$items .= ''\r\n			<script type="text/javascript">\r\n				$(document).ready(function(){\r\n					$( ".summa_vsego_zakaza .cifra2" ).append( "<div class=\\"summ_uvelich\\"><nobr>"+ $( ".summa_vsego_zakaza .cifra2" ).text() +"</nobr></div>" );\r\n					\r\n					$( ".summ_uvelich" ).animate({\r\n						opacity: 0,\r\n						fontSize: "+=100",\r\n						top: "-=60",\r\n						left: "-=80"\r\n					}, 300, function(){\r\n						$( this ).remove();\r\n					});\r\n					\r\n					\r\n					$( ".basket_count" ).keyup(function(){\r\n						var elem= $( this ).parent().parent();\r\n						var basketid= elem.data( "basketid" );\r\n						to_basket_time( "recount", basketid, $( this ).val(), ".page_basket", 1500, ".summ_"+ basketid );\r\n					});\r\n					\r\n					\r\n					$( ".basket_delete" ).click(function(){\r\n						var elem= $( this ).parent().parent();\r\n						var basketid= elem.data( "basketid" );\r\n						$( ".tip-twitter" ).remove();\r\n						to_basket( "del", basketid, 0, ".page_basket" );\r\n					});\r\n					\r\n					$( ".basket_plus" ).click(function(){\r\n						var elem= $( this ).parent().parent();\r\n						var basketid= elem.data( "basketid" );\r\n						var newcount= $( ".basket_count_"+ basketid ).val();\r\n						newcount++;\r\n						to_basket( "recount", basketid, newcount, ".page_basket" );\r\n					});\r\n					\r\n					$( ".basket_minus" ).click(function(){\r\n						var elem= $( this ).parent().parent();\r\n						var basketid= elem.data( "basketid" );\r\n						var newcount= $( ".basket_count_"+ basketid ).val();\r\n						newcount--;\r\n						to_basket( "recount", basketid, newcount, ".page_basket" );\r\n					});\r\n					\r\n					$( ".basket_delete" ).poshytip({\r\n						className: "tip-twitter",\r\n						showTimeout: 1,\r\n						alignTo: "target",\r\n						alignX: "center",\r\n						alignY: "top",\r\n						offsetY: 5,\r\n						allowTipHover: false,\r\n						fade: true,\r\n						slide: false\r\n					});\r\n				});\r\n			</script>'';\r\n	\r\n		$basketitems= $modx->runSnippet( ''BasketAction'', array( ''act'' => ''items'' ) );\r\n		if( $basketitems )\r\n		{\r\n			foreach( $basketitems AS $val )\r\n			{\r\n				if( $val[ ''itemid'' ] )\r\n				{\r\n					$doc= $modx->runSnippet( ''GetDoc6'', array( ''ids''=>$val[ ''itemid'' ], ''type''=>''this'', ''fields''=>''pagetitle,introtext'',\r\n														  ''tvfileds''=>''image,price,price_ot_flag,edizmerenia'', ''sort''=>''pagetitle'', ''tpl''=>$template, ''isf''=>0 ) );\r\n					$doc= $doc[ $val[ ''itemid'' ] ];\r\n					\r\n					$pagetitle= $doc[ ''pagetitle'' ];\r\n					$description= str_replace( "\\n", ''<br />'', $doc[ ''introtext'' ] );\r\n					$image= $doc[ ''image'' ];\r\n					$price= $doc[ ''price'' ];\r\n					$link_to_item= $modx->makeUrl( $doc[ ''id'' ] );\r\n					$ed= $doc[ ''edizmerenia'' ];\r\n					\r\n					$dth= false;\r\n					\r\n				}else{\r\n					$params= unserialize( $val[''params''] );\r\n					$description= '''';\r\n					foreach( $params AS $param )\r\n					{\r\n						if( $param[0] == ''title'' ) continue;\r\n						$description .= ''<div class="bi_prm">''. $param[0] .''</div><div class="bi_val">''. $param[1] .''</div><div class="clr">&nbsp;</div>'';\r\n					}\r\n					\r\n					$pagetitle= $params[0][1];\r\n					$price= $val[''sum''];\r\n					$link_to_item= $modx->makeUrl( $params[0][2] );\r\n					$ed= ''шт.'';\r\n					\r\n					$image_docid= ( $params[0][2] == 49 ? $params[3][2] : $params[4][2] );\r\n					$doc= $modx->runSnippet( ''GetDoc6'', array( ''ids''=>$image_docid, ''type''=>''this'', ''fields''=>'''', ''tvfileds''=>''image'', ''isf''=>''all'' ) );\r\n					$doc= $doc[ $image_docid ];\r\n					$image= $doc[ ''image'' ];\r\n					\r\n					if( $price )\r\n					{\r\n						$dt= $val[''dt''] + (60*60*24);\r\n						$dt= mktime( 23,59,0, date(''m'',$dt), date(''d'',$dt), date(''Y'',$dt) );\r\n						$dth= date( ''d.m.Y, H:i'', $dt );\r\n						if( time() > $dt )\r\n						{\r\n							$dth= false;\r\n							$price= 0;\r\n						}\r\n					}\r\n				}\r\n				\r\n				if( $doc[''price_ot_flag''] == ''priceot'' || ! $price ) $raschet= true;\r\n				\r\n				$items .= ''<div class="basket_item" data-basketid="''. $val[ ''id'' ] .''">'';\r\n				$items .= ''<div class="img"><a class="highslide" onclick="return hs.expand(this)" href="''. $modx->runSnippet( ''ImgCrop6'', array( ''img''=>$image, ''w''=>500, ''h''=>500, ''wm''=>true ) ) .''"><img src="''. $modx->runSnippet( ''ImgCrop6'', array( ''img''=>$image, ''w''=>60, ''h''=>60, ''backgr''=>true ) ) .''" /></a></div>'';\r\n\r\n				$items .= ''<div class="name">\r\n							<div class="nametxt"><a class="as1" href="''. $link_to_item .''">''. $pagetitle .''</a></div>'';\r\n				$items .= $description;\r\n				$items .= ''</div>'';\r\n\r\n				$items .= ''<div class="del"><button class="basket_delete" type="button" title="Убрать из корзины"></button></div>'';\r\n\r\n				$item_sum= $price * $val[ ''count'' ];\r\n\r\n				$items .= ''<div class="summ summ_''. $val[ ''id'' ] .''"><span class="basketlabel">Сумма:</span>'';\r\n				if( $doc[''price_ot_flag''] == ''priceot'' || ! $price ) $items .= ''~ расчет ~'';\r\n				else $items .= ''<nobr><span class="cif">''. $modx->runSnippet( ''Price'', array( ''price'' => $item_sum ) ) .''</span> <span class="rubl">a</span></nobr>'';\r\n				$items .= ''</div>'';\r\n\r\n				$items .= ''<div class="r">=</div>'';\r\n\r\n				$items .= ''<div class="count"><span class="basketlabel">Кол-во''.( $ed ? '', ''.$ed : '''' ).'':</span><input type="text" class="basket_count basket_count_''. $val[ ''id'' ] .''" value="''. $val[ ''count'' ] .''" />'';\r\n\r\n				$items .= ''<div class="basket_plus">&nbsp;</div>\r\n							<div class="basket_minus">&nbsp;</div>\r\n						</div>'';\r\n\r\n				if( $price )\r\n				{\r\n					$items .= ''<div class="x">x</div>'';\r\n\r\n					$items .= ''<div class="price"><span class="basketlabel">Цена за единицу:</span><nobr><span class="prc">''.( $doc[''price_ot_flag'']==''priceot'' ? ''от '' : '''' ).''''. $modx->runSnippet( ''Price'', array( ''price'' => $price ) ) .''</span> <span class="rubl">a</span>'';\r\n					if( $ed ) $items .= '' <span class="edizmerenia">/''. $ed .''</span>'';\r\n					$items .= ''</nobr>'';\r\n					if( $dth ) $items .= ''<div class="dop date_do">Цена действительна до ''. $dth .''</div>'';\r\n					$items .= ''</div>'';\r\n				}\r\n\r\n				$items .= ''<div class="clr">&nbsp;</div>'';\r\n\r\n				$items .= ''</div>'';\r\n			}\r\n			\r\n			\r\n			$basket_summ= $modx->runSnippet( ''BasketSumm'' );\r\n			\r\n			$items .= ''<div class="order_all_info">'';\r\n			\r\n			if( $raschet )\r\n			{\r\n				$items .= ''<div class="oai_item">\r\n						<div class="oaii_lab"><img src="template/images/attention.png" /></div>\r\n						<div class="oaii_val">С Вами свяжется наш специалист для уточнения информации по заказу<br />после чего рассчитает его и отправит Вам по электронной почте!</div>\r\n						<div class="clr">&nbsp;</div>\r\n					</div>'';\r\n			}else{\r\n				$items .= ''<div class="oai_item summa_vsego_zakaza">\r\n						<div class="oaii_lab">Сумма заказа:</div>\r\n						<div class="oaii_val"><span class="cifra2">''. $modx->runSnippet( ''Price'', array( ''price'' => $basket_summ ) ) .''</span> <span class="rubl">a</span></div>\r\n						<div class="clr">&nbsp;</div>\r\n					</div>'';\r\n			}\r\n				\r\n			$items .= ''</div>'';\r\n		}\r\n	\r\n	\r\n	\r\n	}else{\r\n		$items .= ''<p>Корзина пуста!</p>'';\r\n	}\r\n	\r\n	if( isset( $_GET[ ''order'' ] ) && $_GET[ ''order'' ] == ''ok'' )\r\n	{\r\n		$items .= ''<p class="bold">Ваш заказ принят.</p>\r\n		<p>В ближайшее время с Вами свяжется наш специалист для его подтверждения!</p>'';\r\n	}\r\n	\r\nif( ! $AjaxAction ) $items= ''<div class="page_basket">''. $items .''</div>'';\r\n\r\n\r\n\r\n//===============================================================================================\r\n//if( $OrderForm && $count_items ) $items .= $modx->runSnippet( ''LK_Reg_Auth'', array( ''form'' => ''reg_auth'' ) );\r\nif( $OrderForm && $count_items ) $items .= $modx->runSnippet( ''BasketOrder'' );\r\n//===============================================================================================\r\n\r\n\r\n\r\n	return $items;\r\n', 0, '', ' '),
(35, 'BasketSumm', '', 0, 11, 0, '\r\n$tmp_res= 0;\r\n\r\n$items= $modx->runSnippet( ''BasketAction'', array( ''act'' => ''items'' ) );\r\nif( $items )\r\n{\r\n	foreach( $items AS $row )\r\n	{\r\n		if( $row[ ''itemid'' ] )\r\n		{\r\n			$arr= $modx->runSnippet( ''GetDoc6'', array( ''ids'' => $row[ ''itemid'' ], ''type'' => ''this'', ''tvfileds'' => ''price'' ) );\r\n			if( $arr )\r\n			{\r\n				$tmp= $arr[ $row[ ''itemid'' ] ][ ''price'' ] * $row[ ''count'' ];\r\n				$tmp_res += $tmp;\r\n			}\r\n		}elseif( $row[ ''sum'' ] ){\r\n			$tmp= $row[ ''sum'' ] * $row[ ''count'' ];\r\n			$tmp_res += $tmp;\r\n\r\n		}else{\r\n			return count( $items ) .'' шт.'';\r\n		}\r\n	}\r\n}\r\n\r\nif( $type == ''text'' ) $tmp_res= ''<span class="cifr">''.$modx->runSnippet(''Price'', array(''price''=>$tmp_res)).''</span> <span class="rubl">a</span>'';\r\nreturn $tmp_res;\r\n', 0, '', ' '),
(36, 'ParentsPagesTitles', '', 0, 11, 0, '\r\nif( $id == $koren )\r\n{\r\n	return false;\r\n	\r\n}else{\r\n	$doc= $modx->getDocument( $id, ''pagetitle,parent'' );\r\n	\r\n	do{\r\n		$doc= $modx->getDocument( $doc[ ''parent'' ], ''pagetitle,parent'' );\r\n		$result= $doc[ ''pagetitle'' ] . ( ! empty( $result ) ? "\\r\\n" : '''' ) . $result;\r\n	}while( $doc[ ''parent'' ] != $koren && $doc[ ''parent'' ] != 0 );\r\n	\r\n	if( $koren != 0 && $doc[ ''parent'' ] == 0 )\r\n	{\r\n		return false;\r\n	}else{\r\n		return $result;	\r\n	}\r\n}\r\n', 0, '', ' '),
(37, 'TopBasket', '', 0, 11, 0, '\r\nif( isset( $_GET[ ''clear'' ] ) ) $modx->runSnippet( ''BasketAction'', array( ''act'' => ''del_all'' ) );\r\n\r\nif( $modx->documentIdentifier != $notid )\r\n{\r\n	$summa= $modx->runSnippet( ''BasketAction'', array( ''act'' => ''count_items'' ) );\r\n	\r\n	$print .= ''<div id="basket_in_head" class="topbasket">'';\r\n		$print_info .= ''<div class="link"><span class="icon famicon">&nbsp;</span><br /><a class="as2" href="[~38~]">Моя корзина</a></div>'';\r\n		if( $summa ) $print_info .= ''<div class="sum"><nobr>''. $modx->runSnippet(''BasketSumm'', array(''type''=>''text'')) .''</nobr></div>'';\r\n		else $print_info .= ''<span class="null">&ndash; не заполнена</span>'';\r\n		$print .= $print_info;\r\n	$print .= ''</div>'';\r\n	\r\n	if( $type == ''info'' )\r\n	{\r\n		return $print_info;\r\n	}else{\r\n		return $print;\r\n	}\r\n}\r\n', 0, '', ' '),
(38, 'Price', 'v5.5', 0, 10, 0, '\r\n//v5.5\r\n//============================================================================\r\nif( empty( $delimiter ) ) $delimiter= ''&thinsp;'';\r\nif( empty( $round ) ) $round= 2;\r\n\r\n$price= str_replace( ",", ".", $price );\r\n$price= preg_replace( "/[^0-9\\.]/", "", $price );\r\n\r\nif( $price <= 0 || $price == '''' ) return "&mdash;";\r\n\r\n$tmp= explode( ".", $price );\r\n$itogo_price= '''';\r\n$ii= 0;\r\nfor( $kk=strlen( $tmp[ 0 ] )-1; $kk >= 0; $kk-- )\r\n{\r\n	$ii++;\r\n	$itogo_price= substr( $tmp[ 0 ], $kk, 1 ) . $itogo_price;\r\n	if( $ii % 3 == 0 && $kk > 0 )\r\n	{\r\n		$itogo_price= $delimiter . $itogo_price;\r\n	}\r\n}\r\nif( $tmp[ 1 ] ) $itogo_price .= '',''. $tmp[ 1 ];\r\nif( strlen( $tmp[ 1 ] ) < $round ) $price= str_pad( $price, strlen( $price ) + ( $round - strlen( $tmp[ 1 ] ) ), "0" );\r\n\r\nreturn $itogo_price;\r\n', 0, '', ' '),
(39, 'ParentsPublishedList', 'v001', 0, 10, 0, '\r\n//v001\r\n//====================================================================\r\n$flag= false;\r\n$doc= $modx->getDocument( $id, ''id,parent'' );\r\nif( $doc[ ''parent'' ] == 0 ) $flag= true;\r\nwhile( $doc && $id != $koren && $doc[ ''parent'' ] != $koren && $doc[ ''parent'' ] != 0 )\r\n{\r\n	$doc= $modx->getDocument( $doc[ ''parent'' ], ''id,parent'' );\r\n}\r\nif( $id == $koren || $doc[ ''parent'' ] == $koren ) $flag= true;\r\nreturn $flag;\r\n', 0, '', ' '),
(40, 'Pagination', 'v005', 0, 10, 0, '\r\n//v005\r\n//============================================================\r\nif( $docs_items_count > 0 )\r\n{\r\n	$pages_count= ceil( $docs_items_count / $MaxItemsInPage );\r\n	\r\n	if( $pages_count > 1 )\r\n	{\r\n		$pages .= ''<div class="catalog_pages_tit">Страницы:</div>'';\r\n		$pages .= ''<div class="catalog_pages">'';\r\n		\r\n		$pp_prev= $active_page - 1; if( $pp_prev <= 1 ) $pp_prev= 0;\r\n		if( $pp_prev ) $pages .= ''<a class="cp_item" href="''. $modx->makeUrl( $myid ) . ( $filterprms ? ''x/''.$filterprms.''/'' : '''' ) .''page_''. $pp_prev .''/"> < </a>'';\r\n		\r\n		$visible_ot= $active_page - 5; if( $visible_ot < 1 ) $visible_ot= 1;\r\n		$visible_do= $active_page + 5; if( $visible_do > $pages_count ) $visible_do= $pages_count;\r\n		\r\n		for( $pp= 1; $pp <= $pages_count; $pp++ )\r\n		{\r\n			if( $pp >= 3 && $pp < $visible_ot )\r\n			{\r\n				if( ! $first )\r\n				{\r\n					$pages .= ''<div class="cp_troetochie">...</div>'';\r\n					$first= true;	\r\n				}\r\n				continue 1;\r\n			}\r\n			if( $pp <= $pages_count - 2 && $pp > $visible_do )\r\n			{\r\n				if( ! $second )\r\n				{\r\n					$pages .= ''<div class="cp_troetochie">...</div>'';\r\n					$second= true;	\r\n				}\r\n				continue 1;\r\n			}\r\n				\r\n			$pages .= ''<a class="cp_item ''.( $pp == $active_page ? ''active'' : '''' ).''" href="''. $modx->makeUrl( $myid ) . ( $filterprms ? ''x/''.$filterprms.''/'' : '''' ) . ( $pp > 1 ? ''page_''. $pp .''/'' : '''' ) .''">''. $pp .''</a>'';\r\n		}\r\n		\r\n		$pp_next= $active_page + 1; if( $pp_next >= $pages_count ) $pp_next= 0;\r\n		if( $pp_next ) $pages .= ''<a class="cp_item" href="''. $modx->makeUrl( $myid ) . ( $filterprms ? ''x/''.$filterprms.''/'' : '''' ) .''page_''. $pp_next .''/"> > </a>'';\r\n		\r\n		$pages .= ''<div class="clr">&nbsp;</div>'';\r\n		$pages .= ''</div>'';\r\n	}\r\n}\r\n\r\nreturn $pages;\r\n', 0, '', ' '),
(41, 'CAT_ITEM', '', 0, 10, 0, '\r\n$filter= IMG_FILTER_BRIGHTNESS.'';5|''.IMG_FILTER_CONTRAST.'';-10|''.IMG_FILTER_SMOOTH.'';-20'';\r\n	\r\nif( $type == ''category'' )\r\n{\r\n	if( $id == 28 ) $img_mini= $modx->runSnippet( ''ImgCrop7'', array( ''img''=>$row[''image''], ''w''=>( $indexcatalog ? 360 : 195 ), ''h''=>195, ''backgr''=>true, ''bgcolor''=>''1:1'', ''filter''=>$filter ) );\r\n		else $img_mini= $modx->runSnippet( ''ImgCrop7'', array( ''img''=>$row[''image''], ''w''=>( $indexcatalog ? 360 : 195 ), ''h''=>195, ''fill''=>true, ''filter''=>( $id == 1197 ? '''' : $filter ), ''quality''=>( $id == 97 ? ''100'' : '''' ) ) );\r\n	\r\n	$result .= ''<div class="catcat ''.( $last ? ''catcat_last'' : '''' ).''">'';\r\n	$result .= ''<a href="''. $modx->makeUrl( $row[ ''id'' ] ) .''">'';\r\n	$result .= ''<div class="catc_img"><img itemprop="image" src="''. $img_mini .''" alt="" /><div>&nbsp;</div></div>'';\r\n	\r\n	if( $row[ ''lentochka'' ] ) $result .= ''<div class="lenta lenta_''. $row[ ''lentochka'' ] .''">&nbsp;</div>'';\r\n	\r\n	$result .= ''<div class="catc_tit" itemprop="name"><div ''.( $indexcatalog ? ''style="font-size:18px;"'' : '''' ).''>''. $row[ ''pagetitle'' ] .''</div></div>'';\r\n	$result .= ''</a>'';\r\n	$result .= ''</div>'';\r\n	\r\n	if( $last ) $result .= ''<div class="clr">&nbsp;</div>'';\r\n	\r\n	\r\n	\r\n//=============================================================================\r\n	\r\n	\r\n	\r\n}elseif( $type == ''calculator'' ){\r\n	$img_mini= $modx->runSnippet( ''ImgCrop7'', array( ''img''=>$row[ ''image'' ], ''w''=>195, ''h''=>195, ''fill''=>true, ''filter''=>$filter ) );\r\n	\r\n	$result .= ''<div class="catcat ''.( $last ? ''catcat_last'' : '''' ).'' ''.( $calculator ? ''calc_param'' : '''' ).''" data-param="''.$calc_param.''" data-id="''.$row[ ''id'' ].''">'';\r\n	if( ! $calculator ) $result .= ''<a href="''. $modx->makeUrl( $row[ ''id'' ] ) .''">'';\r\n	$result .= ''<div class="catc_img"><img itemprop="image" src="''. $img_mini .''" alt="" /><div>&nbsp;</div></div>'';\r\n	\r\n	if( $row[ ''lentochka'' ] ) $result .= ''<div class="lenta lenta_''. $row[ ''lentochka'' ] .''">&nbsp;</div>'';\r\n	\r\n	$result .= ''<div class="catc_tit" itemprop="name"><div>''. $row[ ''pagetitle'' ] .''</div></div>'';\r\n	if( ! $calculator ) $result .= ''</a>'';\r\n	$result .= ''</div>'';\r\n	\r\n	if( $last ) $result .= ''<div class="clr">&nbsp;</div>'';\r\n	\r\n	\r\n	\r\n//=============================================================================\r\n	\r\n	\r\n	\r\n}elseif( $type == ''item_3'' ){\r\n	$result .= ''sdfsdfsdf'';\r\n	\r\n	\r\n//=============================================================================\r\n	\r\n	\r\n	\r\n}elseif( $type == ''item_1'' ){\r\n	$item_stat= $modx->runSnippet( ''BasketAction'', array( ''act''=>''stat'', ''id''=>$row[''id''] ) );\r\n	\r\n	$img_mini= $modx->runSnippet( ''ImgCrop7'', array( ''img''=>$row[''image''], ''w''=>120, ''h''=>120 ) );\r\n	$img_big= $modx->runSnippet( ''ImgCrop7'', array( ''img''=>$row[''image''], ''w''=>1111, ''h''=>1111, ''wm''=>true ) );\r\n	\r\n	$row[''introtext'']= str_replace( "\\n", ''<br />'', $row[''introtext''] );\r\n	\r\n	$result .= ''<div class="catitem1 ''.( $last ? ''catitem1_last'' : '''' ).''">'';\r\n	$result .= ''<div class="ci_img"><a class="highslide" onclick="return hs.expand(this)" href="''. $img_big .''"><img src="''. $img_mini .''" alt="''. $row[''pagetitle''] .''" ></a></div>'';\r\n	$result .= ''<div class="ci_info">\r\n		<div class="ci_tit">''. $row[''pagetitle''] .''</div>\r\n		<div class="ci_dscr">''. $row[''mini_description''] .''</div>\r\n	</div>'';\r\n	$result .= ''<div class="ci_shop">\r\n		<div class="ci_price"><nobr>''.( $row[''price_ot_flag'']==''priceot'' ? ''<span>от</span> '' : '''' ).''<span class="price">''. $modx->runSnippet( ''Price'', array( ''price''=>$row[''price''], ''round''=>0 ) ) .''</span> <span class="rubl">a</span> <span class="edizm">''.( $row[''edizmerenia''] ? ''/''.$row[''edizmerenia''] : '''' ).''</span></nobr></div>\r\n		\r\n		<div class="ci_tobasket add_to_basket" id="ci_tobasket_''. $row[''id''] .''" data-itemid="''. $row[''id''] .''">'';\r\n		if( $item_stat == ''netu'' ) $result .= ''<button>Купить</button><div style="display:none;"><a class="as2" href="[~38~]">Корзина</a></div><span style="display:none;"><center><img src="template/images/loading1.gif" /></center></span>''; else $result .= ''<div><a class="as2" href="''. $modx->makeUrl(38) .''">В корзине</a></div>'';\r\n		$result .= ''</div>\r\n	</div>'';\r\n	$result .= ''<div class="clr">&nbsp;</div></div>'';\r\n	\r\n	if( $last ) $result .= ''<div class="clr">&nbsp;</div>'';\r\n	\r\n	\r\n	\r\n//=============================================================================\r\n	\r\n	\r\n	\r\n}elseif( $type == ''item_2'' ){\r\n	$item_stat= $modx->runSnippet( ''BasketAction'', array( ''act''=>''stat'', ''id''=>$row[''id''] ) );\r\n	\r\n	$img_mini= $modx->runSnippet( ''ImgCrop7'', array( ''img''=>$row[''image''], ''w''=>120, ''h''=>120, ''backgr''=>true, ''bgcolor''=>''1:1'' ) );\r\n	$img_big= $modx->runSnippet( ''ImgCrop7'', array( ''img''=>$row[''image''], ''w''=>1111, ''h''=>1111, ''wm''=>true ) );\r\n	\r\n	$row[''introtext'']= str_replace( "\\n", ''<br />'', $row[''introtext''] );\r\n	\r\n	$result .= ''<div class="catitem2 ''.( $last ? ''catitem2_last'' : '''' ).''">'';\r\n	$result .= ''<div class="ci_img"><a class="highslide" onclick="return hs.expand(this)" href="''. $img_big .''"><img src="''. $img_mini .''" alt="''. $row[''pagetitle''] .''" ></a></div>'';\r\n	$result .= ''<div class="ci_info">\r\n		<div class="ci_tit">''. $row[''pagetitle''] .''</div>\r\n		<div class="ci_dscr">''. $row[''introtext''] .''</div>\r\n	</div>'';\r\n	$result .= ''<div class="ci_shop">\r\n		<div class="ci_price"><nobr>''.( $row[''price_ot_flag'']==''priceot'' ? ''<span>от</span> '' : '''' ).''<span class="price">''. $modx->runSnippet( ''Price'', array( ''price''=>$row[''price''], ''round''=>0 ) ) .''</span> <span class="rubl">a</span> <span class="edizm">''.( $row[''edizmerenia''] ? ''/''.$row[''edizmerenia''] : '''' ).''</span></nobr></div>\r\n		\r\n		<div class="ci_tobasket add_to_basket" id="ci_tobasket_''. $row[''id''] .''" data-itemid="''. $row[''id''] .''">'';\r\n		if( $item_stat == ''netu'' ) $result .= ''<button>Купить</button><div style="display:none;"><a class="as2" href="[~38~]">Корзина</a></div><span style="display:none;"><center><img src="template/images/loading1.gif" /></center></span>''; else $result .= ''<div><a class="as2" href="''. $modx->makeUrl(38) .''">В корзине</a></div>'';\r\n		$result .= ''</div>\r\n	</div>'';\r\n	$result .= ''<div class="clr">&nbsp;</div></div>'';\r\n	\r\n	if( $last ) $result .= ''<div class="clr">&nbsp;</div>'';\r\n	\r\n	if( false && $thispage )\r\n	{\r\n		$result .= ''<div class="clr">&nbsp;</div>'';\r\n		$result .= ''<div class="itempage_description">'';\r\n		$result .= $row[ ''content'' ];\r\n		$result .= ''</div>'';\r\n	}\r\n	\r\n	\r\n	\r\n//=============================================================================\r\n	\r\n	\r\n	\r\n}elseif( $type == ''item_5'' ){\r\n	$item_stat= $modx->runSnippet( ''BasketAction'', array( ''act''=>''stat'', ''id''=>$row[''id''] ) );\r\n	\r\n	$img_mini= $modx->runSnippet( ''ImgCrop7'', array( ''img''=>$row[''image''], ''w''=>135, ''h''=>135, ''fill''=>true ) );\r\n	$img_big= $modx->runSnippet( ''ImgCrop7'', array( ''img''=>$row[''image''], ''w''=>1111, ''h''=>1111, ''wm''=>true ) );\r\n	\r\n	$row[''introtext'']= str_replace( "\\n", ''<br />'', $row[''introtext''] );\r\n	\r\n	$result .= ''<div class="catitem5 ''.( $last ? ''catitem5_last'' : '''' ).''">'';\r\n	$result .= ''<div class="ci_img"><a class="highslide" onclick="return hs.expand(this)" href="''. $img_big .''"><img src="''. $img_mini .''" alt="''. $row[''pagetitle''] .''" ></a></div>'';\r\n	$result .= ''<div class="ci_info">\r\n		<div class="ci_tit">''. $row[''pagetitle''] .''</div>\r\n	</div>'';\r\n	$result .= ''<div class="ci_shop">\r\n		<div class="ci_price"><nobr>''.( $row[''price_ot_flag'']==''priceot'' ? ''<span>от</span> '' : '''' ).''<span class="price">''. $modx->runSnippet( ''Price'', array( ''price''=>$row[''price''], ''round''=>0 ) ) .''</span> <span class="rubl">a</span> <span class="edizm">''.( $row[''edizmerenia''] ? ''/''.$row[''edizmerenia''] : '''' ).''</span></nobr></div>\r\n		\r\n		<div class="ci_tobasket add_to_basket" id="ci_tobasket_''. $row[''id''] .''" data-itemid="''. $row[''id''] .''">'';\r\n		if( $item_stat == ''netu'' ) $result .= ''<button>Купить</button><div style="display:none;"><a class="as2" href="[~38~]">Корзина</a></div><span style="display:none;"><center><img src="template/images/loading1.gif" /></center></span>''; else $result .= ''<div><a class="as2" href="''. $modx->makeUrl(38) .''">В корзине</a></div>'';\r\n		$result .= ''</div>\r\n	</div>'';\r\n	$result .= ''<div class="clr">&nbsp;</div></div>'';\r\n	\r\n	if( $last ) $result .= ''<div class="clr">&nbsp;</div>'';\r\n	\r\n	\r\n	\r\n//=============================================================================\r\n	\r\n	\r\n	\r\n}\r\n\r\nreturn $result;\r\n', 0, '', ' '),
(42, 'Catalog_Birka', '', 0, 10, 0, '\r\n//v001\r\n//============================================================================\r\n\r\n$myid= $modx->documentIdentifier;\r\nif( empty( $id ) ) $id= $myid;\r\n\r\n$template= 2;\r\n$koren= 14;\r\n\r\nif( $marker <= 0 ) return false; else $marker= intval( $marker );\r\n\r\n$rr= mysql_query( "SELECT sc.id FROM ". $modx->getFullTableName( ''site_content'' ) ." AS sc\r\n			INNER JOIN ". $modx->getFullTableName( ''site_tmplvar_contentvalues'' ) ." AS tv ON tv.contentid=sc.id AND tv.tmplvarid=17\r\n				WHERE sc.template={$template} AND tv.`value`=''{$marker}''" );\r\nif( $rr && mysql_num_rows( $rr ) > 0 ) while( $row= mysql_fetch_assoc( $rr ) ) $ids .= ( ! empty( $ids ) ? "," : "" ) . $row[ ''id'' ];\r\n\r\n$docs= $modx->runSnippet( ''GetDoc5'', array( ''ids'' => $ids, ''type'' => ''this'', ''depth'' => 1, ''fields'' => ''pagetitle,isfolder'', ''tvfileds'' => ''image,lentochka'', ''isf'' => ''1'', ''sort'' => ''menuindex'' ) );\r\n\r\n//$docs2= $modx->runSnippet( ''GetDoc5'', array( ''ids'' => $ids, ''type'' => ''this'', ''fields'' => ''pagetitle,parent,isfolder,content,introtext'',\r\n//											''tvfileds'' => ''image,price,art,marker,oldprice,edizmerenia'', ''isf'' => ''0'', ''sort'' => ''menuindex'', ''limit'' => $page_s .",". $MaxItemsInPage ) );\r\n\r\nif( $docs && $docs2 ) $docs= array_merge( $docs, $docs2 ); elseif( $docs2 ) $docs= $docs2;\r\n\r\nif( $docs )\r\n{\r\n	\r\n	$ii= 0;\r\n	$iii= 0;\r\n	foreach( $docs AS $row )\r\n	{\r\n		if( $row[ ''isfolder'' ] == 1 )\r\n		{		\r\n			$ii++;\r\n			$items .= $modx->runSnippet( ''CAT_ITEM'', array( ''type'' => ''category'', ''val'' => $row, ''indexcatalog'' => $indexcatalog, ''last'' => ( $ii % 4 == 0 ? true : false ), ''parentlist'' => $parentlist[ $row[ ''id'' ] ], ''mylvl'' => $mylvl[ $row[ ''id'' ] ] ) );\r\n			\r\n		}else{\r\n			$iii++;\r\n			$items .= $modx->runSnippet( ''CAT_ITEM'', array( ''type'' => ''item'', ''val'' => $row, ''last'' => ( $iii % 3 == 0 ? true : false ), ''parentlist'' => $parentlist[ $row[ ''parent'' ] ] ) );\r\n		}\r\n	}\r\n}\r\n\r\n$result .= ''<div id="catalog" class="catalog ''.( $indexcatalog ? ''indexcatalog'' : ''catalogpage'' ).''">'';\r\nif( $items != '''' )\r\n{\r\n	$result .= $items;\r\n	$result .= ''<div class="clr">&nbsp;</div>'';\r\n}\r\n$result .= ''</div>'';\r\n\r\nreturn $result;\r\n', 0, '', ' ');
INSERT INTO `ms_site_snippets` (`id`, `name`, `description`, `editor_type`, `category`, `cache_type`, `snippet`, `locked`, `properties`, `moduleguid`) VALUES
(43, 'CATALOG', '', 0, 10, 0, '\r\n/*\r\n$print .= ''<img src="''. $modx->runSnippet( ''ImgCrop7'', array( ''img''=>''assets/images/catalog/zhaluzi/gg_h01.jpg'', ''toimg''=>''tmp1.jpg'', ''r''=>true, ''w''=>150, ''h''=>150 ) ) .''" />'';\r\n$print .= ''<img src="''. $modx->runSnippet( ''ImgCrop7'', array( ''img''=>''assets/images/catalog/zhaluzi/gg_h01.jpg'', ''toimg''=>''tmp2.jpg'', ''r''=>true, ''w''=>150, ''h''=>150, ''fill''=>true ) ) .''" />'';\r\n$print .= ''<img src="''. $modx->runSnippet( ''ImgCrop7'', array( ''img''=>''assets/images/catalog/zhaluzi/gg_h01.jpg'', ''toimg''=>''tmp3.jpg'', ''r''=>true, ''w''=>150, ''h''=>150, ''backgr''=>true ) ) .''" />'';\r\n$print .= ''<img src="''. $modx->runSnippet( ''ImgCrop7'', array( ''img''=>''assets/images/catalog/zhaluzi/gg_h01.jpg'', ''toimg''=>''tmp4.jpg'', ''r''=>true, ''w''=>150, ''h''=>150, ''backgr''=>true, ''bgcolor''=>''200,200,200,127'' ) ) .''" />'';\r\n$print .= ''<img src="''. $modx->runSnippet( ''ImgCrop7'', array( ''img''=>''assets/images/catalog/zhaluzi/gg_h01.jpg'', ''toimg''=>''tmp5.jpg'', ''r''=>true, ''w''=>150, ''h''=>150, ''backgr''=>true, ''bgcolor''=>''470:600'' ) ) .''" />'';\r\n$print .= ''<img src="''. $modx->runSnippet( ''ImgCrop7'', array( ''img''=>''assets/images/catalog/zhaluzi/gg_h01.jpg'', ''toimg''=>''tmp6.jpg'', ''r''=>true, ''w''=>150, ''h''=>150, ''backgr''=>true, ''bgcolor''=>''fill:''.IMG_FILTER_BRIGHTNESS.'';-100'' ) ) .''" />'';\r\n\r\n$print .= ''<img src="''. $modx->runSnippet( ''ImgCrop7'', array( ''img''=>''assets/images/catalog/zhaluzi/gg_h01.jpg'', ''toimg''=>''tmp7.jpg'', ''r''=>true, ''w''=>150, ''h''=>150, ''fill''=>true, ''wm''=>true ) ) .''" />'';\r\n	\r\n$print .= ''<img src="''. $modx->runSnippet( ''ImgCrop7'', array( ''img''=>''assets/images/catalog/zhaluzi/gg_h01.jpg'', ''toimg''=>''tmp8.jpg'', ''r''=>true, ''w''=>150, ''h''=>150, ''filter''=>IMG_FILTER_BRIGHTNESS.'';100'' ) ) .''" />'';\r\n\r\n$print .= ''<img src="''. $modx->runSnippet( ''ImgCrop7'', array( ''img''=>''assets/images/catalog/zhaluzi/gg_h01.jpg'', ''toimg''=>''tmp9.jpg'', ''r''=>true, ''w''=>150, ''h''=>150, ''fill''=>true, ''ellipse''=>''max'' ) ) .''" />'';\r\n\r\n$print .= ''<img src="''. $modx->runSnippet( ''ImgCrop7'', array( ''img''=>''assets/images/catalog/zhaluzi/gg_h01.jpg'', ''toimg''=>''tmp10.jpg'', ''r''=>true, ''w''=>150, ''h''=>150, ''fill''=>true, ''ellipse''=>''max'', ''degstep''=>45 ) ) .''" />'';\r\n\r\n$print .= ''<img src="''. $modx->runSnippet( ''ImgCrop7'', array( ''img''=>''assets/images/catalog/zhaluzi/gg_h01.jpg'', ''toimg''=>''tmp11.jpg'', ''r''=>true, ''w''=>90, ''h''=>90, ''fill''=>true, ''ellipse''=>''max'', ''degstep''=>15, ''dopimg''=>''template/images/kruzhok1.png'', ''dopimg_xy''=>''0:0'' ) ) .''" />'';\r\n\r\n$print .= ''<img src="''. $modx->runSnippet( ''ImgCrop7'', array( ''img''=>''assets/images/catalog/zhaluzi/gg_h01.jpg'', ''toimg''=>''tmp12.jpg'', ''r''=>true, ''w''=>150, ''h''=>150, ''quality''=>10 ) ) .''" />'';\r\n	\r\n$print .= ''<img src="''. $modx->runSnippet( ''ImgCrop7'', array( ''img''=>''assets/images/catalog/zhaluzi/gg_h01.jpg'', ''toimg''=>''tmp13.jpg'', ''r''=>true, ''w''=>150, ''h''=>150 ) ) .''" />'';\r\n$print .= ''<img src="''. $modx->runSnippet( ''ImgCrop7'', array( ''img''=>''assets/images/catalog/zhaluzi/gg_h01.jpg'', ''toimg''=>''tmp14.jpg'', ''r''=>true, ''w''=>150, ''h''=>150, ''filter'' => IMG_FILTER_BRIGHTNESS.'';5|''.IMG_FILTER_CONTRAST.'';-10|''.IMG_FILTER_SMOOTH.'';-20'' ) ) .''" />'';\r\n*/\r\n	\r\n	\r\n//============================================================================\r\n$catalog_koren= 14;\r\n$catalog_template= 2;\r\n\r\n$templates= array(\r\n	// docId => array( кол-во в строке, название шаблона )\r\n	''24'' =>					array( 1, ''item_1'' ),\r\n	''25'' =>					array( 2, ''item_2'' ),\r\n	''26'' =>					array( 2, ''item_2'' ),\r\n	''>=28'' =>				array( 2, ''item_2'' ),\r\n	''92'' =>					array( 2, ''item_2'' ),\r\n	''93'' =>					array( 2, ''item_2'' ),\r\n	''94'' =>					array( 5, ''item_5'' ),\r\n	''>97'' =>				array( 5, ''item_5'' ),\r\n);\r\n//============================================================================\r\n\r\n	\r\n$myid= $modx->documentIdentifier;\r\nif( empty( $id ) ) $id= $myid;\r\n//$doc= $modx->getDocument( $id, ''id,pagetitle,isfolder,content,introtext'' );\r\n$doc= $modx->runSnippet( ''GetDoc6'', array( ''ids''=>$id, ''type''=>''this'', ''fields''=>''pagetitle,isfolder,content,introtext,parent'', ''tvfileds''=>''image'', ''isf''=>''all'' ) );\r\n$doc= $doc[ $id ];\r\n\r\n\r\n$lvl= $modx->runSnippet( ''GetLvl'', array( ''koren''=>$catalog_koren, ''id''=>$id ) );\r\n$maincategory= $modx->runSnippet( ''GetIdOnLvl'', array( ''koren''=>$catalog_koren, ''id''=>$id ) );\r\nif( $maincategory[2][''id''] == 22 )\r\n{\r\n	if( $maincategory[3][''id''] == 48 ) $calculator= 48;\r\n	if( $maincategory[3][''id''] == 49 ) $calculator= 49;\r\n	if( $maincategory[3][''id''] == 50 ) $calculator= 50;\r\n	//if( $maincategory[3][''id''] == 51 ) $calculator= 51;\r\n}\r\nif( $calculator )\r\n{\r\n	$print= $modx->runSnippet( ''Calculator'', array( ''calculator''=>$calculator ) );\r\n	$print .= $doc[ ''content'' ];\r\n	return $print;\r\n}\r\n\r\n\r\nif( $templates[''>=''.$id][1] ) $template= $templates[''>=''.$id];\r\nif( $templates[''>=''.$doc[''parent'']][1] ) $template= $templates[''>=''.$doc[''parent'']];\r\nif( $templates[''>''.$doc[''parent'']][1] ) $template= $templates[''>''.$doc[''parent'']];\r\nif( $templates[$id][1] ) $template= $templates[$id];\r\nif( ! $template[1] ) $template= array( 2, ''item_2'' );\r\n\r\n\r\n$ParentsPublishedList_flag= $modx->runSnippet( ''ParentsPublishedList'', array( ''koren''=>$catalog_koren, ''id''=>$id ) );\r\nif( $lvl && ! $ParentsPublishedList_flag ) $modx->sendErrorPage();\r\n\r\n\r\nif( $doc[ ''isfolder'' ] == 1 )\r\n{\r\n	$docs= $modx->runSnippet( ''GetDoc6'', array( ''ids''=>$id, ''type''=>''childs'', ''depth''=>''1'', ''fields''=>''pagetitle,isfolder,introtext,menuindex,parent'',\r\n												''tvfileds''=>''image,price,price_ot_flag,edizmerenia,lentochka,mini_description'', ''isf''=>''all'', ''sort''=>''menuindex'' ) );\r\n	if( $docs )\r\n	{\r\n		$ii= 0;\r\n		$iii= 0;\r\n		foreach( $docs AS $row )\r\n		{\r\n			if( $row[ ''isfolder'' ] == 1 || $itemprinttype == ''category'' )\r\n			{\r\n				$ii++;\r\n				$categories .= $modx->runSnippet( ''CAT_ITEM'', array( ''id''=>$id, ''type''=>''category'', ''row''=>$row, ''last''=>( $ii % ( $indexcatalog ? 3 : 4 ) == 0 ? true : false ), ''indexcatalog''=>$indexcatalog ) );\r\n				\r\n			}else{\r\n				$iii++;\r\n				$items .= $modx->runSnippet( ''CAT_ITEM'', array( ''type''=>$template[1], ''row''=>$row, ''last''=>( $iii % $template[0] == 0 ? true : false ) ) );\r\n			}\r\n		}\r\n	}\r\n	\r\n	if( ! empty( $doc[ ''content'' ] ) ) $content .= $doc[ ''content'' ];\r\n	\r\n}elseif( true ){\r\n	$docinfo= $modx->runSnippet( ''GetDoc6'', array( ''ids''=>$id, ''type''=>''this'', ''fields''=>''pagetitle,isfolder,introtext,menuindex,parent,content'',\r\n												  ''tvfileds''=>''image,price,price_ot_flag,edizmerenia,lentochka,mini_description'', ''isf''=>''0'' ) );\r\n	$item_page .= $modx->runSnippet( ''CAT_ITEM'', array( ''type''=>$template[1], ''thispage''=>true, ''row''=>$docinfo[ $id ] ) );\r\n}\r\n\r\n\r\n$print .= ''<div id="catalog" class="catalog ''.( $indexcatalog ? ''catalogindex'' : ''catalogpage'' ).''" itemscope itemtype="http://schema.org/Product">'';\r\nif( ! empty( $categories ) )\r\n{\r\n	$print .= $categories;\r\n	$print .= ''<div class="clr">&nbsp;</div>'';\r\n	if( ! empty( $items ) ) $print .= ''<br /><br />'';\r\n}\r\nif( ! empty( $items ) )\r\n{\r\n	$print .= $items;\r\n	$print .= ''<div class="clr">&nbsp;</div>'';\r\n}\r\nif( ! empty( $item_page ) )\r\n{\r\n	$print .= $item_page;\r\n}\r\n$print .= ''</div>'';\r\n\r\n\r\nif( $type != ''content'' )\r\n{\r\n	$print .= ''<div class="clr">&nbsp;</div>'';\r\n	$print .= ''<div class="category_content">''. $content .''</div>'';\r\n	$print .= ''<div class="clr">&nbsp;</div>'';\r\n}\r\n\r\n\r\nreturn $print;\r\n', 0, '', ' ');

-- --------------------------------------------------------

--
-- Структура таблицы `ms_site_templates`
--

CREATE TABLE IF NOT EXISTS `ms_site_templates` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `templatename` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT 'Template',
  `editor_type` int(11) NOT NULL DEFAULT '0' COMMENT '0-plain text,1-rich text,2-code editor',
  `category` int(11) NOT NULL DEFAULT '0' COMMENT 'category id',
  `icon` varchar(255) NOT NULL DEFAULT '' COMMENT 'url to icon file',
  `template_type` int(11) NOT NULL DEFAULT '0' COMMENT '0-page,1-content',
  `content` mediumtext,
  `locked` tinyint(4) NOT NULL DEFAULT '0',
  `selectable` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 COMMENT='Contains the site templates.' AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `ms_site_templates`
--

INSERT INTO `ms_site_templates` (`id`, `templatename`, `description`, `editor_type`, `category`, `icon`, `template_type`, `content`, `locked`, `selectable`) VALUES
(3, 'Обычная страница', '', 0, 8, '', 0, '{{HEAD}}\r\n[*content*]\r\n\r\n{{FOOTER}}', 0, 1),
(4, 'Каталог', '', 0, 10, '', 0, '{{HEAD}}\r\n[*content*]\r\n\r\n{{FOOTER}}', 0, 1),
(5, 'Главная страница', '', 0, 8, '', 0, '{{HEAD}}\r\n[*content*]\r\n\r\n{{FOOTER}}', 0, 1),
(6, 'Обычная страница (без левого меню)', '', 0, 8, '', 0, '{{HEAD}}\r\n[*content*]\r\n\r\n{{FOOTER}}', 0, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `ms_site_tmplvars`
--

CREATE TABLE IF NOT EXISTS `ms_site_tmplvars` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL DEFAULT '',
  `name` varchar(50) NOT NULL DEFAULT '',
  `caption` varchar(80) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `editor_type` int(11) NOT NULL DEFAULT '0' COMMENT '0-plain text,1-rich text,2-code editor',
  `category` int(11) NOT NULL DEFAULT '0' COMMENT 'category id',
  `locked` tinyint(4) NOT NULL DEFAULT '0',
  `elements` text,
  `rank` int(11) NOT NULL DEFAULT '0',
  `display` varchar(20) NOT NULL DEFAULT '' COMMENT 'Display Control',
  `display_params` text COMMENT 'Display Control Properties',
  `default_text` text,
  PRIMARY KEY (`id`),
  KEY `indx_rank` (`rank`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 COMMENT='Site Template Variables' AUTO_INCREMENT=12 ;

--
-- Дамп данных таблицы `ms_site_tmplvars`
--

INSERT INTO `ms_site_tmplvars` (`id`, `type`, `name`, `caption`, `description`, `editor_type`, `category`, `locked`, `elements`, `rank`, `display`, `display_params`, `default_text`) VALUES
(1, 'text', 'seo_title', '[admin] SEO Title', '', 0, 9, 1, '', 0, '', '', '[*pagetitle*] - «Мастерстрой», г.Ростов-на-Дону'),
(2, 'text', 'seo_description', '[admin] SEO Description', '', 0, 9, 1, '', 0, '', '', '[*pagetitle*] - «Мастерстрой», г.Ростов-на-Дону'),
(3, 'text', 'seo_keywords', '[admin] SEO Keywords', '', 0, 9, 1, '', 0, '', '', '[*pagetitle*], Мастерстрой, Ростов-на-Дону'),
(4, 'text', 'seo_h1', '[admin] SEO - H1', '', 0, 9, 1, '', 0, '', '', '[*pagetitle*]'),
(5, 'image', 'image', 'Изображение', '', 0, 8, 0, '', 0, '', '', ''),
(6, 'date', 'date', 'Дата', '', 0, 8, 0, '', 0, 'unixtime', '', ''),
(7, 'textareamini', 'before_content', '[admin] До контента', '', 0, 8, 1, '', 0, '', '', ''),
(8, 'textareamini', 'after_content', '[admin] До контента', '', 0, 8, 1, '', 0, '', '', ''),
(9, 'text', 'price', 'Цена, руб.', '', 0, 10, 0, '', 0, '', '', ''),
(10, 'dropdown', 'birka', 'Бирка', '', 0, 10, 0, '- нет метки -==0||Популярный товар==1||Спец.предложение==2||Новинка==3||Акция==4||Распродажа==5', 0, '', '', ''),
(11, 'dropdown', 'edizmerenia', 'Единица измерения', '', 0, 10, 0, '- нет -==0||шт.||м.п.||рул.||кв.м||упак.', 0, '', '', '');

-- --------------------------------------------------------

--
-- Структура таблицы `ms_site_tmplvar_access`
--

CREATE TABLE IF NOT EXISTS `ms_site_tmplvar_access` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `tmplvarid` int(10) NOT NULL DEFAULT '0',
  `documentgroup` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='Contains data used for template variable access permissions.' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `ms_site_tmplvar_contentvalues`
--

CREATE TABLE IF NOT EXISTS `ms_site_tmplvar_contentvalues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tmplvarid` int(10) NOT NULL DEFAULT '0' COMMENT 'Template Variable id',
  `contentid` int(10) NOT NULL DEFAULT '0' COMMENT 'Site Content Id',
  `value` text,
  PRIMARY KEY (`id`),
  KEY `idx_tmplvarid` (`tmplvarid`),
  KEY `idx_id` (`contentid`),
  FULLTEXT KEY `value_ft_idx` (`value`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 COMMENT='Site Template Variables Content Values Link Table' AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `ms_site_tmplvar_contentvalues`
--

INSERT INTO `ms_site_tmplvar_contentvalues` (`id`, `tmplvarid`, `contentid`, `value`) VALUES
(1, 7, 12, '[!BasketPage? &OrderForm=`1`!]');

-- --------------------------------------------------------

--
-- Структура таблицы `ms_site_tmplvar_templates`
--

CREATE TABLE IF NOT EXISTS `ms_site_tmplvar_templates` (
  `tmplvarid` int(10) NOT NULL DEFAULT '0' COMMENT 'Template Variable id',
  `templateid` int(11) NOT NULL DEFAULT '0',
  `rank` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tmplvarid`,`templateid`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='Site Template Variables Templates Link Table';

--
-- Дамп данных таблицы `ms_site_tmplvar_templates`
--

INSERT INTO `ms_site_tmplvar_templates` (`tmplvarid`, `templateid`, `rank`) VALUES
(1, 3, 5),
(2, 3, 6),
(3, 3, 7),
(4, 3, 4),
(5, 3, 1),
(6, 3, 0),
(7, 3, 2),
(8, 3, 3),
(10, 4, 0),
(1, 4, 8),
(2, 4, 9),
(3, 4, 10),
(4, 4, 7),
(5, 4, 3),
(6, 4, 4),
(7, 4, 5),
(8, 4, 6),
(9, 4, 1),
(11, 4, 2),
(1, 5, 5),
(2, 5, 6),
(3, 5, 7),
(4, 5, 4),
(5, 5, 1),
(6, 5, 0),
(7, 5, 2),
(8, 5, 3),
(1, 6, 5),
(2, 6, 6),
(3, 6, 7),
(4, 6, 4),
(5, 6, 1),
(6, 6, 0),
(7, 6, 2),
(8, 6, 3);

-- --------------------------------------------------------

--
-- Структура таблицы `ms_system_eventnames`
--

CREATE TABLE IF NOT EXISTS `ms_system_eventnames` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `service` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'System Service number',
  `groupname` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 COMMENT='System Event Names.' AUTO_INCREMENT=1036 ;

--
-- Дамп данных таблицы `ms_system_eventnames`
--

INSERT INTO `ms_system_eventnames` (`id`, `name`, `service`, `groupname`) VALUES
(1, 'OnDocPublished', 5, ''),
(2, 'OnDocUnPublished', 5, ''),
(3, 'OnWebPagePrerender', 5, ''),
(4, 'OnWebLogin', 3, ''),
(5, 'OnBeforeWebLogout', 3, ''),
(6, 'OnWebLogout', 3, ''),
(7, 'OnWebSaveUser', 3, ''),
(8, 'OnWebDeleteUser', 3, ''),
(9, 'OnWebChangePassword', 3, ''),
(10, 'OnWebCreateGroup', 3, ''),
(11, 'OnManagerLogin', 2, ''),
(12, 'OnBeforeManagerLogout', 2, ''),
(13, 'OnManagerLogout', 2, ''),
(14, 'OnManagerSaveUser', 2, ''),
(15, 'OnManagerDeleteUser', 2, ''),
(16, 'OnManagerChangePassword', 2, ''),
(17, 'OnManagerCreateGroup', 2, ''),
(18, 'OnBeforeCacheUpdate', 4, ''),
(19, 'OnCacheUpdate', 4, ''),
(107, 'OnMakePageCacheKey', 4, ''),
(20, 'OnLoadWebPageCache', 4, ''),
(21, 'OnBeforeSaveWebPageCache', 4, ''),
(22, 'OnChunkFormPrerender', 1, 'Chunks'),
(23, 'OnChunkFormRender', 1, 'Chunks'),
(24, 'OnBeforeChunkFormSave', 1, 'Chunks'),
(25, 'OnChunkFormSave', 1, 'Chunks'),
(26, 'OnBeforeChunkFormDelete', 1, 'Chunks'),
(27, 'OnChunkFormDelete', 1, 'Chunks'),
(28, 'OnDocFormPrerender', 1, 'Documents'),
(29, 'OnDocFormRender', 1, 'Documents'),
(30, 'OnBeforeDocFormSave', 1, 'Documents'),
(31, 'OnDocFormSave', 1, 'Documents'),
(32, 'OnBeforeDocFormDelete', 1, 'Documents'),
(33, 'OnDocFormDelete', 1, 'Documents'),
(1033, 'OnDocFormUnDelete', 1, 'Documents'),
(1034, 'onBeforeMoveDocument', 1, 'Documents'),
(1035, 'onAfterMoveDocument', 1, 'Documents'),
(34, 'OnPluginFormPrerender', 1, 'Plugins'),
(35, 'OnPluginFormRender', 1, 'Plugins'),
(36, 'OnBeforePluginFormSave', 1, 'Plugins'),
(37, 'OnPluginFormSave', 1, 'Plugins'),
(38, 'OnBeforePluginFormDelete', 1, 'Plugins'),
(39, 'OnPluginFormDelete', 1, 'Plugins'),
(40, 'OnSnipFormPrerender', 1, 'Snippets'),
(41, 'OnSnipFormRender', 1, 'Snippets'),
(42, 'OnBeforeSnipFormSave', 1, 'Snippets'),
(43, 'OnSnipFormSave', 1, 'Snippets'),
(44, 'OnBeforeSnipFormDelete', 1, 'Snippets'),
(45, 'OnSnipFormDelete', 1, 'Snippets'),
(46, 'OnTempFormPrerender', 1, 'Templates'),
(47, 'OnTempFormRender', 1, 'Templates'),
(48, 'OnBeforeTempFormSave', 1, 'Templates'),
(49, 'OnTempFormSave', 1, 'Templates'),
(50, 'OnBeforeTempFormDelete', 1, 'Templates'),
(51, 'OnTempFormDelete', 1, 'Templates'),
(52, 'OnTVFormPrerender', 1, 'Template Variables'),
(53, 'OnTVFormRender', 1, 'Template Variables'),
(54, 'OnBeforeTVFormSave', 1, 'Template Variables'),
(55, 'OnTVFormSave', 1, 'Template Variables'),
(56, 'OnBeforeTVFormDelete', 1, 'Template Variables'),
(57, 'OnTVFormDelete', 1, 'Template Variables'),
(58, 'OnUserFormPrerender', 1, 'Users'),
(59, 'OnUserFormRender', 1, 'Users'),
(60, 'OnBeforeUserFormSave', 1, 'Users'),
(61, 'OnUserFormSave', 1, 'Users'),
(62, 'OnBeforeUserFormDelete', 1, 'Users'),
(63, 'OnUserFormDelete', 1, 'Users'),
(64, 'OnWUsrFormPrerender', 1, 'Web Users'),
(65, 'OnWUsrFormRender', 1, 'Web Users'),
(66, 'OnBeforeWUsrFormSave', 1, 'Web Users'),
(67, 'OnWUsrFormSave', 1, 'Web Users'),
(68, 'OnBeforeWUsrFormDelete', 1, 'Web Users'),
(69, 'OnWUsrFormDelete', 1, 'Web Users'),
(70, 'OnSiteRefresh', 1, ''),
(71, 'OnFileManagerUpload', 1, ''),
(72, 'OnModFormPrerender', 1, 'Modules'),
(73, 'OnModFormRender', 1, 'Modules'),
(74, 'OnBeforeModFormDelete', 1, 'Modules'),
(75, 'OnModFormDelete', 1, 'Modules'),
(76, 'OnBeforeModFormSave', 1, 'Modules'),
(77, 'OnModFormSave', 1, 'Modules'),
(78, 'OnBeforeWebLogin', 3, ''),
(79, 'OnWebAuthentication', 3, ''),
(80, 'OnBeforeManagerLogin', 2, ''),
(81, 'OnManagerAuthentication', 2, ''),
(82, 'OnSiteSettingsRender', 1, 'System Settings'),
(83, 'OnFriendlyURLSettingsRender', 1, 'System Settings'),
(84, 'OnUserSettingsRender', 1, 'System Settings'),
(85, 'OnInterfaceSettingsRender', 1, 'System Settings'),
(86, 'OnMiscSettingsRender', 1, 'System Settings'),
(87, 'OnRichTextEditorRegister', 1, 'RichText Editor'),
(88, 'OnRichTextEditorInit', 1, 'RichText Editor'),
(89, 'OnManagerPageInit', 2, ''),
(90, 'OnWebPageInit', 5, ''),
(101, 'OnLoadDocumentObject', 5, ''),
(104, 'OnBeforeLoadDocumentObject', 5, ''),
(105, 'OnAfterLoadDocumentObject', 5, ''),
(91, 'OnLoadWebDocument', 5, ''),
(92, 'OnParseDocument', 5, ''),
(106, 'OnParseProperties', 5, ''),
(93, 'OnManagerLoginFormRender', 2, ''),
(94, 'OnWebPageComplete', 5, ''),
(95, 'OnLogPageHit', 5, ''),
(96, 'OnBeforeManagerPageInit', 2, ''),
(97, 'OnBeforeEmptyTrash', 1, 'Documents'),
(98, 'OnEmptyTrash', 1, 'Documents'),
(99, 'OnManagerLoginFormPrerender', 2, ''),
(100, 'OnStripAlias', 1, 'Documents'),
(102, 'OnMakeDocUrl', 5, ''),
(103, 'OnBeforeLoadExtension', 5, ''),
(200, 'OnCreateDocGroup', 1, 'Documents'),
(201, 'OnManagerWelcomePrerender', 2, ''),
(202, 'OnManagerWelcomeHome', 2, ''),
(203, 'OnManagerWelcomeRender', 2, ''),
(204, 'OnBeforeDocDuplicate', 1, 'Documents'),
(205, 'OnDocDuplicate', 1, 'Documents'),
(206, 'OnManagerMainFrameHeaderHTMLBlock', 2, ''),
(207, 'OnManagerPreFrameLoader', 2, ''),
(208, 'OnManagerFrameLoader', 2, ''),
(209, 'OnManagerTreeInit', 2, ''),
(210, 'OnManagerTreePrerender', 2, ''),
(211, 'OnManagerTreeRender', 2, ''),
(212, 'OnManagerNodePrerender', 2, ''),
(213, 'OnManagerNodeRender', 2, ''),
(214, 'OnManagerMenuPrerender', 2, ''),
(224, 'OnDocFormTemplateRender', 1, 'Documents'),
(999, 'OnPageUnauthorized', 1, ''),
(1000, 'OnPageNotFound', 1, ''),
(1001, 'OnFileBrowserUpload', 1, 'File Browser Events');

-- --------------------------------------------------------

--
-- Структура таблицы `ms_system_settings`
--

CREATE TABLE IF NOT EXISTS `ms_system_settings` (
  `setting_name` varchar(50) NOT NULL DEFAULT '',
  `setting_value` text,
  PRIMARY KEY (`setting_name`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='Contains Content Manager settings.';

--
-- Дамп данных таблицы `ms_system_settings`
--

INSERT INTO `ms_system_settings` (`setting_name`, `setting_value`) VALUES
('manager_theme', 'MODxRE'),
('settings_version', '1.1'),
('show_meta', '0'),
('server_offset_time', '0'),
('server_protocol', 'http'),
('manager_language', 'russian-UTF8'),
('modx_charset', 'UTF-8'),
('site_name', 'Мастерстрой'),
('site_start', '1'),
('error_page', '9'),
('unauthorized_page', '10'),
('site_status', '1'),
('site_unavailable_message', 'The site is currently unavailable'),
('track_visitors', '0'),
('top_howmany', '10'),
('auto_template_logic', 'parent'),
('default_template', '3'),
('old_template', '3'),
('publish_default', '1'),
('cache_default', '1'),
('search_default', '1'),
('friendly_urls', '1'),
('friendly_url_prefix', ''),
('friendly_url_suffix', '.html'),
('friendly_alias_urls', '1'),
('use_alias_path', '1'),
('use_udperms', '1'),
('udperms_allowroot', '1'),
('failed_login_attempts', '20'),
('blocked_minutes', '20'),
('use_captcha', '0'),
('captcha_words', 'MODX,Access,Better,BitCode,Cache,Desc,Design,Excell,Enjoy,URLs,TechView,Gerald,Griff,Humphrey,Holiday,Intel,Integration,Joystick,Join(),Tattoo,Genetic,Light,Likeness,Marit,Maaike,Niche,Netherlands,Ordinance,Oscillo,Parser,Phusion,Query,Question,Regalia,Righteous,Snippet,Sentinel,Template,Thespian,Unity,Enterprise,Verily,Veri,Website,WideWeb,Yap,Yellow,Zebra,Zygote'),
('emailsender', 'mrvlhf@mail.ru'),
('email_method', 'mail'),
('smtp_auth', '0'),
('smtp_host', ''),
('smtp_port', '25'),
('smtp_username', ''),
('emailsubject', 'Your login details'),
('number_of_logs', '100'),
('number_of_messages', '30'),
('number_of_results', '20'),
('use_editor', '1'),
('use_browser', '1'),
('rb_base_dir', '/home/u383720/masterstroy-rnd.ru/www/_new/assets/'),
('rb_base_url', 'assets/'),
('which_editor', 'TinyMCE'),
('fe_editor_lang', 'russian-UTF8'),
('fck_editor_toolbar', 'standard'),
('fck_editor_autolang', '0'),
('editor_css_path', ''),
('editor_css_selectors', ''),
('strip_image_paths', '1'),
('upload_images', 'bmp,ico,gif,jpeg,jpg,png,psd,tif,tiff'),
('upload_media', 'au,avi,mp3,mp4,mpeg,mpg,wav,wmv'),
('upload_flash', 'fla,flv,swf'),
('upload_files', 'bmp,ico,gif,jpeg,jpg,png,psd,tif,tiff,fla,flv,swf,aac,au,avi,css,cache,doc,docx,gz,gzip,htaccess,htm,html,js,mp3,mp4,mpeg,mpg,ods,odp,odt,pdf,ppt,pptx,rar,tar,tgz,txt,wav,wmv,xls,xlsx,xml,z,zip,JPG,JPEG,PNG,GIF'),
('upload_maxsize', '50485760'),
('new_file_permissions', '0755'),
('new_folder_permissions', '0755'),
('filemanager_path', '/home/u383720/masterstroy-rnd.ru/www/_new/'),
('theme_refresher', ''),
('manager_layout', '4'),
('custom_contenttype', 'application/rss+xml,application/pdf,application/vnd.ms-word,application/vnd.ms-excel,text/html,text/css,text/xml,text/javascript,text/plain,application/json'),
('auto_menuindex', '1'),
('session.cookie.lifetime', '604800'),
('mail_check_timeperiod', '60'),
('manager_direction', 'ltr'),
('tinymce_editor_theme', 'editor'),
('tinymce_custom_plugins', 'style,advimage,advlink,searchreplace,print,contextmenu,paste,fullscreen,nonbreaking,xhtmlxtras,visualchars,media'),
('tinymce_custom_buttons1', 'undo,redo,selectall,separator,pastetext,pasteword,separator,search,replace,separator,nonbreaking,hr,charmap,separator,image,link,unlink,anchor,media,separator,cleanup,removeformat,separator,fullscreen,print,code,help'),
('tinymce_custom_buttons2', 'bold,italic,underline,strikethrough,sub,sup,separator,bullist,numlist,outdent,indent,separator,justifyleft,justifycenter,justifyright,justifyfull,separator,styleselect,formatselect,separator,styleprops'),
('tree_show_protected', '0'),
('rss_url_news', 'http://feeds.feedburner.com/modx-announce'),
('rss_url_security', 'http://feeds.feedburner.com/modxsecurity'),
('validate_referer', '1'),
('datepicker_offset', '-10'),
('xhtml_urls', '1'),
('allow_duplicate_alias', '0'),
('automatic_alias', '1'),
('datetime_format', 'dd-mm-YYYY'),
('warning_visibility', '0'),
('remember_last_tab', '1'),
('enable_bindings', '1'),
('seostrict', '1'),
('cache_type', '1'),
('maxImageWidth', '7777'),
('maxImageHeight', '7777'),
('thumbWidth', '150'),
('thumbHeight', '150'),
('thumbsDir', '.thumbs'),
('jpegQuality', '90'),
('denyZipDownload', '0'),
('denyExtensionRename', '0'),
('showHiddenFiles', '0'),
('docid_incrmnt_method', '0'),
('make_folders', '1'),
('tree_page_click', '27'),
('clean_uploaded_filename', '1'),
('site_id', '5787832c68e0c'),
('site_unavailable_page', '10'),
('reload_site_unavailable', ''),
('siteunavailable_message_default', 'В настоящее время сайт недоступен.'),
('aliaslistingfolder', '0'),
('check_files_onlogin', 'index.php\r\n.htaccess\r\nmanager/index.php\r\nmanager/includes/config.inc.php'),
('error_reporting', '1'),
('send_errormail', '0'),
('pwd_hash_algo', 'MD5'),
('reload_captcha_words', ''),
('captcha_words_default', 'MODX,Access,Better,BitCode,Chunk,Cache,Desc,Design,Excell,Enjoy,URLs,TechView,Gerald,Griff,Humphrey,Holiday,Intel,Integration,Joystick,Join(),Oscope,Genetic,Light,Likeness,Marit,Maaike,Niche,Netherlands,Ordinance,Oscillo,Parser,Phusion,Query,Question,Regalia,Righteous,Snippet,Sentinel,Template,Thespian,Unity,Enterprise,Verily,Tattoo,Veri,Website,WideWeb,Yap,Yellow,Zebra,Zygote'),
('smtp_secure', 'none'),
('reload_emailsubject', ''),
('emailsubject_default', 'Данные для авторизации'),
('reload_signupemail_message', ''),
('signupemail_message', 'Здравствуйте, [+uid+]!\r\n\r\nВаши данные для авторизации в системе управления сайтом [+sname+]:\r\n\r\nИмя пользователя: [+uid+]\r\nПароль: [+pwd+]\r\n\r\nПосле успешной авторизации в системе управления сайтом ([+surl+]), вы сможете изменить свой пароль.\r\n\r\nС уважением, Администрация'),
('system_email_signup_default', 'Здравствуйте, [+uid+]!\r\n\r\nВаши данные для авторизации в системе управления сайтом [+sname+]:\r\n\r\nИмя пользователя: [+uid+]\r\nПароль: [+pwd+]\r\n\r\nПосле успешной авторизации в системе управления сайтом ([+surl+]), вы сможете изменить свой пароль.\r\n\r\nС уважением, Администрация'),
('reload_websignupemail_message', ''),
('websignupemail_message', 'Здравствуйте, [+uid+]!\r\n\r\nВаши данные для авторизации на [+sname+]:\r\n\r\nИмя пользователя: [+uid+]\r\nПароль: [+pwd+]\r\n\r\nПосле успешной авторизации на [+sname+] ([+surl+]), вы сможете изменить свой пароль.\r\n\r\nС уважением, Администрация'),
('system_email_websignup_default', 'Здравствуйте, [+uid+]!\r\n\r\nВаши данные для авторизации на [+sname+]:\r\n\r\nИмя пользователя: [+uid+]\r\nПароль: [+pwd+]\r\n\r\nПосле успешной авторизации на [+sname+] ([+surl+]), вы сможете изменить свой пароль.\r\n\r\nС уважением, Администрация'),
('reload_system_email_webreminder_message', ''),
('webpwdreminder_message', 'Здравствуйте, [+uid+]!\r\n\r\nЧтобы активировать ваш новый пароль, перейдите по следующей ссылке:\r\n\r\n[+surl+]\r\n\r\nПозже вы сможете использовать следующий пароль для авторизации: [+pwd+]\r\n\r\nЕсли это письмо пришло к вам по ошибке, пожалуйста, проигнорируйте его.\r\n\r\nС уважением, Администрация'),
('system_email_webreminder_default', 'Здравствуйте, [+uid+]!\r\n\r\nЧтобы активировать ваш новый пароль, перейдите по следующей ссылке:\r\n\r\n[+surl+]\r\n\r\nПозже вы сможете использовать следующий пароль для авторизации: [+pwd+]\r\n\r\nЕсли это письмо пришло к вам по ошибке, пожалуйста, проигнорируйте его.\r\n\r\nС уважением, Администрация'),
('resource_tree_node_name', 'pagetitle'),
('mce_editor_skin', 'cirkuit'),
('mce_template_docs', ''),
('mce_template_chunks', ''),
('mce_entermode', 'p'),
('mce_element_format', 'xhtml'),
('mce_schema', 'html4'),
('tinymce_custom_buttons3', ''),
('tinymce_custom_buttons4', ''),
('tinymce_css_selectors', 'left=justifyleft;right=justifyright'),
('rb_webuser', '0'),
('sys_files_checksum', 'a:4:{s:51:"/home/u383720/masterstroy-rnd.ru/www/_new/index.php";s:32:"657db3d7274dbb84c80d4aac08a75417";s:51:"/home/u383720/masterstroy-rnd.ru/www/_new/.htaccess";s:32:"cdd9674795767aab6a8e3ad754f3cb3f";s:59:"/home/u383720/masterstroy-rnd.ru/www/_new/manager/index.php";s:32:"5db76a440c8e2388efe93e738025f5d6";s:73:"/home/u383720/masterstroy-rnd.ru/www/_new/manager/includes/config.inc.php";s:32:"8fc54c346359499f0ceeed2dcd011a9f";}');

-- --------------------------------------------------------

--
-- Структура таблицы `ms_user_attributes`
--

CREATE TABLE IF NOT EXISTS `ms_user_attributes` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `internalKey` int(10) NOT NULL DEFAULT '0',
  `fullname` varchar(100) NOT NULL DEFAULT '',
  `role` int(10) NOT NULL DEFAULT '0',
  `email` varchar(100) NOT NULL DEFAULT '',
  `phone` varchar(100) NOT NULL DEFAULT '',
  `mobilephone` varchar(100) NOT NULL DEFAULT '',
  `blocked` int(1) NOT NULL DEFAULT '0',
  `blockeduntil` int(11) NOT NULL DEFAULT '0',
  `blockedafter` int(11) NOT NULL DEFAULT '0',
  `logincount` int(11) NOT NULL DEFAULT '0',
  `lastlogin` int(11) NOT NULL DEFAULT '0',
  `thislogin` int(11) NOT NULL DEFAULT '0',
  `failedlogincount` int(10) NOT NULL DEFAULT '0',
  `sessionid` varchar(100) NOT NULL DEFAULT '',
  `dob` int(10) NOT NULL DEFAULT '0',
  `gender` int(1) NOT NULL DEFAULT '0' COMMENT '0 - unknown, 1 - Male 2 - female',
  `country` varchar(5) NOT NULL DEFAULT '',
  `street` varchar(255) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  `state` varchar(25) NOT NULL DEFAULT '',
  `zip` varchar(25) NOT NULL DEFAULT '',
  `fax` varchar(100) NOT NULL DEFAULT '',
  `photo` varchar(255) NOT NULL DEFAULT '' COMMENT 'link to photo',
  `comment` text,
  PRIMARY KEY (`id`),
  KEY `userid` (`internalKey`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 COMMENT='Contains information about the backend users.' AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `ms_user_attributes`
--

INSERT INTO `ms_user_attributes` (`id`, `internalKey`, `fullname`, `role`, `email`, `phone`, `mobilephone`, `blocked`, `blockeduntil`, `blockedafter`, `logincount`, `lastlogin`, `thislogin`, `failedlogincount`, `sessionid`, `dob`, `gender`, `country`, `street`, `city`, `state`, `zip`, `fax`, `photo`, `comment`) VALUES
(1, 1, 'Default admin account', 1, 'sergey.it7@gmail.com', '', '', 0, 0, 0, 4, 1468564050, 1468666677, 0, 'dm0lm7mdjgcoqu4h2rajg8or82', 0, 0, '', '', '', '', '', '', '', ''),
(2, 2, '', 2, 'mrvlhf@mail.ru', '', '', 0, 0, 0, 0, 0, 0, 0, '', 0, 0, '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Структура таблицы `ms_user_messages`
--

CREATE TABLE IF NOT EXISTS `ms_user_messages` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `type` varchar(15) NOT NULL DEFAULT '',
  `subject` varchar(60) NOT NULL DEFAULT '',
  `message` text,
  `sender` int(10) NOT NULL DEFAULT '0',
  `recipient` int(10) NOT NULL DEFAULT '0',
  `private` tinyint(4) NOT NULL DEFAULT '0',
  `postdate` int(20) NOT NULL DEFAULT '0',
  `messageread` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='Contains messages for the Content Manager messaging system.' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `ms_user_roles`
--

CREATE TABLE IF NOT EXISTS `ms_user_roles` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `frames` int(1) NOT NULL DEFAULT '0',
  `home` int(1) NOT NULL DEFAULT '0',
  `view_document` int(1) NOT NULL DEFAULT '0',
  `new_document` int(1) NOT NULL DEFAULT '0',
  `save_document` int(1) NOT NULL DEFAULT '0',
  `publish_document` int(1) NOT NULL DEFAULT '0',
  `delete_document` int(1) NOT NULL DEFAULT '0',
  `empty_trash` int(1) NOT NULL DEFAULT '0',
  `action_ok` int(1) NOT NULL DEFAULT '0',
  `logout` int(1) NOT NULL DEFAULT '0',
  `help` int(1) NOT NULL DEFAULT '0',
  `messages` int(1) NOT NULL DEFAULT '0',
  `new_user` int(1) NOT NULL DEFAULT '0',
  `edit_user` int(1) NOT NULL DEFAULT '0',
  `logs` int(1) NOT NULL DEFAULT '0',
  `edit_parser` int(1) NOT NULL DEFAULT '0',
  `save_parser` int(1) NOT NULL DEFAULT '0',
  `edit_template` int(1) NOT NULL DEFAULT '0',
  `settings` int(1) NOT NULL DEFAULT '0',
  `credits` int(1) NOT NULL DEFAULT '0',
  `new_template` int(1) NOT NULL DEFAULT '0',
  `save_template` int(1) NOT NULL DEFAULT '0',
  `delete_template` int(1) NOT NULL DEFAULT '0',
  `edit_snippet` int(1) NOT NULL DEFAULT '0',
  `new_snippet` int(1) NOT NULL DEFAULT '0',
  `save_snippet` int(1) NOT NULL DEFAULT '0',
  `delete_snippet` int(1) NOT NULL DEFAULT '0',
  `edit_chunk` int(1) NOT NULL DEFAULT '0',
  `new_chunk` int(1) NOT NULL DEFAULT '0',
  `save_chunk` int(1) NOT NULL DEFAULT '0',
  `delete_chunk` int(1) NOT NULL DEFAULT '0',
  `empty_cache` int(1) NOT NULL DEFAULT '0',
  `edit_document` int(1) NOT NULL DEFAULT '0',
  `change_password` int(1) NOT NULL DEFAULT '0',
  `error_dialog` int(1) NOT NULL DEFAULT '0',
  `about` int(1) NOT NULL DEFAULT '0',
  `file_manager` int(1) NOT NULL DEFAULT '0',
  `save_user` int(1) NOT NULL DEFAULT '0',
  `delete_user` int(1) NOT NULL DEFAULT '0',
  `save_password` int(11) NOT NULL DEFAULT '0',
  `edit_role` int(1) NOT NULL DEFAULT '0',
  `save_role` int(1) NOT NULL DEFAULT '0',
  `delete_role` int(1) NOT NULL DEFAULT '0',
  `new_role` int(1) NOT NULL DEFAULT '0',
  `access_permissions` int(1) NOT NULL DEFAULT '0',
  `bk_manager` int(1) NOT NULL DEFAULT '0',
  `new_plugin` int(1) NOT NULL DEFAULT '0',
  `edit_plugin` int(1) NOT NULL DEFAULT '0',
  `save_plugin` int(1) NOT NULL DEFAULT '0',
  `delete_plugin` int(1) NOT NULL DEFAULT '0',
  `new_module` int(1) NOT NULL DEFAULT '0',
  `edit_module` int(1) NOT NULL DEFAULT '0',
  `save_module` int(1) NOT NULL DEFAULT '0',
  `delete_module` int(1) NOT NULL DEFAULT '0',
  `exec_module` int(1) NOT NULL DEFAULT '0',
  `view_eventlog` int(1) NOT NULL DEFAULT '0',
  `delete_eventlog` int(1) NOT NULL DEFAULT '0',
  `manage_metatags` int(1) NOT NULL DEFAULT '0' COMMENT 'manage site meta tags and keywords',
  `edit_doc_metatags` int(1) NOT NULL DEFAULT '0' COMMENT 'edit document meta tags and keywords',
  `new_web_user` int(1) NOT NULL DEFAULT '0',
  `edit_web_user` int(1) NOT NULL DEFAULT '0',
  `save_web_user` int(1) NOT NULL DEFAULT '0',
  `delete_web_user` int(1) NOT NULL DEFAULT '0',
  `web_access_permissions` int(1) NOT NULL DEFAULT '0',
  `view_unpublished` int(1) NOT NULL DEFAULT '0',
  `import_static` int(1) NOT NULL DEFAULT '0',
  `export_static` int(1) NOT NULL DEFAULT '0',
  `remove_locks` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 COMMENT='Contains information describing the user roles.' AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `ms_user_roles`
--

INSERT INTO `ms_user_roles` (`id`, `name`, `description`, `frames`, `home`, `view_document`, `new_document`, `save_document`, `publish_document`, `delete_document`, `empty_trash`, `action_ok`, `logout`, `help`, `messages`, `new_user`, `edit_user`, `logs`, `edit_parser`, `save_parser`, `edit_template`, `settings`, `credits`, `new_template`, `save_template`, `delete_template`, `edit_snippet`, `new_snippet`, `save_snippet`, `delete_snippet`, `edit_chunk`, `new_chunk`, `save_chunk`, `delete_chunk`, `empty_cache`, `edit_document`, `change_password`, `error_dialog`, `about`, `file_manager`, `save_user`, `delete_user`, `save_password`, `edit_role`, `save_role`, `delete_role`, `new_role`, `access_permissions`, `bk_manager`, `new_plugin`, `edit_plugin`, `save_plugin`, `delete_plugin`, `new_module`, `edit_module`, `save_module`, `delete_module`, `exec_module`, `view_eventlog`, `delete_eventlog`, `manage_metatags`, `edit_doc_metatags`, `new_web_user`, `edit_web_user`, `save_web_user`, `delete_web_user`, `web_access_permissions`, `view_unpublished`, `import_static`, `export_static`, `remove_locks`) VALUES
(2, 'Editor', 'Limited to managing content', 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1),
(3, 'Publisher', 'Editor with expanded permissions including manage users, update Elements and site settings', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 1),
(1, 'Administrator', 'Site administrators have full access to all functions', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `ms_user_settings`
--

CREATE TABLE IF NOT EXISTS `ms_user_settings` (
  `user` int(11) NOT NULL,
  `setting_name` varchar(50) NOT NULL DEFAULT '',
  `setting_value` text,
  PRIMARY KEY (`user`,`setting_name`),
  KEY `setting_name` (`setting_name`),
  KEY `user` (`user`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='Contains backend user settings.';

--
-- Дамп данных таблицы `ms_user_settings`
--

INSERT INTO `ms_user_settings` (`user`, `setting_name`, `setting_value`) VALUES
(1, 'allow_manager_access', '1'),
(1, 'which_editor', 'none'),
(2, 'allow_manager_access', '1');

-- --------------------------------------------------------

--
-- Структура таблицы `ms_webgroup_access`
--

CREATE TABLE IF NOT EXISTS `ms_webgroup_access` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `webgroup` int(10) NOT NULL DEFAULT '0',
  `documentgroup` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='Contains data used for web access permissions.' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `ms_webgroup_names`
--

CREATE TABLE IF NOT EXISTS `ms_webgroup_names` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='Contains data used for web access permissions.' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `ms_web_groups`
--

CREATE TABLE IF NOT EXISTS `ms_web_groups` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `webgroup` int(10) NOT NULL DEFAULT '0',
  `webuser` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_group_user` (`webgroup`,`webuser`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='Contains data used for web access permissions.' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `ms_web_users`
--

CREATE TABLE IF NOT EXISTS `ms_web_users` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `password` varchar(100) NOT NULL DEFAULT '',
  `cachepwd` varchar(100) NOT NULL DEFAULT '' COMMENT 'Store new unconfirmed password',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `ms_web_user_attributes`
--

CREATE TABLE IF NOT EXISTS `ms_web_user_attributes` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `internalKey` int(10) NOT NULL DEFAULT '0',
  `fullname` varchar(100) NOT NULL DEFAULT '',
  `role` int(10) NOT NULL DEFAULT '0',
  `email` varchar(100) NOT NULL DEFAULT '',
  `phone` varchar(100) NOT NULL DEFAULT '',
  `mobilephone` varchar(100) NOT NULL DEFAULT '',
  `blocked` int(1) NOT NULL DEFAULT '0',
  `blockeduntil` int(11) NOT NULL DEFAULT '0',
  `blockedafter` int(11) NOT NULL DEFAULT '0',
  `logincount` int(11) NOT NULL DEFAULT '0',
  `lastlogin` int(11) NOT NULL DEFAULT '0',
  `thislogin` int(11) NOT NULL DEFAULT '0',
  `failedlogincount` int(10) NOT NULL DEFAULT '0',
  `sessionid` varchar(100) NOT NULL DEFAULT '',
  `dob` int(10) NOT NULL DEFAULT '0',
  `gender` int(1) NOT NULL DEFAULT '0' COMMENT '0 - unknown, 1 - Male 2 - female',
  `country` varchar(25) NOT NULL DEFAULT '',
  `street` varchar(255) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  `state` varchar(25) NOT NULL DEFAULT '',
  `zip` varchar(25) NOT NULL DEFAULT '',
  `fax` varchar(100) NOT NULL DEFAULT '',
  `photo` varchar(255) NOT NULL DEFAULT '' COMMENT 'link to photo',
  `comment` text,
  PRIMARY KEY (`id`),
  KEY `userid` (`internalKey`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='Contains information for web users.' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `ms_web_user_settings`
--

CREATE TABLE IF NOT EXISTS `ms_web_user_settings` (
  `webuser` int(11) NOT NULL,
  `setting_name` varchar(50) NOT NULL DEFAULT '',
  `setting_value` text,
  PRIMARY KEY (`webuser`,`setting_name`),
  KEY `setting_name` (`setting_name`),
  KEY `webuserid` (`webuser`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='Contains web user settings.';

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
