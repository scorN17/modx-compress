<?php
$c=&$this->config;$c['manager_theme']="MODxRE";$c['settings_version']="1.1";$c['show_meta']="0";$c['server_offset_time']="0";$c['server_protocol']="http";$c['manager_language']="russian-UTF8";$c['modx_charset']="UTF-8";$c['site_name']="Мастерстрой";$c['site_start']="1";$c['error_page']="9";$c['unauthorized_page']="10";$c['site_status']="1";$c['site_unavailable_message']="The site is currently unavailable";$c['track_visitors']="0";$c['top_howmany']="10";$c['auto_template_logic']="parent";$c['default_template']="3";$c['old_template']="3";$c['publish_default']="1";$c['cache_default']="1";$c['search_default']="1";$c['friendly_urls']="1";$c['friendly_url_prefix']="";$c['friendly_url_suffix']=".html";$c['friendly_alias_urls']="1";$c['use_alias_path']="1";$c['use_udperms']="1";$c['udperms_allowroot']="1";$c['failed_login_attempts']="20";$c['blocked_minutes']="20";$c['use_captcha']="0";$c['captcha_words']="MODX,Access,Better,BitCode,Cache,Desc,Design,Excell,Enjoy,URLs,TechView,Gerald,Griff,Humphrey,Holiday,Intel,Integration,Joystick,Join(),Tattoo,Genetic,Light,Likeness,Marit,Maaike,Niche,Netherlands,Ordinance,Oscillo,Parser,Phusion,Query,Question,Regalia,Righteous,Snippet,Sentinel,Template,Thespian,Unity,Enterprise,Verily,Veri,Website,WideWeb,Yap,Yellow,Zebra,Zygote";$c['emailsender']="mrvlhf@mail.ru";$c['email_method']="mail";$c['smtp_auth']="0";$c['smtp_host']="";$c['smtp_port']="25";$c['smtp_username']="";$c['emailsubject']="Your login details";$c['number_of_logs']="100";$c['number_of_messages']="30";$c['number_of_results']="20";$c['use_editor']="1";$c['use_browser']="1";$c['rb_base_dir']="/home/u383720/masterstroy-rnd.ru/www/_new/assets/";$c['rb_base_url']="assets/";$c['which_editor']="TinyMCE";$c['fe_editor_lang']="russian-UTF8";$c['fck_editor_toolbar']="standard";$c['fck_editor_autolang']="0";$c['editor_css_path']="";$c['editor_css_selectors']="";$c['strip_image_paths']="1";$c['upload_images']="bmp,ico,gif,jpeg,jpg,png,psd,tif,tiff";$c['upload_media']="au,avi,mp3,mp4,mpeg,mpg,wav,wmv";$c['upload_flash']="fla,flv,swf";$c['upload_files']="bmp,ico,gif,jpeg,jpg,png,psd,tif,tiff,fla,flv,swf,aac,au,avi,css,cache,doc,docx,gz,gzip,htaccess,htm,html,js,mp3,mp4,mpeg,mpg,ods,odp,odt,pdf,ppt,pptx,rar,tar,tgz,txt,wav,wmv,xls,xlsx,xml,z,zip,JPG,JPEG,PNG,GIF";$c['upload_maxsize']="50485760";$c['new_file_permissions']="0755";$c['new_folder_permissions']="0755";$c['filemanager_path']="/home/u383720/masterstroy-rnd.ru/www/_new/";$c['theme_refresher']="";$c['manager_layout']="4";$c['custom_contenttype']="application/rss+xml,application/pdf,application/vnd.ms-word,application/vnd.ms-excel,text/html,text/css,text/xml,text/javascript,text/plain,application/json";$c['auto_menuindex']="1";$c['session.cookie.lifetime']="604800";$c['mail_check_timeperiod']="60";$c['manager_direction']="ltr";$c['tinymce_editor_theme']="editor";$c['tinymce_custom_plugins']="style,advimage,advlink,searchreplace,print,contextmenu,paste,fullscreen,nonbreaking,xhtmlxtras,visualchars,media";$c['tinymce_custom_buttons1']="undo,redo,selectall,separator,pastetext,pasteword,separator,search,replace,separator,nonbreaking,hr,charmap,separator,image,link,unlink,anchor,media,separator,cleanup,removeformat,separator,fullscreen,print,code,help";$c['tinymce_custom_buttons2']="bold,italic,underline,strikethrough,sub,sup,separator,bullist,numlist,outdent,indent,separator,justifyleft,justifycenter,justifyright,justifyfull,separator,styleselect,formatselect,separator,styleprops";$c['tree_show_protected']="0";$c['rss_url_news']="http://feeds.feedburner.com/modx-announce";$c['rss_url_security']="http://feeds.feedburner.com/modxsecurity";$c['validate_referer']="1";$c['datepicker_offset']="-10";$c['xhtml_urls']="1";$c['allow_duplicate_alias']="0";$c['automatic_alias']="1";$c['datetime_format']="dd-mm-YYYY";$c['warning_visibility']="0";$c['remember_last_tab']="1";$c['enable_bindings']="1";$c['seostrict']="1";$c['cache_type']="1";$c['maxImageWidth']="7777";$c['maxImageHeight']="7777";$c['thumbWidth']="150";$c['thumbHeight']="150";$c['thumbsDir']=".thumbs";$c['jpegQuality']="90";$c['denyZipDownload']="0";$c['denyExtensionRename']="0";$c['showHiddenFiles']="0";$c['docid_incrmnt_method']="0";$c['make_folders']="1";$c['tree_page_click']="27";$c['clean_uploaded_filename']="1";$c['site_id']="5787832c68e0c";$c['site_unavailable_page']="10";$c['reload_site_unavailable']="";$c['siteunavailable_message_default']="В настоящее время сайт недоступен.";$c['aliaslistingfolder']="0";$c['check_files_onlogin']="index.php\r\n.htaccess\r\nmanager/index.php\r\nmanager/includes/config.inc.php";$c['error_reporting']="1";$c['send_errormail']="0";$c['pwd_hash_algo']="MD5";$c['reload_captcha_words']="";$c['captcha_words_default']="MODX,Access,Better,BitCode,Chunk,Cache,Desc,Design,Excell,Enjoy,URLs,TechView,Gerald,Griff,Humphrey,Holiday,Intel,Integration,Joystick,Join(),Oscope,Genetic,Light,Likeness,Marit,Maaike,Niche,Netherlands,Ordinance,Oscillo,Parser,Phusion,Query,Question,Regalia,Righteous,Snippet,Sentinel,Template,Thespian,Unity,Enterprise,Verily,Tattoo,Veri,Website,WideWeb,Yap,Yellow,Zebra,Zygote";$c['smtp_secure']="none";$c['reload_emailsubject']="";$c['emailsubject_default']="Данные для авторизации";$c['reload_signupemail_message']="";$c['signupemail_message']="Здравствуйте, [+uid+]!\r\n\r\nВаши данные для авторизации в системе управления сайтом [+sname+]:\r\n\r\nИмя пользователя: [+uid+]\r\nПароль: [+pwd+]\r\n\r\nПосле успешной авторизации в системе управления сайтом ([+surl+]), вы сможете изменить свой пароль.\r\n\r\nС уважением, Администрация";$c['system_email_signup_default']="Здравствуйте, [+uid+]!\r\n\r\nВаши данные для авторизации в системе управления сайтом [+sname+]:\r\n\r\nИмя пользователя: [+uid+]\r\nПароль: [+pwd+]\r\n\r\nПосле успешной авторизации в системе управления сайтом ([+surl+]), вы сможете изменить свой пароль.\r\n\r\nС уважением, Администрация";$c['reload_websignupemail_message']="";$c['websignupemail_message']="Здравствуйте, [+uid+]!\r\n\r\nВаши данные для авторизации на [+sname+]:\r\n\r\nИмя пользователя: [+uid+]\r\nПароль: [+pwd+]\r\n\r\nПосле успешной авторизации на [+sname+] ([+surl+]), вы сможете изменить свой пароль.\r\n\r\nС уважением, Администрация";$c['system_email_websignup_default']="Здравствуйте, [+uid+]!\r\n\r\nВаши данные для авторизации на [+sname+]:\r\n\r\nИмя пользователя: [+uid+]\r\nПароль: [+pwd+]\r\n\r\nПосле успешной авторизации на [+sname+] ([+surl+]), вы сможете изменить свой пароль.\r\n\r\nС уважением, Администрация";$c['reload_system_email_webreminder_message']="";$c['webpwdreminder_message']="Здравствуйте, [+uid+]!\r\n\r\nЧтобы активировать ваш новый пароль, перейдите по следующей ссылке:\r\n\r\n[+surl+]\r\n\r\nПозже вы сможете использовать следующий пароль для авторизации: [+pwd+]\r\n\r\nЕсли это письмо пришло к вам по ошибке, пожалуйста, проигнорируйте его.\r\n\r\nС уважением, Администрация";$c['system_email_webreminder_default']="Здравствуйте, [+uid+]!\r\n\r\nЧтобы активировать ваш новый пароль, перейдите по следующей ссылке:\r\n\r\n[+surl+]\r\n\r\nПозже вы сможете использовать следующий пароль для авторизации: [+pwd+]\r\n\r\nЕсли это письмо пришло к вам по ошибке, пожалуйста, проигнорируйте его.\r\n\r\nС уважением, Администрация";$c['resource_tree_node_name']="pagetitle";$c['mce_editor_skin']="cirkuit";$c['mce_template_docs']="";$c['mce_template_chunks']="";$c['mce_entermode']="p";$c['mce_element_format']="xhtml";$c['mce_schema']="html4";$c['tinymce_custom_buttons3']="";$c['tinymce_custom_buttons4']="";$c['tinymce_css_selectors']="left=justifyleft;right=justifyright";$c['rb_webuser']="0";$c['sys_files_checksum']="a:4:{s:51:\"/home/u383720/masterstroy-rnd.ru/www/_new/index.php\";s:32:\"657db3d7274dbb84c80d4aac08a75417\";s:51:\"/home/u383720/masterstroy-rnd.ru/www/_new/.htaccess\";s:32:\"cdd9674795767aab6a8e3ad754f3cb3f\";s:59:\"/home/u383720/masterstroy-rnd.ru/www/_new/manager/index.php\";s:32:\"5db76a440c8e2388efe93e738025f5d6\";s:73:\"/home/u383720/masterstroy-rnd.ru/www/_new/manager/includes/config.inc.php\";s:32:\"8fc54c346359499f0ceeed2dcd011a9f\";}";$this->aliasListing=array();$a=&$this->aliasListing;$d=&$this->documentListing;$m=&$this->documentMap;$d['topmenu'] = 3;$a[3] = array('id' => 3, 'alias' => 'topmenu', 'path' => '', 'parent' => 0, 'isfolder' => 1);$m[] = array('0' => '3');$d['catalog'] = 7;$a[7] = array('id' => 7, 'alias' => 'catalog', 'path' => '', 'parent' => 0, 'isfolder' => 0);$m[] = array('0' => '7');$d['pages'] = 15;$a[15] = array('id' => 15, 'alias' => 'pages', 'path' => '', 'parent' => 0, 'isfolder' => 1);$m[] = array('0' => '15');$d['techpages'] = 8;$a[8] = array('id' => 8, 'alias' => 'techpages', 'path' => '', 'parent' => 0, 'isfolder' => 1);$m[] = array('0' => '8');$d['index'] = 1;$a[1] = array('id' => 1, 'alias' => 'index', 'path' => '', 'parent' => 3, 'isfolder' => 0);$m[] = array('3' => '1');$d['dostavka-i-oplata'] = 2;$a[2] = array('id' => 2, 'alias' => 'dostavka-i-oplata', 'path' => '', 'parent' => 3, 'isfolder' => 0);$m[] = array('3' => '2');$d['stati'] = 4;$a[4] = array('id' => 4, 'alias' => 'stati', 'path' => '', 'parent' => 3, 'isfolder' => 0);$m[] = array('3' => '4');$d['mail'] = 5;$a[5] = array('id' => 5, 'alias' => 'mail', 'path' => '', 'parent' => 3, 'isfolder' => 0);$m[] = array('3' => '5');$d['contacts'] = 6;$a[6] = array('id' => 6, 'alias' => 'contacts', 'path' => '', 'parent' => 3, 'isfolder' => 0);$m[] = array('3' => '6');$d['404'] = 9;$a[9] = array('id' => 9, 'alias' => '404', 'path' => '', 'parent' => 8, 'isfolder' => 0);$m[] = array('8' => '9');$d['fail'] = 10;$a[10] = array('id' => 10, 'alias' => 'fail', 'path' => '', 'parent' => 8, 'isfolder' => 0);$m[] = array('8' => '10');$d['shop'] = 11;$a[11] = array('id' => 11, 'alias' => 'shop', 'path' => '', 'parent' => 8, 'isfolder' => 1);$m[] = array('8' => '11');$d['____action'] = 13;$a[13] = array('id' => 13, 'alias' => '____action', 'path' => '', 'parent' => 8, 'isfolder' => 1);$m[] = array('8' => '13');$d['basket'] = 12;$a[12] = array('id' => 12, 'alias' => 'basket', 'path' => '', 'parent' => 11, 'isfolder' => 0);$m[] = array('11' => '12');$d['ajax'] = 14;$a[14] = array('id' => 14, 'alias' => 'ajax', 'path' => '', 'parent' => 13, 'isfolder' => 0);$m[] = array('13' => '14');$d['search'] = 16;$a[16] = array('id' => 16, 'alias' => 'search', 'path' => '', 'parent' => 15, 'isfolder' => 0);$m[] = array('15' => '16');$c = &$this->contentTypes;$c = &$this->chunkCache;$c['mm_rules'] = '// more example rules are in assets/plugins/managermanager/example_mm_rules.inc.php
// example of how PHP is allowed - check that a TV named documentTags exists before creating rule

if ($modx->db->getValue($modx->db->select(\'count(id)\', $modx->getFullTableName(\'site_tmplvars\'), "name=\'documentTags\'"))) {
	mm_widget_tags(\'documentTags\', \' \'); // Give blog tag editing capabilities to the \'documentTags (3)\' TV
}
mm_widget_showimagetvs(); // Always give a preview of Image TVs

mm_moveFieldsToTab( "published,alias_visible", "general" );
	
mm_moveFieldsToTab( \'longtitle,description,menutitle,log,searchable,link_attributes\', \'settings\' );
';$c['HEAD'] = '<!DOCTYPE html>
<html lang="ru">
	<head>
		<meta charset="[(modx_charset)]" />
		<!--[if lt IE 9]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->

		<base_and_canonical />

		<title>[*seo_title*]</title>
		<meta name="description" content="[*seo_description*]" />
		<meta name="keywords" content="[*seo_keywords*]" />

		<meta name="viewport" content="width=device-width, initial-scale=1" />

		<link rel="icon" href="favicon.ico" type="image/x-icon" />
		<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
		<!-- ==================================================================== -->

		<!-- JS & CSS -->
		<script type="text/javascript" src="[!Compress? &compress=`false` &files=`template/js/jquery/: jquery-2.1.4.min.js, jquery-ui.min.js` &tofile=`template/js/jquery/jquery.js`!]"></script>
		<link rel="stylesheet" type="text/css" href="[!Compress? &files=`template/css/: main.css, dop.css, catalog.css, shop.css` &tofile=`template/css/all.compress.css`!]" />
		<!-- JS & CSS -->

		<script type="text/javascript">
			$v(function(){
				$v( ".cat-item" ).hover(
					function(){
						$v( ".children", this ).toggle( \'slide\', {}, 100 );
					}
				);
			});
		</script>

		{{GoogleAnalytics}}
		
		<!-- <a class="highslide" onclick="return hs.expand(this)"> -->
	</head>
	<body id="bdy">
		<div class="mainwrapper [[if? &is=`[*id*]:=:1` &then=`mainwrapper_mainpage` &else=` `]]">
			<!-- ================================================= -->';$c['FOOTER'] = '<div class="footer_br">&nbsp;</div>
<footer class="wrapper_footer">
   <div itemscope itemtype="http://schema.org/LocalBusiness" class="footer mw1100px">
	   <div class="foot_1 hcont">
		   <div itemprop="address" itemscope itemtype="http://schema.org/PostalAddress" class="hc_addr"><span class="famicon">&nbsp;</span> <span itemprop="postalCode">344000</span>, <span itemprop="addressCountry">Россия</span>, <span itemprop="addressLocality">г. Ростов-на-Дону</span>, <span itemprop="streetAddress">ул. Таганрогская, д. 144</span></div>

		   <div itemprop="telephone" class="hc_phone"><span class="famicon">&nbsp;</span> +7 (863) 206-03-89</div>

		   <div class="hc_grafik"><span class="famicon2">&nbsp;</span> пн.-пт. 9:00 &ndash; 18:00</div>

		   <div class="hc_mail"><span class="famicon">&nbsp;</span> <a class="as3" href="mailto:mrvlhf@mail.ru"><span itemprop="email">mrvlhf@mail.ru</span></a></div>
	   </div>

	   <div class="foot_3">
		   <div>&copy; <span itemprop="name">«Мастерстрой»</span> &ndash; [[Date? &f=`Y`]]</div>
		   <div>
			   {{COUNTER}}
		   </div>
		   <div class="deltalink"><img src="template/images/deltalink.png" alt="DELTA" title="DELTA" /></div>
	   </div>

	   <div class="foot_2">
		   <div class="linkstosocseti">
			   <a class="fb" target="_blank" href="https://facebook.com/"><span>Facebook</span></a>
			   <a class="mru" target="_blank" href="http://my.mail.ru/"><span>Mail.ru</span></a>
			   <a class="ok" target="_blank" href="http://ok.ru/"><span>ok.ru</span></a>
			   <a class="vk" target="_blank" href="http://vk.com/"><span>ВКонтакте</span></a>
			   <div class="clr">&nbsp;</div>
		   </div>
	   </div>

	   <div class="foot_4">
		   <div class="footermenu">
			   <div class="foottit">Информация</div>
			   [[Wayfinder? &startId=`32` &rowTpl=`wf_botmenu_rowTpl`]]
		   </div>
	   </div>
	   <div class="clr">&nbsp;</div>
   </div>
</footer>

<!-- ================================================= -->
</div>

<div class="knopavverh">&nbsp;</div>

<!-- JS & CSS -->
<noscript><link rel="stylesheet" type="text/css" href="template/css/noscript.css" /></noscript>

<script type="text/javascript" src="template/js/highslide/highslide-with-gallery.min.js"></script>
<link rel="stylesheet" type="text/css" href="[!Compress? &file=`template/js/highslide/highslide.css`!]" />

<link rel="stylesheet" type="text/css" href="[!Compress? &file=`template/js/poshytip/tip-twitter/tip-twitter.css`!]" />
<script type="text/javascript" src="template/js/poshytip/jquery.poshytip.min.js"></script>

<script type="text/javascript" src="[!Compress? &files=`template/js/: scroll_animate.js, javascript.js, shop.js` &tofile=`template/js/all.compress.js`!]"></script>
<!-- JS & CSS -->

[!SuperPuperForms? &popup=`2` &class=`spfs_krzhk,phoneorder`!]

</body></html>';$c['GoogleAnalytics'] = '<script>(function(i,s,o,g,r,a,m){i[\'GoogleAnalyticsObject\']=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)})(window,document,\'script\',\'//www.google-analytics.com/analytics.js\',\'ga\');ga(\'create\', \'UA-71023734-1\', \'auto\');ga(\'send\', \'pageview\');</script>';$c['COUNTER'] = '<!--LiveInternet counter--><script type="text/javascript"><!--
document.write("<a href=\'//www.liveinternet.ru/click\' "+
"target=_blank><img src=\'//counter.yadro.ru/hit?t44.5;r"+
escape(document.referrer)+((typeof(screen)=="undefined")?"":
";s"+screen.width+"*"+screen.height+"*"+(screen.colorDepth?
screen.colorDepth:screen.pixelDepth))+";u"+escape(document.URL)+
";"+Math.random()+
"\' alt=\'\' title=\'LiveInternet\' "+
"border=\'0\' width=\'31\' height=\'31\'><\\/a>")
//--></script><!--/LiveInternet-->


<!-- Yandex.Metrika counter -->
<script type="text/javascript">
(function (d, w, c) {
    (w[c] = w[c] || []).push(function() {
        try {
            w.yaCounter16387657 = new Ya.Metrika({id:16387657,
                    webvisor:true,
                    clickmap:true,
                    trackLinks:true,
                    accurateTrackBounce:true});
        } catch(e) { }
    });

    var n = d.getElementsByTagName("script")[0],
        s = d.createElement("script"),
        f = function () { n.parentNode.insertBefore(s, n); };
    s.type = "text/javascript";
    s.async = true;
    s.src = (d.location.protocol == "https:" ? "https:" : "http:") + "//mc.yandex.ru/metrika/watch.js";

    if (w.opera == "[object Opera]") {
        d.addEventListener("DOMContentLoaded", f, false);
    } else { f(); }
})(document, window, "yandex_metrika_callbacks");
</script>
<noscript><div><img src="//mc.yandex.ru/watch/16387657" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
					<!-- PulsCen: company widget --><div style="font: normal 11px/120% arial !important; display: inline-block !important; //display: inline !important;"><div style="border: 1px solid #ffa200; background: url(http://www.pulscen.ru/images/informers/bg_orange.gif) 0 100% repeat-x #fff; height: 29px; overflow: hidden; display: inline-block !important; //display: inline !important;"><table style="width: 88px; margin: 0; border: 0; border-collapse: collapse;"><tr><td style="text-align: center; font: normal 11px/120% arial !important; white-space: nowrap; padding: 1px 2px 0; border: 0;"><nobr><a style="color: #000; text-decoration: none; outline: none;" href="http://masterstroy.pulscen.ru/">Мастерстрой</a></nobr></td></tr><tr><td style="padding: 2px 2px 1px; font: normal 11px/120% arial !important; border: 0;"><span style="float: right; font-size: 10px; padding: 0 !important; margin: -1px 0 0 !important;"><a style="color: #1c53a2; text-decoration: none; outline: none;" href="http://rostov.pulscen.ru/price/150504-yelektrodreli">PulsCen.ru</a></span><img src="http://www.pulscen.ru/cwds?c=918703ea3729ae1c6db95d736f3c8e0e" width="23" height="10" alt="Электродрели в Ростове-на-Дону" title="Электродрели в Ростове-на-Дону" /></td></tr></table></div></div><!-- // PulsCen: company widget -->
';$c['CONTENT_1'] = '<main class="center">
			<div class="white_block">
<!-- whiteblock whiteblock whiteblock whiteblock whiteblock whiteblock -->
				<div class="pathway">[[Breadcrumbs? &showCurrentCrumb=`0`]]</div>
				
				<div class="pagetitle"><h1>[*seo_h1*]</h1></div>
				
				<div class="content_br">&nbsp;</div>
				<div class="content">
<!-- content content content content content content content content content content content content content content content content -->';$c['CONTENT_2'] = '<!-- content content content content content content content content content content content content content content content content -->
					{{socseti}}
				</div>
<!-- whiteblock whiteblock whiteblock whiteblock whiteblock whiteblock -->
			</div>

		</main>';$c['socseti'] = '<div class="clr">&nbsp;</div>
<div class="socseti">
	<script type="text/javascript" src="//yastatic.net/es5-shims/0.0.2/es5-shims.min.js" charset="utf-8"></script><script type="text/javascript" src="//yastatic.net/share2/share.js" charset="utf-8"></script><div class="ya-share2" data-services="vkontakte,facebook,odnoklassniki,moimir,gplus,twitter,evernote,linkedin,lj,viber,whatsapp" data-counter=""></div>
</div>';$s=&$this->snippetCache;$s['DocLister']='return require MODX_BASE_PATH.\'assets/snippets/DocLister/snippet.DocLister.php\';';$s['AjaxSearch']='return require MODX_BASE_PATH.\'assets/snippets/ajaxSearch/snippet.ajaxSearch.php\';';$s['Breadcrumbs']='return require MODX_BASE_PATH.\'assets/snippets/breadcrumbs/snippet.breadcrumbs.php\';';$s['Ditto']='return require MODX_BASE_PATH.\'assets/snippets/ditto/snippet.ditto.php\';';$s['eForm']='return require MODX_BASE_PATH.\'assets/snippets/eform/snippet.eform.php\';';$s['FirstChildRedirect']='return require MODX_BASE_PATH.\'assets/snippets/firstchildredirect/snippet.firstchildredirect.php\';';$s['if']='return require MODX_BASE_PATH.\'assets/snippets/if/snippet.if.php\';';$s['Jot']='/*####
#
# Author: Armand "bS" Pondman (apondman@zerobarrier.nl)
#
# Latest Version: http://modx.com/extras/package/jot
# Jot Demo Site: http://projects.zerobarrier.nl/modx/
# Documentation: http://wiki.modxcms.com/index.php/Jot (wiki)
#
####*/

$jotPath = $modx->config[\'base_path\'] . \'assets/snippets/jot/\';
include_once($jotPath.\'jot.class.inc.php\');

$Jot = new CJot;
$Jot->VersionCheck("1.1.4");
$Jot->Set("path",$jotPath);
$Jot->Set("action", $action);
$Jot->Set("postdelay", $postdelay);
$Jot->Set("docid", $docid);
$Jot->Set("tagid", $tagid);
$Jot->Set("subscribe", $subscribe);
$Jot->Set("moderated", $moderated);
$Jot->Set("captcha", $captcha);
$Jot->Set("badwords", $badwords);
$Jot->Set("bw", $bw);
$Jot->Set("sortby", $sortby);
$Jot->Set("numdir", $numdir);
$Jot->Set("customfields", $customfields);
$Jot->Set("guestname", $guestname);
$Jot->Set("canpost", $canpost);
$Jot->Set("canview", $canview);
$Jot->Set("canedit", $canedit);
$Jot->Set("canmoderate", $canmoderate);
$Jot->Set("trusted", $trusted);
$Jot->Set("pagination", $pagination);
$Jot->Set("placeholders", $placeholders);
$Jot->Set("subjectSubscribe", $subjectSubscribe);
$Jot->Set("subjectModerate", $subjectModerate);
$Jot->Set("subjectAuthor", $subjectAuthor);
$Jot->Set("notify", $notify);
$Jot->Set("notifyAuthor", $notifyAuthor);
$Jot->Set("validate", $validate);
$Jot->Set("title", $title);
$Jot->Set("authorid", $authorid);
$Jot->Set("css", $css);
$Jot->Set("cssFile", $cssFile);
$Jot->Set("cssRowAlt", $cssRowAlt);
$Jot->Set("cssRowMe", $cssRowMe);
$Jot->Set("cssRowAuthor", $cssRowAuthor);
$Jot->Set("tplForm", $tplForm);
$Jot->Set("tplComments", $tplComments);
$Jot->Set("tplModerate", $tplModerate);
$Jot->Set("tplNav", $tplNav);
$Jot->Set("tplNotify", $tplNotify);
$Jot->Set("tplNotifyModerator", $tplNotifyModerator);
$Jot->Set("tplNotifyAuthor", $tplNotifyAuthor);
$Jot->Set("tplSubscribe", $tplSubscribe);
$Jot->Set("debug", $debug);
$Jot->Set("output", $output);
return $Jot->Run();';$s['ListIndexer']='return require MODX_BASE_PATH.\'assets/snippets/listindexer/snippet.listindexer.php\';';$s['MemberCheck']='return require MODX_BASE_PATH.\'assets/snippets/membercheck/snippet.membercheck.php\';';$s['Personalize']='return require MODX_BASE_PATH.\'assets/snippets/personalize/snippet.personalize.php\';';$s['phpthumb']='return require MODX_BASE_PATH.\'assets/snippets/phpthumb/snippet.phpthumb.php\';';$s['Reflect']='/*
 * Author: 
 *      Mark Kaplan for MODX CMF
 * 
 * Note: 
 *      If Reflect is not retrieving its own documents, make sure that the
 *          Ditto call feeding it has all of the fields in it that you plan on
 *       calling in your Reflect template. Furthermore, Reflect will ONLY
 *          show what is currently in the Ditto result set.
 *       Thus, if pagination is on it will ONLY show that page\'s items.
*/
 

// ---------------------------------------------------
//  Includes
// ---------------------------------------------------

$reflect_base = isset($reflect_base) ? $modx->config[\'base_path\'].$reflect_base : $modx->config[\'base_path\']."assets/snippets/reflect/";
/*
    Param: ditto_base
    
    Purpose:
    Location of Ditto files

    Options:
    Any valid folder location containing the Ditto source code with a trailing slash

    Default:
    [(base_path)]assets/snippets/ditto/
*/

$config = (isset($config)) ? $config : "default";
/*
    Param: config

    Purpose:
    Load a custom configuration

    Options:
    "default" - default blank config file
    CONFIG_NAME - Other configs installed in the configs folder or in any folder within the MODX base path via @FILE

    Default:
    "default"
    
    Related:
    - <extenders>
*/

require($reflect_base."configs/default.config.php");
require($reflect_base."default.templates.php");
if ($config != "default") {
    require((substr($config, 0, 5) != "@FILE") ? $reflect_base."configs/$config.config.php" : $modx->config[\'base_path\'].trim(substr($config, 5)));
}

// ---------------------------------------------------
//  Parameters
// ---------------------------------------------------

$id = isset($id) ? $id."_" : false;
/*
    Param: id

    Purpose:
    Unique ID for this Ditto instance for connection with other scripts (like Reflect) and unique URL parameters

    Options:
    Any valid folder location containing the Ditto source code with a trailing slash

    Default:
    "" - blank
*/
$getDocuments = isset($getDocuments) ? $getDocuments : 0;
/*
    Param: getDocuments

    Purpose:
    Force Reflect to get documents

    Options:
    0 - off
    1 - on
    
    Default:
    0 - off
*/
$showItems = isset($showItems) ? $showItems : 1;
/*
    Param: showItems

    Purpose:
    Show individual items in the archive

    Options:
    0 - off
    1 - on
    
    Default:
    1 - on
*/
$groupByYears = isset($groupByYears)? $groupByYears : 1;
/*
    Param: groupByYears

    Purpose:
    Group the archive by years

    Options:
    0 - off
    1 - on
    
    Default:
    1 - on
*/
$targetID = isset($targetID) ? $targetID : $modx->documentObject[\'id\'];
/*
    Param: targetID

    Purpose:
    ID for archive links to point to

    Options:
    Any MODX document with a Ditto call setup with extenders=`dateFilter`
    
    Default:
    Current MODX Document
*/
$dateSource = isset($dateSource) ? $dateSource : "createdon";
/*
    Param: dateSource

    Purpose:
    Date source to display for archive items

    Options:
    # - Any UNIX timestamp from MODX fields or TVs such as createdon, pub_date, or editedon
    
    Default:
    "createdon"
    
    Related:
    - <dateFormat>
*/
$dateFormat = isset($dateFormat) ? $dateFormat : "%d-%b-%y %H:%M";  
/*
    Param: dateFormat

    Purpose:
    Format the [+date+] placeholder in human readable form

    Options:
    Any PHP valid strftime option

    Default:
    "%d-%b-%y %H:%M"
    
    Related:
    - <dateSource>
*/
$yearSortDir = isset($yearSortDir) ? $yearSortDir : "DESC";
/*
    Param: yearSortDir

    Purpose:
    Direction to sort documents

    Options:
    ASC - ascending
    DESC - descending

    Default:
    "DESC"
    
    Related:
    - <monthSortDir>
*/
$monthSortDir = isset($monthSortDir) ? $monthSortDir : "ASC";
/*
    Param: monthSortDir

    Purpose:
    Direction to sort the months

    Options:
    ASC - ascending
    DESC - descending

    Default:
    "ASC"
    
    Related:
    - <yearSortDir>
*/
$start = isset($start)? intval($start) : 0;
/*
    Param: start

    Purpose:
    Number of documents to skip in the results
    
    Options:
    Any number

    Default:
    0
*/  
$phx = (isset($phx))? $phx : 1;
/*
    Param: phx

    Purpose:
    Use PHx formatting

    Options:
    0 - off
    1 - on
    
    Default:
    1 - on
*/
$emptymsg = isset($emptymsg)? $emptymsg : "The Ditto object is invalid. Please check it.";
/*
    Param: emptymsg

    Purpose:
    Message to return if error

    Options:
    Any string
    
    Default:
    The Ditto object is invalid. Please check it.
*/

// ---------------------------------------------------
//  Initialize Ditto
// ---------------------------------------------------
$placeholder = ($id != false && $getDocuments == 0) ? true : false;
if ($placeholder === false) {
    $rID = "reflect_".rand(1,1000);
    $itemTemplate = isset($tplItem) ? $tplItem: "@CODE:".$defaultTemplates[\'item\'];
    $dParams = array(
        "id" => "$rID",
        "save" => "3",  
        "summarize" => "all",
        "tpl" => $itemTemplate,
    );
    
    $source = $dittoSnippetName;
    $params = $dittoSnippetParameters;
        // TODO: Remove after 3.0
        
    if (isset($params)) {
        $givenParams = explode("|",$params);
        foreach ($givenParams as $parameter) {
            $p = explode(":",$parameter);
            $dParams[$p[0]] = $p[1];
        }
    }
    /*
        Param: params

        Purpose:
        Pass parameters to the Ditto instance used to retreive the documents

        Options:
        Any valid ditto parameters in the format name:value 
        with multiple parameters separated by a pipe (|)
        
        Note:
        This parameter is only needed for config, start, and phx as you can
        now simply use the parameter as if Reflect was Ditto

        Default:
        [NULL]
    */
    
    $reflectParameters = array(\'reflect_base\',\'config\',\'id\',\'getDocuments\',\'showItems\',\'groupByYears\',\'targetID\',\'yearSortDir\',\'monthSortDir\',\'start\',\'phx\',\'tplContainer\',\'tplYear\',\'tplMonth\',\'tplMonthInner\',\'tplItem\',\'save\');
    $params =& $modx->event->params;
    if(is_array($params)) {
        foreach ($params as $param=>$value) {
            if (!in_array($param,$reflectParameters) && substr($param,-3) != \'tpl\') {
                $dParams[$param] = $value;
            }
        }
    }

    $source = isset($source) ? $source : "Ditto";
    /*
        Param: source

        Purpose:
        Name of the Ditto snippet to use

        Options:
        Any valid snippet name

        Default:
        "Ditto"
    */
    $snippetOutput = $modx->runSnippet($source,$dParams);
    $ditto = $modx->getPlaceholder($rID."_ditto_object");
    $resource = $modx->getPlaceholder($rID."_ditto_resource");
} else {
    $ditto = $modx->getPlaceholder($id."ditto_object");
    $resource = $modx->getPlaceholder($id."ditto_resource");
}
if (!is_object($ditto) || !isset($ditto) || !isset($resource)) {
    return !empty($snippetOutput) ? $snippetOutput : $emptymsg;
}

// ---------------------------------------------------
//  Templates
// ---------------------------------------------------

$templates[\'tpl\'] = isset($tplContainer) ? $ditto->template->fetch($tplContainer): $defaultTemplates[\'tpl\'];
/*
    Param: tplContainer

    Purpose:
    Container template for the archive

    Options:
    - Any valid chunk name
    - Code via @CODE:
    - File via @FILE:

    Default:
    See default.tempates.php
*/
$templates[\'year\'] = isset($tplYear) ? $ditto->template->fetch($tplYear): $defaultTemplates[\'year\'];
/*
    Param: tplYear

    Purpose:
    Template for the year item

    Options:
    - Any valid chunk name
    - Code via @CODE:
    - File via @FILE:

    Default:
    See default.tempates.php
*/
$templates[\'year_inner\'] = isset($tplYearInner) ? $ditto->template->fetch($tplYearInner): $defaultTemplates[\'year_inner\'];
/*
    Param: tplYearInner

    Purpose:
    Template for the year item (the ul to hold the year template)

    Options:
    - Any valid chunk name
    - Code via @CODE:
    - File via @FILE:

    Default:
    See default.tempates.php
*/
$templates[\'month\'] = isset($tplMonth) ? $ditto->template->fetch($tplMonth): $defaultTemplates[\'month\'];
/*
    Param: tplMonth

    Purpose:
    Template for the month item

    Options:
    - Any valid chunk name
    - Code via @CODE:
    - File via @FILE:

    Default:
    See default.tempates.php
*/
$templates[\'month_inner\'] = isset($tplMonthInner) ? $ditto->template->fetch($tplMonthInner): $defaultTemplates[\'month_inner\'];
/*
    Param: tplMonthInner

    Purpose:
    Template for the month item  (the ul to hold the month template)

    Options:
    - Any valid chunk name
    - Code via @CODE:
    - File via @FILE:

    Default:
    See default.tempates.php
*/
$templates[\'item\'] = isset($tplItem) ? $ditto->template->fetch($tplItem): $defaultTemplates[\'item\'];
/*
    Param: tplItem

    Purpose:
    Template for the individual item

    Options:
    - Any valid chunk name
    - Code via @CODE:
    - File via @FILE:

    Default:
    See default.tempates.php
*/

$ditto->addField("date","display","custom");
    // force add the date field if receiving data from a Ditto instance

// ---------------------------------------------------
//  Reflect
// ---------------------------------------------------

if (function_exists("reflect") === FALSE) {
function reflect($templatesDocumentID, $showItems, $groupByYears, $resource, $templatesDateSource, $dateFormat, $ditto, $templates,$id,$start,$yearSortDir,$monthSortDir) {
    global $modx;
    $cal = array();
    $output = \'\';
    $ph = array(\'year\'=>\'\',\'month\'=>\'\',\'item\'=>\'\',\'out\'=>\'\');
    $build = array();
    $stop = count($resource);

    // loop and fetch all the results
    for ($i = $start; $i < $stop; $i++) {
        $date = getdate($resource[$i][$templatesDateSource]);
        $year = $date["year"];
        $month = $date["mon"];
        $cal[$year][$month][] = $resource[$i];
    }
    if ($yearSortDir == "DESC") {
        krsort($cal);
    } else {
        ksort($cal);
    }
    foreach ($cal as $year=>$months) {
        if ($monthSortDir == "ASC") {
            ksort($months);
        } else {
            krsort($months);
        }
        $build[$year] = $months;
    }
    
    foreach ($build as $year=>$months) {
        $r_year = \'\';
        $r_month = \'\';
        $r_month_2 = \'\';
        $year_count = 0;
        $items = array();
        
        foreach ($months as $mon=>$month) {
            $month_text = strftime("%B", mktime(10, 10, 10, $mon, 10, $year));
            $month_url = $ditto->buildURL("month=".$mon."&year=".$year."&day=false&start=0",$templatesDocumentID,$id);
            $month_count = count($month);
            $year_count += $month_count;
            $r_month = $ditto->template->replace(array("year"=>$year,"month"=>$month_text,"url"=>$month_url,"count"=>$month_count),$templates[\'month\']);
            if ($showItems) {
                foreach ($month as $item) {
                    $items[$year][$mon][\'items\'][] = $ditto->render($item, $templates[\'item\'], false, $templatesDateSource, $dateFormat, array(),$phx);
                }
                $r_month_2 = $ditto->template->replace(array(\'wrapper\' => implode(\'\',$items[$year][$mon][\'items\'])),$templates[\'month_inner\']);
                $items[$year][$mon] = $ditto->template->replace(array(\'wrapper\' => $r_month_2),$r_month);
            } else {
                $items[$year][$mon] = $r_month;
            }
        }
        if ($groupByYears) {
            $year_url = $ditto->buildURL("year=".$year."&month=false&day=false&start=0",$templatesDocumentID,$id);
            $r_year =  $ditto->template->replace(array("year"=>$year,"url"=>$year_url,"count"=>$year_count),$templates[\'year\']);
            $var = $ditto->template->replace(array(\'wrapper\'=>implode(\'\',$items[$year])),$templates[\'year_inner\']);
            $output .= $ditto->template->replace(array(\'wrapper\'=>$var),$r_year);
        } else {
            $output .= implode(\'\',$items[$year]);
        }
    }

    $output = $ditto->template->replace(array(\'wrapper\'=>$output),$templates[\'tpl\']);
    $modx->setPlaceholder($id.\'reset\',$ditto->buildURL(\'year=false&month=false&day=false\',$templatesDocumentID,$id));

return $output;
    
}
}

return reflect($targetID, $showItems, $groupByYears, $resource, $dateSource, $dateFormat, $ditto, $templates,$id,$start,$yearSortDir,$monthSortDir);';$s['UltimateParent']='return require MODX_BASE_PATH.\'assets/snippets/ultimateparent/snippet.ultimateparent.php\';';$s['Wayfinder']='return require MODX_BASE_PATH.\'assets/snippets/wayfinder/snippet.wayfinder.php\';';$s['WebChangePwd']='# Created By Raymond Irving April, 2005
#::::::::::::::::::::::::::::::::::::::::
# Params:	
#
#	&tpl			- (Optional)
#		Chunk name or document id to use as a template
#				  
#	Note: Templats design:
#			section 1: change pwd template
#			section 2: notification template 
#
# Examples:
#
#	[[WebChangePwd? &tpl=`ChangePwd`]] 

# Set Snippet Paths 
$snipPath  = (($modx->isBackend())? "../":"");
$snipPath .= "assets/snippets/";

# check if inside manager
if ($m = $modx->isBackend()) {
	return \'\'; # don\'t go any further when inside manager
}


# Snippet customize settings
$tpl		= isset($tpl)? $tpl:"";

# System settings
$isPostBack		= count($_POST) && isset($_POST[\'cmdwebchngpwd\']);

# Start processing
include_once $snipPath."weblogin/weblogin.common.inc.php";
include_once $snipPath."weblogin/webchangepwd.inc.php";

# Return
return $output;';$s['WebLogin']='# Created By Raymond Irving 2004
#::::::::::::::::::::::::::::::::::::::::
# Params:	
#
#	&loginhomeid 	- (Optional)
#		redirects the user to first authorized page in the list.
#		If no id was specified then the login home page id or 
#		the current document id will be used
#
#	&logouthomeid 	- (Optional)
#		document id to load when user logs out	
#
#	&pwdreqid 	- (Optional)
#		document id to load after the user has submited
#		a request for a new password
#
#	&pwdactid 	- (Optional)
#		document id to load when the after the user has activated
#		their new password
#
#	&logintext		- (Optional) 
#		Text to be displayed inside login button (for built-in form)
#
#	&logouttext 	- (Optional)
#		Text to be displayed inside logout link (for built-in form)
#	
#	&tpl			- (Optional)
#		Chunk name or document id to as a template
#				  
#	Note: Templats design:
#			section 1: login template
#			section 2: logout template 
#			section 3: password reminder template 
#
#			See weblogin.tpl for more information
#
# Examples:
#
#	[[WebLogin? &loginhomeid=`8` &logouthomeid=`1`]] 
#
#	[[WebLogin? &loginhomeid=`8,18,7,5` &tpl=`Login`]] 

# Set Snippet Paths 
$snipPath = $modx->config[\'base_path\'] . "assets/snippets/";

# check if inside manager
if ($m = $modx->isBackend()) {
	return \'\'; # don\'t go any further when inside manager
}

# deprecated params - only for backward compatibility
if(isset($loginid)) $loginhomeid=$loginid;
if(isset($logoutid)) $logouthomeid = $logoutid;
if(isset($template)) $tpl = $template;

# Snippet customize settings
$liHomeId	= isset($loginhomeid)? array_filter(array_map(\'intval\', explode(\',\', $loginhomeid))):array($modx->config[\'login_home\'],$modx->documentIdentifier);
$loHomeId	= isset($logouthomeid)? $logouthomeid:$modx->documentIdentifier;
$pwdReqId	= isset($pwdreqid)? $pwdreqid:0;
$pwdActId	= isset($pwdactid)? $pwdactid:0;
$loginText	= isset($logintext)? $logintext:\'Login\';
$logoutText	= isset($logouttext)? $logouttext:\'Logout\';
$tpl		= isset($tpl)? $tpl:"";

# System settings
$webLoginMode = isset($_REQUEST[\'webloginmode\'])? $_REQUEST[\'webloginmode\']: \'\';
$isLogOut		= $webLoginMode==\'lo\' ? 1:0;
$isPWDActivate	= $webLoginMode==\'actp\' ? 1:0;
$isPostBack		= count($_POST) && (isset($_POST[\'cmdweblogin\']) || isset($_POST[\'cmdweblogin_x\']));
$txtPwdRem 		= isset($_REQUEST[\'txtpwdrem\'])? $_REQUEST[\'txtpwdrem\']: 0;
$isPWDReminder	= $isPostBack && $txtPwdRem==\'1\' ? 1:0;

$site_id = isset($site_id)? $site_id: \'\';
$cookieKey = substr(md5($site_id."Web-User"),0,15);

# Start processing
include_once $snipPath."weblogin/weblogin.common.inc.php";
include_once ($modx->config[\'site_manager_path\'] . "includes/crypt.class.inc.php");

if ($isPWDActivate || $isPWDReminder || $isLogOut || $isPostBack) {
	# include the logger class
	include_once $modx->config[\'site_manager_path\'] . "includes/log.class.inc.php";
	include_once $snipPath."weblogin/weblogin.processor.inc.php";
}

include_once $snipPath."weblogin/weblogin.inc.php";

# Return
return $output;';$s['WebLoginProps']='&loginhomeid=Login Home Id;string; &logouthomeid=Logout Home Id;string; &logintext=Login Button Text;string; &logouttext=Logout Button Text;string; &tpl=Template;string; ';$s['WebSignup']='# Created By Raymond Irving April, 2005
#::::::::::::::::::::::::::::::::::::::::
# Usage:     
#    Allows a web user to signup for a new web account from the website
#    This snippet provides a basic set of form fields for the signup form
#    You can customize this snippet to create your own signup form
#
# Params:    
#
#    &tpl        - (Optional) Chunk name or document id to use as a template
#	    		   If custom template AND captcha on AND using WebSignup and 
#                  WebLogin on the same page make sure you have a field named
#                  cmdwebsignup. In the default template it is the submit button 
#                  One can use a hidden field.
#    &groups     - Web users groups to be assigned to users
#    &useCaptcha - (Optional) Determine to use (1) or not to use (0) captcha
#                  on signup form - if not defined, will default to system
#                  setting. GD is required for this feature. If GD is not 
#                  available, useCaptcha will automatically be set to false;
#                  
#    Note: Templats design:
#        section 1: signup template
#        section 2: notification template 
#
# Examples:
#
#    [[WebSignup? &tpl=`SignupForm` &groups=`NewsReaders,WebUsers`]] 

# Set Snippet Paths 
$snipPath = $modx->config[\'base_path\'] . "assets/snippets/";

# check if inside manager
if ($m = $modx->isBackend()) {
    return \'\'; # don\'t go any further when inside manager
}


# Snippet customize settings
$tpl = isset($tpl)? $tpl:"";
$useCaptcha = isset($useCaptcha)? $useCaptcha : $modx->config[\'use_captcha\'] ;
// Override captcha if no GD
if ($useCaptcha && !gd_info()) $useCaptcha = 0;

# setup web groups
$groups = isset($groups) ? array_filter(array_map(\'trim\', explode(\',\', $groups))):array();

# System settings
$isPostBack        = count($_POST) && isset($_POST[\'cmdwebsignup\']);

$output = \'\';

# Start processing
include_once $snipPath."weblogin/weblogin.common.inc.php";
include_once $snipPath."weblogin/websignup.inc.php";

# Return
return $output;';$s['WebSignupProps']='&tpl=Template;string; ';$s['YandexMap']='$points= $modx->runSnippet( \'PageContacts\', array( \'array\'=>true ) );
//return print_r($points);
?>
<style>#yandexmap{width:100%;height:500px;}</style>
<script src="//api-maps.yandex.ru/2.1/?lang=ru_RU" type="text/javascript"></script>
<div id="yandexmap"></div>
<script type="text/javascript">
ymaps.ready(init);
var yandexmap;
function init(){
    yandexmap= new ymaps.Map( \'yandexmap\',
        {
            center: [47.23107859368434,39.722849411069355],
            zoom: 11,
        }
    );
	
	yandexmap.geoObjects
	<?php
foreach( $points AS $row )
{
	$info= \'\';
	foreach( $row AS $row2 )
	{
		//if( $row2[\'left\'] == \'Адрес:\' ) $address= $row2[\'left\'] .\' \'. $row2[\'right\'];
		if( $row2[\'type\'] != 7 && $row2[\'type\'] != 8 ) $info .= $row2[\'left\'] .\' \'. $row2[\'right\'] .\'<br />\';
		if( $row2[\'type\'] != 8 ) continue;
		print \'.add(new ymaps.Placemark(\'.$row2[\'right\'].\',{
			balloonContent: "\'.addslashes($info).\'"
		},{
			preset: "islands#dotIcon",
			iconColor: "#18277C"
		}))\';
	}
}
	?>
	;
}
</script>
<?php
//';$s['PageContacts']='//v045
//PageContacts
//07.07.2016
//=====================================================================================
$print .= \'<link rel="stylesheet" type="text/css" href="template/css/pagecontacts.css" />\';
if( $blocks )
{
	$blocks_qq= "";
	$blocks= explode( \',\', $blocks );
	foreach( $blocks AS $row )
	{
		$blocks_qq .= ( ! empty( $blocks_qq ) ? " OR " : "" ) ."block=". intval($row);
	}
}
$rr= mysql_query( "SELECT * FROM ".$modx->getFullTableName( \'page_contacts\' )." ".( $blocks_qq ? "WHERE ".$blocks_qq : "" )." ORDER BY block, `index`" );
if( $rr && mysql_num_rows( $rr ) > 0 )
{
	$block= 0;
	$ii= 0;
	while( $row= mysql_fetch_assoc( $rr ) )
	{
		if( $row[ \'block\' ] && $row[ \'block\' ] != $block )
		{
			if( $onlymain ) break;
			
			$ii++;
			if( $block ) $print .= \'</div>\'; // закрываем предыдущий BLOCK
			$block= $row[ \'block\' ];
			if( $ii%2!=0 ) $print .= \'<div class="clr">&nbsp;</div>\';
			$print .= \'<div class="cont_block cont_block_\'. $block .\' \'.( $ii%2==0 ? \'cont_block_alt\' : \'\' ).\'">\'; // открываем новый BLOCK
		}
		
		if( $onlyblock && ! $block ) continue;
		
		if( $array )
		{
			$result_array[ $row[\'block\'] ][]= $row;
			continue;
		}
		
		if( $row[ \'type\' ] == 7 )
		{
			$print .= \'<div class="cont_img"><a class="highslide" onclick="return hs.expand(this)" href="\'. $row[ \'right\' ] .\'"><img src="\'.$modx->runSnippet( \'ImgCrop6\', array( \'img\'=>$row[ \'right\' ], \'w\'=>90, \'h\'=>90, \'fill\'=>true, \'ellipse\'=>\'max\', \'degstep\'=>15, \'dopimg\'=>\'template/images/kruzhok1.png\', \'dopimg_xy\'=>\'0:0\' ) ).\'" /></a></div>\';
			
		}elseif( $row[ \'type\' ] == 8 ){
			
		}elseif( $row[ \'type\' ] != 3 ){
			$print .= \'<div class="cont_1">\'. $row[ \'left\' ] .\'</div>\';
			
			$print .= \'<div class="cont_2 \'.( $row[ \'br\' ] == \'1\' ? \'cont_br\' : \'\' ).\'" \'.( $row[ \'type\' ] == \'4\' ? \'style="font-size: 24px;"\' : \'\' ).\' \'.( $row[ \'type\' ] == \'6\' ? \'style="font-weight:bold;"\' : \'\' ).\'>\';
			
			if( $row[ \'type\' ] == 1 || $row[ \'type\' ] == 4 || $row[ \'type\' ] == 6 ) $print .= $row[ \'right\' ];
			if( $row[ \'type\' ] == 2 ) $print .= \'<a class="as1 padd2" target="_blank" href="mailto:\'. $row[ \'right\' ] .\'">\'. $row[ \'right\' ] .\'</a>\';
			if( $row[ \'type\' ] == 5 ) $print .= \'<h3>\'. $row[ \'right\' ] .\'</h3>\';
			
			$print .= \'</div><div class="clr">&nbsp;</div>\';
			
		}else{
			$print .= \'<br /><div class="map">\'. $row[ \'right\' ] .\'</div>\';
			if( $row[ \'br\' ] == \'1\' ) $print .= \'<br /><br />\';
		}
	}
	if( $block ) $print .= \'</div><div class="clr">&nbsp;</div>\'; // закрываем последний BLOCK
}
if( $array ) return $result_array;
return $print;';$s['SuperPuperForms']='//SuperPuperForms
//v003
//===============================================================================
/*
&form=`2`
&popup=`1;2`
&class=`className1;className21,className22`
[!SuperPuperForms? &form=`2`!]
[!SuperPuperForms? &popup=`1;2` &class=`className1;className21,className22`!]
*/
//
//
//
//
//
//
//===============================================================================
$js= \'template/js/superpuperforms/superpuperforms.js\'; // Путь к файлу JS
$css= \'template/js/superpuperforms/superpuperforms.css\'; // Путь к файлу CSS
$telefonchik__flag= true; // Прыгающий телефончик
$veriword__flag[ 1 ]= true; // Captcha 1-й формы
$veriword__flag[ 2 ]= true; // Captcha 2-й формы
//===============================================================================
//smtp//mail//default//
$mailtype= \'smtp\';

//КОМУ (через запятую)
$mailto= \'sergey.it7@gmail.com\';

//Видимые копии (через запятую)
$mailcc= false;

//Скрытые копии (через запятую)
$mailbcc= false;

//ОТ (если SMTP, то это поле - логин)
$mailfrom= \'feedback.noreply@yandex.ru\';

//Пароль от почты (если SMTP)
$mailpassw= \'XSbKjp7ZjdoaesD_o_0j\';
//Любимый киногерой: JXosI6J30_Qy_gINenXh //Секретный вопрос от почты

//Сервер SMTP (если SMTP)
$smtp= \'smtp.yandex.ru\';

//Порт SMTP (если SMTP)
$smtpport= 465;

//SNIPPET SuperPuperForms //SNIPPET BasketOrder //MODULE scorn_orders //SNIPPET _LK_Restore_Password //SNIPPET _LK_Reg //MODULE scorn_subscription
//===============================================================================
//
//
//
//
//
//
//
//
//
//
//===============================================================================
include_once( MODX_MANAGER_PATH .\'includes/controls/class.phpmailer.php\' );
$popup= explode( \';\', $popup );
$class= explode( \';\', $class );
if( $popup ) foreach( $popup AS $key => $row ) if( intval( trim( $row ) ) ) $popup_forms[ intval( trim( $row ) ) ]= trim( $class[ $key ] );
$form= intval( trim( $form ) );
if( $form ) $form_flag= true;
//===============================================================================

if( $_GET[ \'act\' ] == \'superpuperforms_captcha\' )
{
	print \'{"result":"ok","text":"template/js/superpuperforms/dmt_captcha/veriword.php?id=\'. addslashes( $_GET[ \'dmtcaptchaid\' ] ) .\'"}\';
	if( isset( $_GET[ \'ajax\' ] ) ){ exit(); }
}
if( $_GET[ \'act\' ] == \'superpuperforms_send\' )
{
	$spfs_formid= intval( $_POST[ \'spfs_formid\' ] );
	$spfs_name= addslashes( trim( $_POST[ \'spfs_name\' ] ) );
	$spfs_email= addslashes( trim( $_POST[ \'spfs_email\' ] ) );
	$spfs_phone= addslashes( trim( $_POST[ \'spfs_phone\' ] ) );
	$spfs_kogda= addslashes( trim( $_POST[ \'spfs_kogda\' ] ) );
	$spfs_pageid= intval( $_POST[ \'spfs_pageid\' ] );
	$spfs_text= addslashes( trim( $_POST[ \'spfs_text\' ] ) );
	$spfs_text2= str_replace( "\\r\\n", "<br />", $spfs_text );
	
	if( $veriword__flag[ $spfs_formid ] && $_POST[ \'spfs_veriword\' ] != $_SESSION[ \'DMTCaptcha\' ][ \'superpuperforms_\'.$spfs_formid ] )
	{
		$result= \'{"result":"error","text":"Введен неверный текст с картинки!"}\';
	}elseif( ! $spfs_email && ! $spfs_phone ){
		$result= \'{"result":"error","text":"Необходимо указать контактные данные!"}\';
	}
	if( ! $result )
	{
		$subject= ( $spfs_formid == 2 ? \'Заказ звонка\' : \'Письмо\' ) ." с сайта www.". $_SERVER[ \'HTTP_HOST\' ];
		
		$message= \'<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><title>\'. $subject .\'</title></head><body><h2>\'. $subject .\'</h2>\';
		
		if( $spfs_pageid ) $message .= \'<p><b>Отправлено со страницы:</b> \'. $modx->makeUrl( $spfs_pageid, \'\', \'\', \'full\' ) .\'</p>\';
		
		if( $spfs_name ) $message .= \'<p><b>Имя Отчество:</b> \'. $spfs_name .\'</p>\';
		
		if( $spfs_email ) $message .= \'<p><b>E-mail:</b> \'. $spfs_email .\'</p>\';
		
		if( $spfs_phone ) $message .= \'<p><b>Контактный телефон:</b> \'. $spfs_phone .\'</p>\';
		
		if( $spfs_kogda ) $message .= \'<p><b>Когда позвонить?</b> \'. $spfs_kogda .\'</p>\';
		
		$message .= \'<p><b>Дата и время сообщения:</b> \'. date( \'d.m.Y - H:i\' ) .\'</p>\';
		
		if( $spfs_text2 ) $message .= \'<p><b>Сообщение:</b><br />\'. $spfs_text2 .\'</p>\';
		
		$message .= \'</body></html>\';

// ============================================================================
					if( $mailtype == \'smtp\' || $mailtype == \'mail\' )
					{
						$phpmailer= new PHPMailer();
						if( false )
						{
							$phpmailer->SMTPDebug= 2;
							$phpmailer->Debugoutput = \'html\';
						}
						if( $mailtype == \'smtp\' )
						{
							$phpmailer->isSMTP();
							$phpmailer->Host= $smtp;
							$phpmailer->Port= $smtpport;
							$phpmailer->SMTPAuth= true;
							$phpmailer->SMTPSecure= \'ssl\';
							$phpmailer->Username= $mailfrom;
							$phpmailer->Password= $mailpassw;
						}
						$phpmailer->CharSet= \'utf-8\';
						$phpmailer->From= $mailfrom;
						$phpmailer->FromName= "";
						$phpmailer->isHTML( true );
						$phpmailer->Subject= $subject;
						$phpmailer->Body= $message;
						$mailto= explode( \',\', $mailto ); foreach( $mailto AS $row ) $phpmailer->addAddress( trim( $row ) );
						if( $mailcc ){ $mailcc= explode( \',\', $mailcc ); foreach( $mailcc AS $row ) $phpmailer->addCC( trim( $row ) ); }
						if( $mailbcc ){ $mailbcc= explode( \',\', $mailbcc ); foreach( $mailbcc AS $row ) $phpmailer->addBCC( trim( $row ) ); }
						$phpmailer_result= $phpmailer->send();
					}else{
						$headers= "Content-type: text/html; charset=utf-8\\n";
						$headers .= "From: <". $mailfrom .">\\n";
						$phpmailer_result= mail( $mailto, $subject, $message, $headers );
					}
// ============================================================================	
		
		if( $phpmailer_result )
		{
			$result= \'{"result":"ok","text":"Сообщение успешно отправлено!<br />С Вами свяжется наш специалист."}\';
		}else{
			$result= \'{"result":"error","text":"Ошибка сервера! Повторите попытку позже."}\';
		}
	}
	print $result;
	if( isset( $_GET[ \'ajax\' ] ) ){ header( \'Content-Type:text/html; charset=UTF-8\' ); exit(); }
}
?>
<link rel="stylesheet" type="text/css" href="<?= $css ?>" />
<script type="text/javascript" src="<?= $js ?>"></script>
<script type="text/javascript">
(function($){$(document).ready(function(){
<?php
	if( ! $form_flag )
	{
		foreach( $popup_forms AS $formId => $className )
		{
			$className= str_replace( \',\', \', .\', $className );
			print \'$( ".\'. $className .\'" ).click(function(){ superpuperforms_show( \'. $formId .\' ); return false; });\';
		}
	}
?>
});})(jQuery);
</script>

<?php if( $telefonchik__flag && ! $form_flag ){ ?>
	<div class="superpuperforms_wrapper superpuperforms_wrapper_krzhk"><div class="spfs_krzhk">&nbsp;</div></div>
<?php } ?>

<div class="superpuperforms_wrapper <?=( ! $form_flag ? \'superpuperforms_wrapper_popup\' : \'superpuperforms_wrapper_default\' )?>">
	<?php if( ! $form_flag ){ ?>
	<div class="spfs_black"><div class="spfs_white"><div class="spfs_krestik"><span>Закрыть</span></div>
	<?php } ?>
	
	<?php if( ( $form_flag && $form == 1 ) || ( ! $form_flag && $popup_forms[ 1 ] ) ){ ?>
		<div class="spfs_formwrapper spfs_formwrapper_1 <?=( ! $form_flag ? \'spfs_formwrapper_popup\' : \'\' )?>" data-formid="1">
			<?=( $form_flag ? \'<div class="spfs_label"> </div>\' : \'\' )?><div class="spfs_tit">Напишите нам</div><div class="clr">&nbsp;</div>
			<div class="spfs_result"></div>
			<form action="<?= $modx->makeUrl( $modx->documentIdentifier ); ?>" method="post">
				<div class="spfs_label">Имя Отчество:</div><div class="spfs_input"><input class="form_elem" type="text" name="spfs_name" /></div>
				<div class="clr">&nbsp;</div>
				<div class="spfs_label"><?=( $form_flag ? \'Адрес электронной почты\' : \'E-mail\' )?>:<div class="zvd">*</div></div><div class="spfs_input"><input class="form_elem" type="text" name="spfs_email" /></div>
				<div class="clr">&nbsp;</div>
				<div class="spfs_label">Номер телефона:<div class="zvd">*</div></div><div class="spfs_input"><input class="form_elem" type="text" name="spfs_phone" /></div>
				<div class="clr">&nbsp;</div>
				<div class="spfs_label">Сообщение:</div><div class="spfs_input">
					<textarea class="form_elem" name="spfs_text"><?php print $mail_text;?></textarea>
				</div>
				<div class="clr">&nbsp;</div>
				<?php if( $veriword__flag[ 1 ] ){ ?>
				<div class="spfs_captcha">
					<div class="spfs_label spfs_br"><img src="template/js/superpuperforms/dmt_captcha/veriword.php?id=superpuperforms_1" /><div class="spfs_change">Изменить число</div><div class="zvd">*</div></div>
					<div class="spfs_input spfs_br">Введите текст с картинки:<br /><input class="form_elem" type="text" name="spfs_veriword" /></div>
					<div class="clr">&nbsp;</div>
				</div>
				<?php } ?>
				<div class="spfs_label"><div class="zvd">*</div></div><div class="spfs_input">- поля обязательные для заполнения!</div>
				<div class="clr">&nbsp;</div>
				<input class="spfs_pageid" type="hidden" name="spfs_pageid" value="[*id*]" />
				<input type="hidden" name="spfs_formid" value="1" />
				<div class="spfs_label"> </div><div class="spfs_input"><button class="spfs_submit" type="button">Отправить сообщение</button></div>
				<div class="clr">&nbsp;</div>
			</form>
		</div>
	<?php } ?>
		
		
		
		
		
	<?php if( ( $form_flag && $form == 2 ) || ( ! $form_flag && $popup_forms[ 2 ] ) ){ ?>
		<div class="spfs_formwrapper spfs_formwrapper_2 <?=( ! $form_flag ? \'spfs_formwrapper_popup\' : \'\' )?>" data-formid="2">
			<?=( $form_flag ? \'<div class="spfs_label"> </div>\' : \'\' )?><div class="spfs_tit">Заказ обратного звонка</div>
			<div class="spfs_result"></div>
			<form action="<?= $modx->makeUrl( $modx->documentIdentifier ); ?>" method="post">
				<div class="spfs_label">Имя Отчество:</div><div class="spfs_input"><input class="form_elem" type="text" name="spfs_name" /></div>
				<div class="clr">&nbsp;</div>
				<div class="spfs_label">Номер телефона:<div class="spfs_txt">с кодом города</div></div><div class="spfs_input"><input class="form_elem" type="text" name="spfs_phone" /></div>
				<div class="clr">&nbsp;</div>
				<div class="spfs_label">Когда позвонить?</div><div class="spfs_input"><input class="form_elem" type="text" name="spfs_kogda" /></div>
				<div class="clr">&nbsp;</div>
				<?php if( $veriword__flag[ 2 ] ){ ?>
				<div class="spfs_captcha">
					<div class="spfs_label spfs_br"><img src="template/js/superpuperforms/dmt_captcha/veriword.php?id=superpuperforms_2" /><div class="spfs_change">Изменить число</div></div>
					<div class="spfs_input spfs_br">Введите текст с картинки:<br /><input class="form_elem" type="text" name="spfs_veriword" /></div>
					<div class="clr">&nbsp;</div>
				</div>
				<?php } ?>
				<input class="spfs_pageid" type="hidden" name="spfs_pageid" value="[~[*id*]~]" />
				<input type="hidden" name="spfs_formid" value="2" />
				<div class="spfs_label"> </div><div class="spfs_input"><button class="spfs_submit" type="button">Отправить заявку</button></div>
				<div class="clr">&nbsp;</div>
			</form>
		</div>
	<?php } ?>
		
	<?php if( ! $form_flag ){ ?>
	</div></div>
	<?php } ?>
</div>
<?php
//
?>';$s['Compress']='$varsion= \'v11\';
//18.06.2016
//Compress
/*	&compress=true/false
	&file - компрессит в filename.compress.css один файл
	&files - компрессит в all.compress.css все указанные файлы
	&tofile - файл, в который комперссить все указанные файлы
	&print=false/true - выводить код, а не путь к файлу
	&r=false/true - принудительно пересоздает компресс-файлы
	&rvars=false/true - замена переменных
	[!Compress? &file=`css/styles.css`!]
	[!Compress? &files=`css: styles.css, catalog.css; css2: shop.css; css3/dop.css` &tofile=`css/all.compress.css`!]
*/
//============================================================================
$strtr[ \'.css\' ]= array(
);
$strtr[ \'.js\' ]= array(
);
$pregreplace[ \'.css\' ][0]= array(
	"/\\/\\*(.*)\\*\\//sU" => "",
	"/[\\s]{2,}/" => " ",
	"/[\\s]*([\\(\\){\\}\\[\\];:])[\\s]*/" => \'${1}\',
	"/[\\s]*([,>])[\\s]*/" => \'${1}\',
	"/([^0-9])0px/" => \'${1}0\',
	"/;\\}/" => \'}\',
);
$pregreplace[ \'.css\' ][1]= array(
);
$pregreplace[ \'.js\' ][0]= array(
	"/\\/\\/(.*)$/mU" => "",
	"/\\/\\*(.*)\\*\\//sU" => "",
);
$pregreplace[ \'.js\' ][1]= array(
	"/[\\s]{2,}/" => " ",
	"/[\\s]*([\\(\\){\\}\\[\\];:])[\\s]*/" => \'${1}\',
	"/[\\s]*([<,:>])[\\s]*/" => \'${1}\',
	"/[\\s]*([=+!\\/-])[\\s]*/" => \'${1}\',
	"/[\\s]*([?|\\*])[\\s]*/" => \'${1}\',
);
//============================================================================
if( true )
{
	$slash= ( substr( ( $file ? $file : $files ), 0, 1 ) == "/" ? false : true );
	$root= rtrim( MODX_BASE_PATH, "/\\\\" ) . ( $slash ? \'/\' : \'\' );
	if( $file )
	{
		$filetype= substr( $file, strrpos( $file, \'.\' ) );
		$file_to= substr( $file, 0, strrpos( $file, \'.\' ) ) .\'.compress\'. $filetype;
		$filesarray[]= $file;
		if( ! file_exists( $root . $file_to ) || filemtime( $root . $file ) > filemtime( $root . $file_to ) ) $refresh= true;
	}else{
		$filetype= substr( $files, strrpos( $files, \'.\' ) );
		$file_to= ( $tofile ? $tofile : \'all.compress\'.$filetype );
		$tmp1= explode( \';\', $files );
		foreach( $tmp1 AS $row1 )
		{
			$tmp2= explode( \':\', trim( $row1 ) );
			if( count( $tmp2 ) == 1 )
			{
				$filepath= trim( $row1 );
				$filesarray[]= $filepath;
				if( ! file_exists( $root . $file_to ) || filemtime( $root . $filepath ) > filemtime( $root . $file_to ) ) $refresh= true;
			}else{
				$tmp3= explode( \',\', $tmp2[ 1 ] );
				foreach( $tmp3 AS $row3 )
				{
					$filepath= $tmp2[ 0 ] . trim( $row3 );
					$filesarray[]= $tmp2[ 0 ] . trim( $row3 );
					if( ! file_exists( $root . $file_to ) || filemtime( $root . $filepath ) > filemtime( $root . $file_to ) ) $refresh= true;
				}
			}
		}
	}
	if( isset( $strtr[ $filetype ] ) ) $strtr_type= $strtr[ $filetype ];
	if( isset( $pregreplace[ $filetype ][0] ) ) $pregreplace_type_0= $pregreplace[ $filetype ][0];
	if( isset( $pregreplace[ $filetype ][1] ) ) $pregreplace_type_1= $pregreplace[ $filetype ][1];
}
//============================================================================
$refresh= ( $refresh || ! empty( $r ) ? true : false );
if( $refresh && $filesarray )
{
	$size_before= 0;
	$file_to_handle= fopen( $root . $file_to, \'w\' );
	if( $files ) fwrite( $file_to_handle, "/*{$files}*/\\n\\n" );
	foreach( $filesarray AS $filerow )
	{
		$size_before += filesize( $root . $filerow );
	}
	foreach( $filesarray AS $filerow )
	{
		$filecontent= "";
		$file_handle= fopen( $root . $filerow, \'r\' );
		if( $file_handle )
		{
			while( ! feof( $file_handle ) ) $filecontent .= fread( $file_handle, 1024*64 );
			fclose( $file_handle );
			if( $filecontent )
			{
				if( $compress !== \'false\' )
				{
					if( $pregreplace_type_0 )
					{
						foreach( $pregreplace_type_0 AS $pattern => $replacement )
							$filecontent= preg_replace( $pattern, $replacement, $filecontent );
					}
					if( $filetype == \'.css\' ) if( $strtr_type ) $filecontent= strtr( $filecontent, $strtr_type );
					
					if( $filetype != \'.css\' )
					{
						$parts= array();
						$kovpos= $curpos= 0;
						$string_flag= false;
						while( true )
						{
							$kov1= ( $string_flag === \'2\' ? false : strpos( $filecontent, "\\"", $curpos+1 ) );
							$kov2= ( $string_flag === \'1\' ? false : strpos( $filecontent, "\'", $curpos+1 ) );
							if( $kov1 === false && $kov2 === false )
							{
								$parts[]= array( substr( $filecontent, $kovpos ).( $string_flag === \'1\' ? "\\"" : ( $string_flag === \'2\' ? "\'" : \'\' ) ), ( $string_flag ? $string_flag : false ) );
								break;
							}else{
								if( $kov1 === false ) $kov1= $kov2 + 1;
								if( $kov2 === false ) $kov2= $kov1 + 1;
								$curpos= ( $kov1 < $kov2 ? $kov1 : $kov2 );
								$ii= 1; $cc= 0;
								if( $string_flag )
								{
									while( substr( $filecontent, $curpos-$ii, 1 ) == "\\\\" )
									{
										$ii++; $cc++;
									}
								}
								$vse_eshe_text= ( $string_flag && $cc%2!=0 ? true : false );
								if( ! $string_flag || ( ! $parts[count($parts)-1][1] && ! $vse_eshe_text ) )
								{
									$parts[]= array( substr( $filecontent, $kovpos+( $string_flag ? 1 : 0 ), $curpos-($kovpos+( $string_flag ? 1 : -1 )) ),
												( $string_flag ? $string_flag : false ) );
									$string_flag= ( $string_flag ? false : ( $kov1 < $kov2 ? \'1\' : \'2\' ) );
									$kovpos= $curpos;
								}
							}
						}
						
						if( $rvars === \'true\' )
						{
							preg_match_all( "/var [a-zA-Z0-9_]+?/U", $filecontent, $matches );
							if( $matches )
							{
								foreach( $matches[0] AS $row )
								{
									$var= str_replace( \'var \', \'\', $row );
									$vars[ $var ]= true;
								}
								foreach( $matches[0] AS $row )
								{
									$var= str_replace( \'var \', \'\', $row );
									do{ $varnum++; }while( $vars[ \'_\'.$varnum ] );
									$pregreplace_type_1[ "/([^a-zA-Z0-9_])(". $var .")([^a-zA-Z0-9_])/U" ]= \'${1}_\'.$varnum.\'${3}\';
								}
							}
						}
						
						$filecontent= \'\';
						if( $parts )
						{
							foreach( $parts AS $part )
							{
								if( ! $part[1] )
								{
									if( $pregreplace_type_1 )
									{
										foreach( $pregreplace_type_1 AS $pattern => $replacement )
											$part[0]= preg_replace( $pattern, $replacement, $part[0] );
									}
									if( $strtr_type ) $part[0]= strtr( $part[0], $strtr_type );
								}
								$filecontent .= $part[0];
							}
						}
					}
				}
				fwrite( $file_to_handle, "/*{$filerow}*/\\n".$filecontent."\\n\\n" );
			}
		}
	}
	$size_after= filesize( $root . $file_to );
	//$md5_after= md5_file( $root . $file_to );
	fwrite( $file_to_handle, "/*Compress {$varsion} - ".round( $size_after * 100 / $size_before )."%".( $md5_after ? " - ".$md5_after : "" )."*/" );
	fclose( $file_to_handle );
}
//============================================================================
if( $print === \'true\' )
{
	$filecontent= \'\';
	$file_to_handle= fopen( $root . $file_to, \'r\' );
	while( ! feof( $file_to_handle ) ) $filecontent .= fread( $file_to_handle, 1024*64 );
	fclose( $file_to_handle );
	return $filecontent;
}else return $file_to;
?>';$s['GenerAlias']='//v02
//GenerAlias
//==================================================================================
$trans = array("а"=>"a", "б"=>"b", "в"=>"v", "г"=>"g", "д"=>"d", "е"=>"e",
        "ё"=>"jo", "ж"=>"zh", "з"=>"z", "и"=>"i", "й"=>"jj", "к"=>"k", "л"=>"l",
        "м"=>"m", "н"=>"n", "о"=>"o", "п"=>"p", "р"=>"r", "с"=>"s", "т"=>"t", "у"=>"u",
        "ф"=>"f", "х"=>"kh", "ц"=>"c", "ч"=>"ch", "ш"=>"sh", "щ"=>"shh", "ы"=>"y",
        "э"=>"eh", "ю"=>"yu", "я"=>"ya", "А"=>"a", "Б"=>"b", "В"=>"v", "Г"=>"g",
        "Д"=>"d", "Е"=>"e", "Ё"=>"jo", "Ж"=>"zh", "З"=>"z", "И"=>"i", "Й"=>"jj",
        "К"=>"k", "Л"=>"l", "М"=>"m", "Н"=>"n", "О"=>"o", "П"=>"p", "Р"=>"r", "С"=>"s",
        "Т"=>"t", "У"=>"u", "Ф"=>"f", "Х"=>"kh", "Ц"=>"c", "Ч"=>"ch", "Ш"=>"sh",
        "Щ"=>"shh", "Ы"=>"y", "Э"=>"eh", "Ю"=>"yu", "Я"=>"ya", " "=>"-", "."=>"-",
        ","=>"-", "_"=>"-", "+"=>"-", ":"=>"-", ";"=>"-", "!"=>"-", "?"=>"-");
		
	$alias= addslashes( $txt );
	$alias= strip_tags( strtr( $alias, $trans ) );
	$alias= preg_replace( \'/&.+?;/\', \'\', $alias );
	$alias= preg_replace( "/[^a-zA-Z0-9-]/", "", $alias );
	$alias= preg_replace( \'/([-]){2,}/\', \'\\1\', $alias );
	$alias= trim( $alias, \'-\' );
	
	if( strlen( $alias ) > 20 )
	{
		$alias= trim( substr( $alias, 0, 20 ), "-" );
	}
	
	do{
		$rr= mysql_query( "SELECT id FROM ". $modx->getFullTableName( \'site_content\' ) ." WHERE alias=\'{$alias}\' LIMIT 1" );
		
		if( $rr && mysql_num_rows( $rr ) == 1 ) $alias .= rand( 1, 9 );
		
	}while( ( $rr && mysql_num_rows( $rr ) == 1 ) || ! $rr );
	
	if( ! $rr ) $alias= false;
	
	return $alias;
?>';$s['GetDoc61']='// 6.1 ver.
//==========================================================================
	
	// idslist - только эти документы
	// slice - срез итогового массива документов - функция array_slice();
	
// id = 1,2,5,255
	// type = this | childs | all
	// depth = 0 | 3 | 1,2,4 : 4-макс.уровень, а 1 и 2 игнорируются
	// fields = \'pagetitle,content\'
	// tvfields = \'image,price\'
	// sort = \'field DESC, field_2 ASC\'
	// tpl = 0 | 10 | 6,-7,8
	// isf
	// param
	// query
	// limit
	// clone - Клонировать в категории (ID TV параметра) значение параметра: ,345,123,56,
	// publ
	// del

// ВЫЧЛЕНЕНИЕ ДОКУМЕНТОВ
	//function getdoc50( $ids=\'0,1\', $type=\'childs\', $depth=0, $fields=\'\', $tvfields=\'\', $sort=\'isfolder DESC, menuindex\', $tpl=0, $isf=\'all\', $param=\'\', $query=\'\', $limit=0, $clone=\'\' )
	//{
	
	$table1= \'site_content\';
	$table2= \'site_tmplvars\';
	$table3= \'site_tmplvar_contentvalues\';
	
	$docs= explode( \',\', $ids );
	
	if( count( $docs ) > 0 )
	{
		$type= ( $type && ( $type == \'this\' || $type == \'all\' ) ? $type : \'childs\' );
		
		if( ! empty( $fields ) )
		{
			$arr_fields= explode( \',\', $fields );
		}
		
		if( ! empty( $tvfields ) )
		{
			$tvfields= explode( \',\', $tvfields );
			$tvfields_flag= true;
			foreach( $tvfields AS $val )
			{
				if( $qq_tvfields != "" ) $qq_tvfields .= " OR ";
				$qq_tvfields .= "tv.`name`=\'{$val}\'";
			}
			if( $qq_tvfields ) $qq_tvfields= "AND ( {$qq_tvfields} )";
		}
			
		if( $tpl )
		{
			$flag_tpl= ( strstr( $tpl, "-" ) ? false : true );
			$tpl= trim( $tpl, "-" );
			$arr_tpl= explode( \',\', $tpl );
			foreach( $arr_tpl AS $key => $val )
			{
				if( $val == 0 )
				{
					$qq_tpl= "";
					break 1;
				}else{
					if( $qq_tpl != \'\' ) $qq_tpl .= ( $flag_tpl ? " OR " : " AND " );
					$qq_tpl .= "template ".( $flag_tpl ? "=" : "<>" )." {$val}";
				}
			}
			if( $qq_tpl ) $qq_tpl= "AND ( {$qq_tpl} )";
		}
		
		if( empty( $isf ) ) $isf= "0";
		if( $isf != \'all\' )
		{
			$qq_isf= "AND isfolder=". ( $isf ? "1" : "0" );
		}
		
		$qq_published= "AND published=";
		if( $publ == \'0\' ) $qq_published .= "0"; else $qq_published .= "1";
		if( $publ == \'all\' ) $qq_published= "";
		
		$qq_deleted= "AND deleted=";
		if( $del == \'1\' ) $qq_deleted .= "1"; else $qq_deleted .= "0";
		if( $del == \'all\' ) $qq_deleted= "";
		
		$query= ( ! empty( $query ) ? "AND ". $query : "" );
		
		if( $type != \'this\' )
		{
			if( $depth )
			{
				$depths= explode( \',\', $depth );
				
				if( count( $depths ) >= 2 )
				{
					$maxlvl= $depths[ count( $depths )-1 ];
					foreach( $depths AS $key => $val ) if( $key != count( $depths )-1 ) $ignore_lvl[ $val ]= true;
					
				}elseif( count( $depths ) == 1 ){
					$maxlvl= $depth;
				}
			}
			if( ! $maxlvl ) $maxlvl= 999;
			
			$qq_sort= ( ! empty( $sort ) ? "ORDER BY ". $sort : "" );
			
			$qq_limit= ( ! empty( $limit ) ? "LIMIT ". $limit : "" );
			
			if( $slice ) $slice= explode( ",", $slice );
		}
		
		
//======================================================
		
		foreach( $docs AS $row )
		{
			if( ! $ignore_lvl[ 0 ] )
			{
				$ids_for_result[ $row ]= array( $row, 0, true );
			}
			$ids_for_check[ $row ]= array( $row, 0, true );
			
			if( $type != \'this\' )
			{
				if( ! empty( $clone ) )
				{
					$rr= mysql_query( "SELECT * FROM ". $modx->getFullTableName( $table3 ) ." WHERE tmplvarid={$clone} AND `value` LIKE \'%,{$row},%\'" );
					if( $rr && mysql_num_rows( $rr ) > 0 )
					{
						while( $cln= mysql_fetch_assoc( $rr ) )
						{
							$clones[ $cln[ \'contentid\' ] ]= $cln[ \'contentid\' ];
						}
					}
				}
			}
		}
		
		$idslist= explode( \',\', $idslist );
		$qq_onlyids= "";
		if( ! empty( $idslist ) )
		{
			foreach( $idslist AS $val )
			{
				if( $val ) $qq_onlyids .= ( $qq_onlyids ? " OR " : "AND ( " ) ."id={$val}";
			}
			if( ! empty( $qq_onlyids ) ) $qq_onlyids .= " )";
		}
		
		if( $type != \'this\' )
		{
			while( count( $ids_for_check ) > 0 )
			{
				$row= array_shift( $ids_for_check );
				$rr= mysql_query( "SELECT id FROM ". $modx->getFullTableName( $table1 ) ." WHERE parent={$row[0]} AND isfolder=1 {$qq_published} {$qq_deleted}" );
				if( $rr && mysql_num_rows( $rr ) > 0 )
				{
					$lvlii= $row[ 1 ] + 1;
					for( $kk=0; $kk<mysql_num_rows( $rr ); $kk++ )
					{
						if( $lvlii <= $maxlvl )
						{
							$ids_for_result[ mysql_result( $rr, $kk, \'id\' ) ]= array( mysql_result( $rr, $kk, \'id\' ), $lvlii );
							$ids_for_check[ mysql_result( $rr, $kk, \'id\' ) ]= array( mysql_result( $rr, $kk, \'id\' ), $lvlii );
						}
					}
				}
			}
		}
		
		if( count( $ids_for_result ) > 0 )
		{
			foreach( $ids_for_result AS $key => $val )
			{
				$lvlii= $val[ 1 ];
				$lvliii= $lvlii + 1;
				
				$tmp1= ( ! $ignore_lvl[ $lvlii ] && $lvlii <= $maxlvl && ( $type != \'childs\' || ! $val[ 2 ] ) ? "id={$key}" : "" );
				$tmp2= ( ! $ignore_lvl[ $lvliii ] && $lvliii <= $maxlvl && ( ! $isf || $isf == \'all\' ) ? ( $tmp1 ? " OR " : "" ) ."parent={$key}" : "" );
				
				if( $tmp1 || $tmp2 )
				{
					if( $qq_ids != \'\' ) $qq_ids .= " OR ";
					$qq_ids .= "( {$tmp1}{$tmp2} )";
				}
			}
		}
		
		if( ! empty( $clones ) )
		{
			foreach( $clones AS $cln )
			{
				$qq_ids .= ( ! empty( $qq_ids ) ? " OR " : "" ) ."( id={$cln} )";
			}
		}
		
		$qq= "SELECT id".( $fields ? ",".$fields : "" )." FROM ". $modx->getFullTableName( $table1 ) ."
			WHERE ( {$qq_ids} ) {$qq_onlyids} {$qq_tpl} {$qq_isf} {$query} {$qq_published} {$qq_deleted}
				{$qq_sort} {$qq_limit}";
		
		$rr= mysql_query( $qq );
		$qq_ids= "";
		if( $rr )
		{
			while( $row= mysql_fetch_assoc( $rr ) )
			{
				$itogo[ $row[ \'id\' ] ]= $row;
				
				if( $tvfields_flag )
				{
					if( $qq_ids != "" ) $qq_ids .= " OR ";
					$qq_ids .= "tvc.contentid={$row[id]}";
				}
			}
		}
		
		if( $tvfields_flag && ! empty( $itogo ) )
		{
			if( $qq_ids ) $qq_ids= "AND ( {$qq_ids} )";
			
			$rr= mysql_query( "SELECT id, name, default_text FROM ". $modx->getFullTableName( $table2 ) ." AS tv WHERE 1=1 {$qq_tvfields}" );
			if( $rr )
			{
				while( $row= mysql_fetch_assoc( $rr ) )
				{
					$tvdefault[ $row[ \'name\' ] ]= $row[ \'default_text\' ];
				}
			}
			
			$rr= mysql_query( "SELECT tv.default_text,tv.`name`,tvc.contentid,tvc.`value` FROM ". $modx->getFullTableName( $table2 ) ." AS tv, ". $modx->getFullTableName( $table3 ) ." AS tvc
				WHERE tv.id=tvc.tmplvarid {$qq_tvfields} {$qq_ids} ORDER BY tv.id" );
			if( $rr )
			{
				while( $row= mysql_fetch_assoc( $rr ) )
				{
					$itogo[ $row[ \'contentid\' ] ][ $row[ \'name\' ] ]= $row[ \'value\' ];
				}
			}
			
			foreach( $itogo AS $key => $val )
			{
				foreach( $tvfields AS $key2 => $val2 )
				{
					if( ! isset( $val[ $val2 ] ) || empty( $val[ $val2 ] ) )
						$itogo[ $key ][ $val2 ]= $tvdefault[ $val2 ];
				}
			}
		}
		
		if( $slice )
		{
			$itogo= array_slice( $itogo, $slice[ 0 ], ( $slice[ 1 ] ? $slice[ 1 ] : null ) );
		}
	}
	
	return $itogo;
//}


	// СОРТИРОВКА ПО TV-параметрам
	/*if( $docs2 )
	{
		foreach( $docs2 AS $row )
		{
			$tmp= intval( $row[ \'price\' ] );
			$tmp= str_pad( $tmp, 10, \'0\', STR_PAD_LEFT );
			$sortirovka[ $tmp .\'__\'. $row[ \'pagetitle\' ] .\'__\'. $row[ \'id\' ] ]= $row;
		}
		ksort( $sortirovka );
		$docs2= array_slice( $sortirovka, $page_s, $MaxItemsInPage );
	}*/
	// СОРТИРОВКА ПО TV-параметрам
?>';$s['GetIdOnLvl']='//v005
//GetIdOnLvl
//================== Список ИД всех родителей ====================
$doc= $modx->getDocument( $id, \'id,parent\'.( $fields ? \',\' : \'\' ).$fields );

$list[]= $doc;

while( $id != $koren && $doc[ \'parent\' ] != $koren && $doc[ \'parent\' ] != 0 )
{
	$doc= $modx->getDocument( $doc[ \'parent\' ], \'id,parent\'.( $fields ? \',\' : \'\' ).$fields );
	$list[]= $doc;
}

if( $doc[ \'parent\' ] == 0 )
{
	$list[]= array( \'id\'=>0 );
}elseif( $doc[ \'parent\' ] == $koren ){
	$doc= $modx->getDocument( $doc[ \'parent\' ], \'id,parent\'.( $fields ? \',\' : \'\' ).$fields );
	$list[]= $doc;
}

$list[]= false;
$list= array_reverse( $list );

return ( $lvl ? $list[ $lvl ][ ( $prm ? $prm : \'id\' ) ] : $list );
//====================================================================
?>';$s['GetLvl']='//v002
//GetLvl
//================== Определение уровня вложенности ====================
	if( $id == $koren )
	{
		print \'1\';
	
	}else{
		$lvl= 2;
		$doc= $modx->getDocument( $id, \'parent\' );
		
		while( $doc[ \'parent\' ] != $koren && $doc[ \'parent\' ] != 0 )
		{
			$lvl++;
			$doc= $modx->getDocument( $doc[ \'parent\' ], \'parent\' );
		}
		
		if( $koren != 0 && $doc[ \'parent\' ] == 0 )
		{
			print \'0\';
		}else{
			print $lvl;	
		}
	}
//====================================================================
?>';$s['ImgCrop71']='// v71
// 14.07.2016
// ImgCrop
/*
	$img= assets/images/img.jpg
	$w= (int)156
	$h= (int)122
	$backgr= 0/1
	$fill= 0/1
	$x= center/left/right
	$y= center/top/bottom
	$bgcolor= R,G,B,A / x:y / fill:a;b;c;d|b;c;d
	$wm= 0/1
	$filter= a;b;c;d|b;c;d
	$png= 0/1
	$r= 0/1
	$ellipse= max / (int)56
	$degstep= (int)5
	$dopimg= assets/images/dopimg.jpg
	$dopimg_xy= x:y
	$toimg= assets/images/toimg.jpg
	$quality= (int)80
*/
//==========================================================================================
	$ipathnotphoto= \'template/images/notphoto.png\'; // БЕЗ СЛЕША В НАЧАЛЕ
	$ipathwatermark= \'template/images/watermark.png\'; // БЕЗ СЛЕША В НАЧАЛЕ // ТОЛЬКО .PNG













//==========================================================================================
	
	$img= urldecode( $img );
	$w= ( empty( $w ) ? 0 : intval($w) );
	$h= ( empty( $h ) ? 0 : intval($h) );
	$backgr= ( empty( $backgr ) ? false : $backgr );
	$fill= ( empty( $fill ) ? false : $fill );
	$x= ( empty( $x ) ? \'center\' : $x );
	$y= ( empty( $y ) ? \'center\' : $y );
	$bgcolor= ( empty( $bgcolor ) ? \'255,255,255,127\' : $bgcolor );
	$wm= ( empty( $wm ) ? false : $wm );
	$png= ( empty( $png ) ? false : $png );
	$filter= ( empty( $filter ) ? -1 : $filter );
	$refresh= ( empty( $r ) ? false : true );
	$slash= ( substr( $img, 0, 1 ) != DIRECTORY_SEPARATOR ? true : false );
	$root= rtrim( MODX_BASE_PATH, "/\\\\" ) . ( $slash ? DIRECTORY_SEPARATOR : \'\' );
	$img= trim( $img );
	
	$ipathnotphoto= ( $slash ? \'\' : DIRECTORY_SEPARATOR ) . $ipathnotphoto;
	$ipathwatermark= ( $slash ? \'\' : DIRECTORY_SEPARATOR ) . $ipathwatermark;

	$quality= intval( $quality );
	$quality= ( empty($quality) || $quality < 0 || $quality > 100 ? 80 : $quality );

	$ellipse= ( $ellipse == \'max\' ? \'max\' : intval( $ellipse ) );

	if( $dopimg )
	{
		$dopimg= trim( urldecode( $dopimg ) );
		$dopimg= ltrim( $dopimg, "/\\\\" );
		$dopimg= $root . ( $slash ? \'\' : DIRECTORY_SEPARATOR ) . $dopimg;
	}
	if( $toimg )
	{
		$toimg= trim( urldecode( $toimg ) );
		$toimg= ltrim( $toimg, "/\\\\" );
		$toimg= ( $slash ? \'\' : DIRECTORY_SEPARATOR ) . $toimg;
	}
	
	if( ! file_exists( $root . $img ) || ! is_file( $root . $img ) )
	{
		$img= $ipathnotphoto;
		if( $fill ){ $fill= false; $backgr= true; $bgcolor= \'1:1\'; }
	}
	if( ! file_exists( $root . $img ) || ! is_file( $root . $img ) ) return false;
	if( $wm && ( ! file_exists( $root . $ipathwatermark ) || ! is_file( $root . $ipathwatermark ) ) )
	{
		$wm= false;
		$img= $ipathnotphoto;
	}

	if( ! $toimg )
	{
		$imgrassh= substr( $img, strrpos( $img, \'.\' ) );
		$newimg= \'_th\'. md5( $img . $w . $h . $backgr . $fill . $x . $y . $bgcolor . $wm . $filter . $ellipse . $dopimg . $quality ) . ( $png ? \'.png\' : $imgrassh );
		
		$imgarr= explode( DIRECTORY_SEPARATOR, $img );
		unset( $imgarr[ count( $imgarr )-1 ] );
		foreach( $imgarr AS $val )
		{
			$newimg_dir .= $val . DIRECTORY_SEPARATOR;
		}
		$newimg_dir .= \'.th\'. DIRECTORY_SEPARATOR;
		if( ! file_exists( $root . $newimg_dir ) ) mkdir( $root . $newimg_dir, 0777 );
		
		$newimg_path= $root . $newimg_dir . $newimg;
		$newimg_path_return= ( $fullpath ? MODX_SITE_URL : \'\' ) . $newimg_dir . $newimg;
		
	}else{
		$newimg_path= $toimg;
		$newimg_path_return= ( $fullpath ? MODX_SITE_URL : \'\' ) . $toimg;
	}
	if( ! file_exists( $newimg_path ) || filemtime( $root . $img ) > filemtime( $newimg_path ) ) $refresh= true;
	if( filesize( $root . $img ) > 1024*1024*10 ) return $img;
// ======================================================

	if( $refresh )
	{
		$img1_info= getimagesize( $root . $img );
		if( ! $img1_info[ 1 ] ) return false;
		$ot= $img1_info[ 0 ] / $img1_info[ 1 ];
		$dstW= ( $w > 0 ? $w : $img1_info[ 0 ] );
		$dstH= ( $h > 0 ? $h : $img1_info[ 1 ] );
		$dstX= 0;
		$dstY= 0;
		$srcW= $img1_info[ 0 ];
		$srcH= $img1_info[ 1 ];
		$srcX= 0;
		$srcY= 0;
		if( $fill )
		{
			$srcW= $img1_info[ 0 ];
			$srcH= round( $img1_info[ 0 ] / ( $dstW / $dstH ) );
			if( $srcH > $img1_info[ 1 ] )
			{
				$srcW= round( $img1_info[ 1 ] / ( $dstH / $dstW ) );
				$srcH= $img1_info[ 1 ];
			}
			if( $x == \'center\' ) $srcX= round( ( $img1_info[ 0 ] - $srcW ) / 2 );
			if( $x == \'right\' ) $srcX= $img1_info[ 0 ] - $srcW;
			if( $y == \'center\' ) $srcY= round( ( $img1_info[ 1 ] - $srcH ) / 2 );
			if( $y == \'bottom\' ) $srcY= $img1_info[ 1 ] - $srcH;
		}else{
			if( ( $img1_info[ 0 ] > $w && $w > 0 ) || ( $img1_info[ 1 ] > $h && $h > 0 ) )
			{
				$dstH= round( $dstW / $ot );
				
				if( $dstH > $h && $h > 0 )
				{
					$dstH= $h;
					$dstW= round( $dstH * $ot );
				}
			}else{
				$dstW= $img1_info[ 0 ];
				$dstH= $img1_info[ 1 ];
			}
			if( $backgr )
			{
				if( $dstW < $w )
				{
					if( $x == \'center\' ) $dstX= round( ( $w - $dstW ) / 2 );
					if( $x == \'right\' ) $dstX= $w - $dstW;
				}
				if( $dstH < $h )
				{
					if( $y == \'center\' ) $dstY= round( ( $h - $dstH ) / 2 );
					if( $y == \'bottom\' ) $dstY= $h - $dstH;
				}
			}
		}
		$crW= ( $backgr && $w > 0 ? $w : $dstW );
		$crH= ( $backgr && $h > 0 ? $h : $dstH );
		if( strstr( $bgcolor, "," ) )
		{
			$rgba_arr= explode( ",", $bgcolor );
			for( $kk=0; $kk<=3; $kk++ )
			{
				$rgba_arr[ $kk ]= intval( $rgba_arr[ $kk ] );
				if( $kk <= 2 && ( $rgba_arr[ $kk ] < 0 || $rgba_arr[ $kk ] > 255 ) ) $rgba_arr[ $kk ]= 255;
				if( $kk == 3 && ( $rgba_arr[ $kk ] < 0 || $rgba_arr[ $kk ] > 127 ) ) $rgba_arr[ $kk ]= 127;
			}
			$bgcolor= \'rgba\';
		}elseif( strpos( $bgcolor, \'fill:\' ) === 0 ){
			$effect= substr( $bgcolor, strpos( $bgcolor, \':\' )+1 );
			$bgcolor= \'fill\';
		}else{
			$coord_arr= explode( ":", $bgcolor );
			$bgcolor= \'coord\';
		}
//========================================================================================
		
		if( $img1_info[ 2 ] == 1 ) $img1= imagecreatefromgif( $root . $img );
			
		elseif( $img1_info[ 2 ] == 2 ) $img1= imagecreatefromjpeg( $root . $img );
			
		elseif( $img1_info[ 2 ] == 3 ){
			$img1= imagecreatefrompng( $root . $img );
			$png= true;
		}
		
		if( $bgcolor == \'coord\' )
		{
			$col= imagecolorat( $img1, $coord_arr[ 0 ], $coord_arr[ 1 ] );
			$bgcolor= imagecolorsforindex( $img1, $col );
			$rgba_arr[ 0 ]= $bgcolor[ \'red\' ];
			$rgba_arr[ 1 ]= $bgcolor[ \'green\' ];
			$rgba_arr[ 2 ]= $bgcolor[ \'blue\' ];
			$rgba_arr[ 3 ]= $bgcolor[ \'alpha\' ];
		}
		
		$img2= ImageCreateTrueColor( $crW, $crH );
		
		if( $png )
		{
			imagealphablending( $img2, true );
			imagesavealpha( $img2, true );
			$col= imagecolorallocatealpha( $img2, $rgba_arr[ 0 ], $rgba_arr[ 1 ], $rgba_arr[ 2 ], $rgba_arr[ 3 ] );
		}else{
			$col= imagecolorallocate( $img2, $rgba_arr[ 0 ], $rgba_arr[ 1 ], $rgba_arr[ 2 ] );
		}
		
		if( $bgcolor == \'fill\' )
		{
			imagecopyresampled( $img2, $img1, 0, 0, 0, 0, $crW, $crH, $img1_info[0], $img1_info[1] );
			$effect= explode( \'|\', $effect );
			if( ! empty( $effect ) )
			{
				foreach( $effect AS $row )
				{
					$tmp= explode( \';\', $row );
					if( $tmp[ 0 ] == 2 || $tmp[ 0 ] == 3 || $tmp[ 0 ] == 10 ) imagefilter( $img2, $tmp[ 0 ], $tmp[ 1 ] );
					elseif( $tmp[ 0 ] == 4 ) imagefilter( $img2, $tmp[ 0 ], $tmp[ 1 ], $tmp[ 2 ], $tmp[ 3 ], $tmp[ 4 ] );
					elseif( $tmp[ 0 ] == 11 ) imagefilter( $img2, $tmp[ 0 ], $tmp[ 1 ], $tmp[ 2 ] );
					else imagefilter( $img2, $tmp[ 0 ] );
				}
			}
		}else{
			imagefill( $img2, 0,0, $col );
		}
		
		imagecopyresampled( $img2, $img1, $dstX, $dstY, $srcX, $srcY, $dstW, $dstH, $srcW, $srcH );
		
		if( $wm )
		{
			$wm_info= getimagesize( $root . $ipathwatermark );
			$img3= imagecreatefrompng( $root . $ipathwatermark );
			$wm_ot= $wm_info[ 0 ] / $wm_info[ 1 ];
			$wmW= $wm_info[ 0 ];
			$wmH= $wm_info[ 1 ];
			if( $crW < $wm_info[ 0 ] )
			{
				$wmW= $crW - round( $crW / 30 );
				$wmH= round( $wmW / $wm_ot );
			}
			if( $crH < $wmH )
			{
				$wmH= $crH - round( $crH / 30 );
				$wmW= round( $wmH * $wm_ot );
			}
			$wmX= round( ( $crW - $wmW ) / 2 );
			$wmY= round( ( $crH - $wmH ) / 2 );
			imagecopyresampled( $img2, $img3, $wmX, $wmY, 0, 0, $wmW, $wmH, $wm_info[ 0 ], $wm_info[ 1 ] );
			imagedestroy( $img3 );
		}
		
		$filter= explode( \'|\', $filter );
		if( ! empty( $filter ) )
		{
			foreach( $filter AS $row )
			{
				$tmp= explode( \';\', $row );
				if( $tmp[ 0 ] == 2 || $tmp[ 0 ] == 3 || $tmp[ 0 ] == 10 ) imagefilter( $img2, $tmp[ 0 ], $tmp[ 1 ] );
				elseif( $tmp[ 0 ] == 4 ) imagefilter( $img2, $tmp[ 0 ], $tmp[ 1 ], $tmp[ 2 ], $tmp[ 3 ], $tmp[ 4 ] );
				elseif( $tmp[ 0 ] == 11 ) imagefilter( $img2, $tmp[ 0 ], $tmp[ 1 ], $tmp[ 2 ] );
				else imagefilter( $img2, $tmp[ 0 ] );
			}
		}
		
		if( $ellipse )
		{
			$degstep= ( $degstep ? intval( $degstep ) : 5 );
			$w= ( $crW > $crH ? $crH : $crW );
			$cntr= ($w/2);
			$coord= array();
			$opacitycolor= imagecolorallocatealpha( $img2, 255, 255, 255, 127 );
			if( $ellipse == \'max\' ) $ellipse_r= $cntr-1; else $ellipse_r= $ellipse;
			for( $part=1; $part<=4; $part++ )
			{
				for( $deg=0; $deg<90; $deg+=$degstep )
				{
					$mydeg= $deg;
					if( $part == 2 || $part == 4 ) $mydeg= 90 - $deg;
					if( ! $coord[ $mydeg ][ \'x\' ] ) $coord[ $mydeg ][ \'x\' ]= round( $ellipse_r * cos( deg2rad( $mydeg ) ) );
					if( ! $coord[ $mydeg ][ \'y\' ] ) $coord[ $mydeg ][ \'y\' ]= round( $ellipse_r * sin( deg2rad( $mydeg ) ) );
					$x= $coord[ $mydeg ][ \'x\' ];
					$y= $coord[ $mydeg ][ \'y\' ];
					if( $part == 4 ){ $y *= -1; }
					if( $part == 3 ){ $x *= -1; $y *= -1; }
					if( $part == 2 ){ $x *= -1; }
					$points[]= $cntr + $x;
					$points[]= $cntr + $y;
				}
			}
			$points[]= $cntr + $ellipse_r; $points[]= $cntr;
			$points[]= $w; $points[]= $cntr;
			$points[]= $w; $points[]= $w;
			$points[]= 0; $points[]= $w;
			$points[]= 0; $points[]= 0;
			$points[]= $w; $points[]= 0;
			$points[]= $w; $points[]= $cntr;
			$png= true;
			imagealphablending( $img2, false );
			imagesavealpha( $img2, true );
			imagefilledpolygon( $img2, $points, count($points)/2, $opacitycolor );
			//$autrum= imagecolorallocate( $img2, 216, 181, 85 );
			//imageellipse( $img2, $cntr, $cntr, $ellipse_r*2, $ellipse_r*2, $autrum );
		}
		
		if( $dopimg )
		{
			if( $dopimg_xy )
			{
				$dopimg_xy= explode( ":", $dopimg_xy );	
			}
			imagealphablending( $img2, true );
			imagesavealpha( $img2, true );
			$dopimg_info= getimagesize( $dopimg );
			$img3= imagecreatefrompng( $dopimg );
			$diX= round( ( $crW - $dopimg_info[ 0 ] ) / 2 ) + ( $dopimg_xy[ 0 ] ? intval( $dopimg_xy[ 0 ] ) : 0 );
			$diY= round( ( $crH - $dopimg_info[ 1 ] ) / 2 ) + ( $dopimg_xy[ 1 ] ? intval( $dopimg_xy[ 1 ] ) : 0 );
			imagecopyresampled( $img2, $img3, $diX, $diY, 0, 0, $dopimg_info[ 0 ], $dopimg_info[ 1 ], $dopimg_info[ 0 ], $dopimg_info[ 1 ] );
			imagedestroy( $img3 );
		}
		
		if( $png ){
			imagepng( $img2, $newimg_path );
		}elseif( $img1_info[ 2 ] == 1 ){
			imagegif( $img2, $newimg_path, $quality );
		}elseif( $img1_info[ 2 ] == 2 ){
			imagejpeg( $img2, $newimg_path, $quality );
		}
		chmod( $newimg_path, 0777 );
		imagedestroy( $img1 );
		imagedestroy( $img2 );
	}

	return $newimg_path_return;
?>';$s['Date']='$array= array(
	\'m2\' => array(
		\'01\' => \'января\', \'02\' => \'февраля\', \'03\' => \'марта\', \'04\' => \'апреля\',
		\'05\' => \'мая\', \'06\' => \'июня\', \'07\' => \'июля\', \'08\' => \'августа\',
		\'09\' => \'сентября\', \'10\' => \'октября\', \'11\' => \'ноября\', \'12\' => \'декабря\'
	)
);
if( ! empty( $array[ $ff ] ) ) return $array[ $ff ][ date( ( ! empty( $f ) ? $f : \'d.m.Y\' ), ( ! empty( $d ) ? $d : time() ) ) ];
return date( ( ! empty( $f ) ? $f : \'d.m.Y\' ), ( ! empty( $d ) ? $d : time() ) );';$s['WayfinderScorn']='if(!defined(\'MODX_BASE_PATH\')){die(\'What are you doing? Get out of here!\');}
/*
::::::::::::::::::::::::::::::::::::::::
 Snippet name: Wayfinder
 Short Desc: builds site navigation
 Version: 2.0.1
 Authors: 
	Kyle Jaebker (muddydogpaws.com)
	Ryan Thrash (vertexworks.com)
 Date: February 27, 2006
::::::::::::::::::::::::::::::::::::::::
Description:
    Totally refactored from original DropMenu nav builder to make it easier to
    create custom navigation by using chunks as output templates. By using templates,
    many of the paramaters are no longer needed for flexible output including tables,
    unordered- or ordered-lists (ULs or OLs), definition lists (DLs) or in any other
    format you desire.
::::::::::::::::::::::::::::::::::::::::
Example Usage:
    [[Wayfinder? &startId=`0`]]
::::::::::::::::::::::::::::::::::::::::
*/

$wayfinder_sc_base = $modx->config[\'base_path\']."assets/snippets/wayfinder_scorn/";

//Include a custom config file if specified
$config = (isset($config)) ? "{$wayfinder_sc_base}configs/{$config}.config.php" : "{$wayfinder_sc_base}configs/default.config.php";
if (file_exists($config)) {
	include("$config");
}

include_once("{$wayfinder_sc_base}wayfinder.inc.php");

if (class_exists(\'ScornWayfinder\')) {
   $wf = new ScornWayfinder();
} else {
    return \'error: Wayfinder class not found\';
}

$wf->_config = array(
	\'id\' => isset($startId) ? $startId : $modx->documentIdentifier,
	\'level\' => isset($level) ? $level : 0,
	\'includeDocs\' => isset($includeDocs) ? $includeDocs : 0,
	\'excludeDocs\' => isset($excludeDocs) ? $excludeDocs : 0,
	\'ph\' => isset($ph) ? $ph : FALSE,
	\'debug\' => isset($debug) ? TRUE : FALSE,
	\'ignoreHidden\' => isset($ignoreHidden) ? $ignoreHidden : FALSE,
	\'hideSubMenus\' => isset($hideSubMenus) ? $hideSubMenus : FALSE,
	\'useWeblinkUrl\' => isset($useWeblinkUrl) ? $useWeblinkUrl : TRUE,
	\'fullLink\' => isset($fullLink) ? $fullLink : FALSE,
	\'nl\' => isset($removeNewLines) ? \'\' : "\\n",
	\'sortOrder\' => isset($sortOrder) ? strtoupper($sortOrder) : \'ASC\',
	\'sortBy\' => isset($sortBy) ? $sortBy : \'menuindex\',
	\'limit\' => isset($limit) ? $limit : 0,
	\'cssTpl\' => isset($cssTpl) ? $cssTpl : FALSE,
	\'jsTpl\' => isset($jsTpl) ? $jsTpl : FALSE,
	\'rowIdPrefix\' => isset($rowIdPrefix) ? $rowIdPrefix : FALSE,
	\'textOfLinks\' => isset($textOfLinks) ? $textOfLinks : \'menutitle\',
	\'titleOfLinks\' => isset($titleOfLinks) ? $titleOfLinks : \'pagetitle\',
	\'displayStart\' => isset($displayStart) ? $displayStart : FALSE,
	\'entityEncode\' => isset($entityEncode) ? $entityEncode : TRUE,
	
	\'prefFC\' => isset($prefClass) ? $prefClass : \'\',
	\'only\' => $onlyThis == \'folders\' ? \'folders\' : FALSE,
	\'onlyStart\' => isset($onlyThisStart) ? $onlyThisStart : FALSE,
	\'onlyForReg\' => isset($onlyForReg) ? $onlyForReg : FALSE,
);

//get user class definitions
$wf->_css = array(
	\'first\' => isset($firstClass) ? $prefClass . $firstClass : \'\',
	\'last\' => isset($lastClass) ? $prefClass . $lastClass : $prefClass . \'last\',
	\'here\' => isset($hereClass) ? $prefClass . $hereClass : $prefClass . \'active\',
	\'parent\' => isset($parentClass) ? $prefClass . $parentClass : \'\',
	\'row\' => isset($rowClass) ? $prefClass . $rowClass : \'\',
	\'outer\' => isset($outerClass) ? $prefClass . $outerClass : \'\',
	\'inner\' => isset($innerClass) ? $prefClass . $innerClass : \'\',
	\'level\' => isset($levelClass) ? $prefClass . $levelClass: \'\',
	\'self\' => isset($selfClass) ? $prefClass . $selfClass : $prefClass . \'iam\',
	\'weblink\' => isset($webLinkClass) ? $prefClass . $webLinkClass : \'\',
	
	\'open\' => isset($openClass) ? $prefClass . $openClass : $prefClass . \'open\',
	\'empty\' => isset($emptyClass) ? $prefClass . $emptyClass : $prefClass . \'empty\',
	\'link\' => isset($linkClass) ? $linkClass : \'\',
);

//get user templates
$wf->_templates = array(
	\'outerTpl\' => isset($outerTpl) ? $outerTpl : \'\',
	\'rowTpl\' => isset($rowTpl) ? $rowTpl : \'\',
	\'parentRowTpl\' => isset($parentRowTpl) ? $parentRowTpl : \'\',
	\'parentRowHereTpl\' => isset($parentRowHereTpl) ? $parentRowHereTpl : \'\',
	\'hereTpl\' => isset($hereTpl) ? $hereTpl : \'\',
	\'innerTpl\' => isset($innerTpl) ? $innerTpl : \'\',
	\'innerRowTpl\' => isset($innerRowTpl) ? $innerRowTpl : \'\',
	\'innerHereTpl\' => isset($innerHereTpl) ? $innerHereTpl : \'\',
	\'activeParentRowTpl\' => isset($activeParentRowTpl) ? $activeParentRowTpl : \'\',
	\'categoryFoldersTpl\' => isset($categoryFoldersTpl) ? $categoryFoldersTpl : \'\',
	\'startItemTpl\' => isset($startItemTpl) ? $startItemTpl : \'\',
);

//Process Wayfinder
$output = $wf->run();

if ($wf->_config[\'debug\']) {
	$output .= $wf->renderDebugOutput();
}

//Ouput Results
if ($wf->_config[\'ph\']) {
    $modx->setPlaceholder($wf->_config[\'ph\'],$output);
    return;
} else {
    return $output;
}';$s['AJAX']='$id= intval( $_GET[ \'id\' ] );
$count= intval( $_GET[ \'count\' ] );

if( $_GET[ \'act\' ] == \'add\' )
{
	$modx->runSnippet( \'BasketAction\', array( \'act\' => $_GET[ \'act\' ], \'id\' => $id, \'count\' => $count ) );
	
	
}elseif( $_GET[ \'act\' ] == \'head_basket_refr\'  ){
	return $modx->runSnippet( \'TopBasket\', array( \'type\' => \'info\' ) );
	
	
}elseif( $_GET[ \'act\' ] == \'del\' || $_GET[ \'act\' ] == \'recount\' ){
	$modx->runSnippet( \'BasketAction\', array( \'act\' => $_GET[ \'act\' ], \'id\' => $id, \'count\' => $count ) );
	return $modx->runSnippet( \'BasketPage\', array( \'OrderForm\' => false, \'AjaxAction\' => true ) );
	
	
}elseif( $_GET[ \'act\' ] == \'refr\'  ){
	return $modx->runSnippet( \'BasketPage\', array( \'OrderForm\' => false, \'AjaxAction\' => true ) );
}';$s['BasketAction']='$id= intval( $id );
$count= intval( $count );
if( ! isset( $count ) || empty( $count ) || $count == \'\' || $count <= 0 || $count > 999999 ) $count= 1;

$table= $modx->getFullTableName( \'_shop_basket\' );

$webuserinfo= $_SESSION[ \'webuserinfo\' ];
if( $webuserinfo[ \'auth\' ] )
{
	$user= "user=\'{$webuserinfo[id]}\'";
}else{
	$session_id= \'ses\'. session_id();
	$user= "idsession=\'{$session_id}\'";
}

if( $act == \'recount\' || $act == \'add\' )
{
	//$maxcc= $modx->runSnippet( \'GetDoc3\', array( \'ids\' => $id, \'type\' => \'this\', \'tvfileds\' => \'amount\' ) );
	//$maxcc[ $id ][ \'amount\' ]= intval( $maxcc[ $id ][ \'amount\' ] );
	//if( $count > $maxcc[ $id ][ \'amount\' ] ) $count= $maxcc[ $id ][ \'amount\' ];
}

	if( $act == \'stat\' )
	{
		$rr= mysql_query( "SELECT id FROM {$table} WHERE {$user} AND itemid={$id} LIMIT 1" );
		if( $rr && mysql_num_rows( $rr ) == 1 )
		{
			return \'nedel\';
		}else{
			return \'netu\';
		}
		
		
	}elseif( $act == \'pos\' ){
		$rr= mysql_query( "SELECT id FROM {$table} WHERE {$user} AND itemid={$id} LIMIT 1" );
		if( $rr && mysql_num_rows( $rr ) == 1 )
		{
			return mysql_result( $rr, 0, \'id\' );
		}else{
			return false;
		}
		
		
	}elseif( $act == \'add\' && $id > 0 ){
		$stat= $modx->runSnippet( \'BasketAction\', array( \'act\' => \'stat\', \'id\' => $id ) );
		if( $stat == \'netu\' )
		{
			mysql_query( "INSERT INTO {$table} SET {$user}, itemid={$id}, `count`={$count}, dth=\'".date(\'Y-m-d-H-i-s\')."\', dt=".time() );
			
		}elseif( $stat == \'nedel\' ){
			mysql_query( "UPDATE {$table} SET `count`={$count} WHERE {$user} AND itemid={$id} LIMIT 1" );
		}
		
		
	}elseif( $act == \'del\' ){
		mysql_query( "DELETE FROM {$table} WHERE {$user} AND id={$id} LIMIT 1" );
		
		
	}elseif( $act == \'del_all\' ){
		mysql_query( "DELETE FROM {$table} WHERE {$user}" );
		
		
	}elseif( $act == \'item_count\' ){
		$rr= mysql_query( "SELECT `count` FROM {$table} WHERE {$user} AND id={$id} LIMIT 1" );
		if( $rr && mysql_num_rows( $rr ) == 1 )
		{
			return mysql_result( $rr, 0, \'count\' );
		}else{
			return 0;
		}
		
		
	}elseif( $act == \'recount\' ){
		mysql_query( "UPDATE {$table} SET `count`={$count} WHERE {$user} AND id={$id} LIMIT 1" );
		
		
		
		
	}elseif( $act == \'all_list\' ){
		$rr= mysql_query( "SELECT id FROM {$table} WHERE {$user}" );
		if( $rr && mysql_num_rows( $rr ) > 0 )
		{
			while( $row= mysql_fetch_assoc( $rr ) )
			{
				if( ! empty( $basket_doci ) ) $basket_doci .= \',\';
				$basket_doci .= $row[ \'id\' ];
			}
		}
		
		return $basket_doci;
		
		
	}elseif( $act == \'count_items\' ){
		$rr= mysql_query( "SELECT id FROM {$table} WHERE {$user}" );
		if( $rr )
		{
			return mysql_num_rows( $rr );
		}else{
			return 0;
		}
		
		
	}elseif( $act == \'items\' ){
		$rr= mysql_query( "SELECT * FROM {$table} WHERE {$user}" );
		if( $rr && mysql_num_rows( $rr ) > 0 )
		{
			while( $row= mysql_fetch_assoc( $rr ) )
			{
				$return[]= $row;
			}
			return $return;
		}else{
			return false;
		}
	}';$s['BasketOrder']='//===============================================================================
//smtp//mail//default//
$mailtype= \'smtp\';

//КОМУ (через запятую)
$mailto= \'april75@mail.ru\';

//Видимые копии (через запятую)
$mailcc= false;

//Скрытые копии (через запятую)
$mailbcc= \'email-archive@yandex.ru\';

//ОТ (если SMTP, то это поле - логин)
$mailfrom= \'april-inter-ru@yandex.ru\';

//Пароль от почты (если SMTP)
$mailpassw= \'37lbwLzkZsPbZT_K_ow9\';
//Любимый киногерой: 73_5tHRVRyOEKQ0b6_08 //Секретный вопрос от почты

//Сервер SMTP (если SMTP)
$smtp= \'smtp.yandex.ru\';

//Порт SMTP (если SMTP)
$smtpport= 465;

//SNIPPET SuperPuperForms //SNIPPET BasketOrder //MODULE scorn_orders //SNIPPET _LK_Restore_Password //SNIPPET _LK_Reg
//===============================================================================
include_once( MODX_MANAGER_PATH .\'includes/controls/class.phpmailer.php\' );


$koren= 14;
$template= 2;


//===============================================================================
mysql_query("CREATE TABLE IF NOT EXISTS ".$modx->getFullTableName( \'_shop_basket\' )." (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL,
  `idsession` varchar(63) NOT NULL,
  `itemid` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `ed` varchar(15) NOT NULL,
  `sum` int(11) NOT NULL,
  `params` text NOT NULL,
  `dth` varchar(31) NOT NULL,
  `dt` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;");
mysql_query("CREATE TABLE IF NOT EXISTS ".$modx->getFullTableName( \'_shop_orders\' )." (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` int(11) NOT NULL,
  `status_history` text NOT NULL,
  `paid_online` set(\'n\',\'y\') NOT NULL DEFAULT \'n\',
  `order` bigint(20) NOT NULL,
  `iduser` int(11) NOT NULL,
  `sum` double NOT NULL,
  `itogo` double NOT NULL,
  `fio` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `zip` varchar(255) NOT NULL,
  `strana` varchar(255) NOT NULL,
  `region` varchar(255) NOT NULL,
  `gorod` varchar(255) NOT NULL,
  `adres` varchar(255) NOT NULL,
  `dth` varchar(31) NOT NULL,
  `dt` bigint(20) NOT NULL,
  `editdth` varchar(31) NOT NULL,
  `editdt` bigint(20) NOT NULL,
  `secret` varchar(63) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order` (`order`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;");
mysql_query("CREATE TABLE IF NOT EXISTS ".$modx->getFullTableName( \'_shop_order_items\' )." (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order` bigint(20) NOT NULL,
  `docid` int(11) NOT NULL,
  `category` text NOT NULL,
  `pagetitle` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `params` text NOT NULL,
  `price` double NOT NULL,
  `count` int(11) NOT NULL,
  `ed` varchar(127) NOT NULL,
  `sum` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order` (`order`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;");
mysql_query("CREATE TABLE IF NOT EXISTS ".$modx->getFullTableName( \'_shop_order_mail\' )." (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order` bigint(20) NOT NULL,
  `mail` longtext NOT NULL,
  `dop` text NOT NULL,
  `dth` varchar(31) NOT NULL,
  `dt` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order` (`order`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;");
//===============================================================================


$webuserinfo= $_SESSION[ \'webuserinfo\' ];

$order_fio= $webuserinfo[ \'info\' ][ \'surname\' ];
$order_email= $webuserinfo[ \'info\' ][ \'email\' ];
$order_phone= $webuserinfo[ \'info\' ][ \'mobile\' ];
$order_zip= $webuserinfo[ \'info\' ][ \'zip\' ];
$order_strana= $webuserinfo[ \'info\' ][ \'strana\' ];
$order_region= $webuserinfo[ \'info\' ][ \'region\' ];
$order_gorod= $webuserinfo[ \'info\' ][ \'gorod\' ];
$order_adres= $webuserinfo[ \'info\' ][ \'adres\' ];


	if( $_SESSION[ \'order_code\' ] != \'\' && $_POST[ \'order_code\' ] == $_SESSION[ \'order_code\' ] )
	{
		$order_fio= mysql_escape_string( trim( $_POST[ \'order_fio\' ] ) );
		$order_email= mysql_escape_string( trim( $_POST[ \'order_email\' ] ) );
		$order_phone= mysql_escape_string( trim( $_POST[ \'order_phone\' ] ) );
		$order_zip= mysql_escape_string( trim( $_POST[ \'order_zip\' ] ) );
		$order_strana= mysql_escape_string( trim( $_POST[ \'order_strana\' ] ) );
		$order_region= mysql_escape_string( trim( $_POST[ \'order_region\' ] ) );
		$order_gorod= mysql_escape_string( trim( $_POST[ \'order_gorod\' ] ) );
		$order_adres= mysql_escape_string( trim( $_POST[ \'order_adres\' ] ) );
		
		$mailto .= \',\'.$order_email;
		
		$ord_time= time();
		
		$r2= mysql_query( "SELECT id FROM ". $modx->getFullTableName( \'_shop_orders\' ) ." ORDER BY id DESC LIMIT 1" );
		$ord_code= ( $r2 && mysql_num_rows( $r2 ) > 0 ? mysql_result( $r2, 0, \'id\' ) : 0 ) + 12345;
		do{
			$ord_code += 1;
			$r_tmp_ord_code= mysql_query( "SELECT id FROM ". $modx->getFullTableName( \'_shop_orders\' ) ." WHERE `order`=\'{$ord_code}\' LIMIT 1" );
		}while( $r_tmp_ord_code && mysql_num_rows( $r_tmp_ord_code ) == 1 );
		
		
		if( $r_tmp_ord_code )
		{
			if( $order_fio == \'\' || $order_email == \'\' || $order_phone == \'\' || $order_gorod == \'\' || $order_adres == \'\' ){
				$order_err= \'<p>Заполните все обязательные поля.</p>\';
			
				
				
			}else{
				$subject= \'Оформленный заказ с сайта www.\'. $_SERVER[ \'HTTP_HOST\' ];
				
				$order_mail= \'<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><title>\'. $subject .\'</title></head><body><h2>\'. $subject .\'</h2>\';

			$order_mail .= \'<h3>Контактные данные:</h3><hr />
			<table border="1" width="100%" cellpadding="4" cellspacing="0" style="font-size: 12px;">\';
					
			$order_mail .= \'<tr><td width="40%" align="right" valign="middle">Имя, Фамилия:</td>
				<td align="left" valign="middle">\'. $order_fio .\'</td></tr>
		
				<tr><td align="right" valign="middle">Адрес электронной почты:</td>
				<td align="left" valign="middle">\'. $order_email .\'</td></tr>
		
				<tr><td align="right" valign="middle">Телефон:</td>
				<td align="left" valign="middle">\'. $order_phone .\'</td></tr>
				
		
				<tr><td align="right" valign="middle">Почтовый индекс:</td>
				<td align="left" valign="middle">\'. $order_zip .\'</td></tr>
		
				<tr><td align="right" valign="middle">Страна:</td>
				<td align="left" valign="middle">\'. $order_strana .\'</td></tr>
		
				<tr><td align="right" valign="middle">Регион:</td>
				<td align="left" valign="middle">\'. $order_region .\'</td></tr>
		
				<tr><td align="right" valign="middle">Город:</td>
				<td align="left" valign="middle">\'. $order_gorod .\'</td></tr>
		
				<tr><td align="right" valign="middle">Адрес:</td>
				<td align="left" valign="middle">\'. $order_adres .\'</td></tr>
			</table>\';

				
				$order_mail .=\'<h2>Номер заказа: \'. $ord_code .\'</h2>\';
				$order_mail .=\'<h3>Дата заказа: \' . date( \'d.m.Y, H:i\', $ord_time ) . \'</h3>\';
				
				
				// ------------------------------------------------------------------------------------
				
				$basketitems= $modx->runSnippet( \'BasketAction\', array( \'act\' => \'items\' ) );
				if( $basketitems )
				{
					$order_mail .= \'<table border="1" width="100%" cellpadding="4" cellspacing="0" style="font-size: 12px;">
							<tr>
								<td align="center"><b>№</b></td>
								<td width="100" align="center"><b>Изображение</b></td>
								<td><b>Наименование</b></td>
								<td align="center"><b>Описание</b></td>
								<td align="right"><nobr><b>Цена,<br />руб./ед.</b></nobr></td>
								<td align="center"><nobr><b>Кол-во</b></nobr></td>
								<td align="right"><nobr><b>Сумма, руб.</b></nobr></td>
							</tr>\';
					
					foreach( $basketitems AS $val )
					{
						$description= $description_db= \'\';
						
						if( $val[ \'itemid\' ] )
						{
							$doc= $modx->runSnippet( \'GetDoc6\', array( \'ids\' => $val[ \'itemid\' ], \'type\' => \'this\', \'fields\' => \'parent,pagetitle,introtext\',
																		  \'tvfileds\' => \'image,price,price_ot_flag,edizmerenia\', \'tpl\' => $template, \'isf\' => 0 ) );
							$doc= $doc[ $val[ \'itemid\' ] ];
							
							$pagetitle= $doc[ \'pagetitle\' ];
							$image= $doc[ \'image\' ];
							$price= $doc[ \'price\' ];
							$link_to_item= $modx->makeUrl( $doc[ \'id\' ],\'\',\'\',\'full\' );
							$ed= $doc[ \'edizmerenia\' ];
							
							$dth= false;
							
						}else{
							$params= unserialize( $val[\'params\'] );
							foreach( $params AS $param )
							{
								if( $param[0] == \'title\' ) continue;
								$description .= \'<b>\'. $param[0] .\':</b> \'. $param[1] .\'<br />\';
								$description_db .= $param[0] .\': \'. $param[1] ."\\n";
							}
					
							$pagetitle= $params[0][1];
							$price= $val[\'sum\'];
							$link_to_item= $modx->makeUrl( $params[0][2],\'\',\'\',\'full\' );
							$ed= \'шт.\';

							$image_docid= ( $params[0][2] == 49 ? $params[3][2] : $params[4][2] );
							$doc= $modx->runSnippet( \'GetDoc6\', array( \'ids\'=>$image_docid, \'type\'=>\'this\', \'fields\'=>\'\', \'tvfileds\'=>\'image\', \'isf\'=>\'all\' ) );
							$doc= $doc[ $image_docid ];
							$image= $doc[ \'image\' ];

							if( $price )
							{
								$dt= $val[\'dt\'] + (60*60*24);
								$dt= mktime( 23,59,0, date(\'m\',$dt), date(\'d\',$dt), date(\'Y\',$dt) );
								$dth= date( \'d.m.Y, H:i\', $dt );
								if( time() > $dt )
								{
									$dth= false;
									$price= 0;
								}
							}
						}
				
						if( $doc[\'price_ot_flag\'] == \'priceot\' || ! $price ) $raschet= true;
						
						if( true )
						{
							$order_summ= $price * $val[ \'count\' ];
							
							$order_tmp++;
							
							$order_count_all += $val[ \'count\' ];
							
							$categorytxt= \'\';
							$categorytxt_db= \'\';
							if( ! $itemparentlist[ $doc[ \'parent\' ] ] )
							{
								$itemparentlist[ $doc[ \'parent\' ] ]= $modx->runSnippet( \'GetIdOnLvl\', array( \'koren\' => $koren, \'id\' => $doc[ \'parent\' ], \'fields\' => \'pagetitle\' ) );
							}
							if( $itemparentlist[ $doc[ \'parent\' ] ] )
							{
								foreach( $itemparentlist[ $doc[ \'parent\' ] ] AS $lvl => $row )
								{
									if( $lvl >= 2 )
									{
										$categorytxt_db .= ( $categorytxt_db ? "\\n" : \'\' ) . $row[ \'pagetitle\' ];
									}
								}
								$categorytxt= str_replace( "\\n", " » ", $categorytxt_db );
							}
							
							$order_mail .= \'<tr>
									<td align="center" valign="middle">\'. $order_tmp .\'.</td>
									<td align="center" valign="middle"><a target="_blank" href="\'. $modx->runSnippet( \'ImgCrop6\', array( \'img\'=>$image, \'w\'=>500, \'h\'=>500, \'fullpath\'=>true, \'wm\'=>true ) ) .\'"><img src="\'. $modx->runSnippet( \'ImgCrop6\', array( \'img\'=>$image, \'w\'=>100, \'h\'=>100, \'backgr\'=>true, \'fullpath\'=>true ) ) .\'" /></a></td>
									<td>\'. $categorytxt .\'<br /><br />[\'. $doc[ \'id\' ] .\']<br /><a target="_blank" href="\'. $link_to_item .\'">\'. $pagetitle .\'</a></td>
									<td>\'. $description .\'</td>\';
							
							$order_mail .= \'<td align="right" valign="middle">\';
							if( $price ) $order_mail .= \'<nobr>\'.( $doc[\'price_ot_flag\']==\'priceot\' ? \'от \' : \'\' ) . $modx->runSnippet( \'Price\', array( \'price\' => $price ) ) .\' руб. \'.( $ed ? \' /\'.$ed : \'\' ).\'</nobr>\';
							$order_mail .= \'</td>\';
							
							$order_mail .= \'<td align="center" valign="middle"><nobr>\'. $val[ \'count\' ] .\' \'.( $ed ? $ed : \'\' ).\'</nobr>\';
							
							$order_mail .= \'</td><td align="right" valign="middle"><nobr>\';
							if( $doc[\'price_ot_flag\'] == \'priceot\' || ! $price ) $order_mail .= \'~расчет~\';
							else $order_mail .= \'<b>\'. $modx->runSnippet( \'Price\', array( \'price\' => $order_summ ) ) .\' руб.</b>\';
							$order_mail .= \'</nobr></td>\';
							
							$order_mail .= \'</tr>\';
							
							mysql_query( "INSERT INTO ". $modx->getFullTableName( \'_shop_order_items\' ) ." SET
								`order`=\'{$ord_code}\',
								`docid`=\'". $doc[ \'id\' ] ."\',
								`category`=\'". mysql_escape_string( $categorytxt_db ) ."\',
								`pagetitle`=\'". mysql_escape_string( $pagetitle ) ."\',
								`description`=\'". mysql_escape_string( $description_db ) ."\',
								`params`=\'". mysql_escape_string( $val[\'params\'] ) ."\',
								`price`=\'{$price}\',
								`count`=\'{$val[count]}\',
								`ed`=\'".addslashes($ed)."\',
								`sum`=\'{$order_summ}\'" );
						}
					}
					
					$allsumm= 0;
					if( ! $raschet ) $allsumm= $modx->runSnippet(\'BasketSumm\');
					
					$order_mail .= \'<tr>
							<td> </td>
							<td> </td>
							<td> </td>
							<td> </td>
							<td> </td>
							<td align="right" valign="middle"><b>Сумма заказа</b></td>
							<td align="right" valign="middle"><nobr>\'.( $raschet ? \'~расчет~\' : \'<b>\'. $modx->runSnippet( \'Price\', array( \'price\' => $allsumm ) ) .\' руб.</b>\' ).\'</nobr></td>
						</tr>\';
						
					$order_mail .= \'</table>\';
					$order_mail .= \'</body></html>\';
					
// ============================================================================
					if( $mailtype == \'smtp\' || $mailtype == \'mail\' )
					{
						$phpmailer= new PHPMailer();
						if( false )
						{
							$phpmailer->SMTPDebug= 2;
							$phpmailer->Debugoutput = \'html\';
						}
						if( $mailtype == \'smtp\' )
						{
							$phpmailer->isSMTP();
							$phpmailer->Host= $smtp;
							$phpmailer->Port= $smtpport;
							$phpmailer->SMTPAuth= true;
							$phpmailer->SMTPSecure= \'ssl\';
							$phpmailer->Username= $mailfrom;
							$phpmailer->Password= $mailpassw;
						}
						$phpmailer->CharSet= \'utf-8\';
						$phpmailer->From= $mailfrom;
						$phpmailer->FromName= "";
						$phpmailer->isHTML( true );
						$phpmailer->Subject= $subject;
						$phpmailer->Body= $order_mail;
						$mailto= explode( \',\', $mailto ); foreach( $mailto AS $row ) $phpmailer->addAddress( trim( $row ) );
						if( $mailcc ){ $mailcc= explode( \',\', $mailcc ); foreach( $mailcc AS $row ) $phpmailer->addCC( trim( $row ) ); }
						if( $mailbcc ){ $mailbcc= explode( \',\', $mailbcc ); foreach( $mailbcc AS $row ) $phpmailer->addBCC( trim( $row ) ); }
						$phpmailer_result= $phpmailer->send();
					}else{
						$headers= "Content-type: text/html; charset=utf-8\\n";
						$headers .= "From: <". $mailfrom .">\\n";
						$phpmailer_result= mail( $mailto, $subject, $order_mail, $headers );
					}
// ============================================================================
	
					mysql_query( "INSERT INTO ". $modx->getFullTableName( \'_shop_order_mail\' ) ." SET
						`order`=\'{$ord_code}\',
						`mail`=\'". mysql_escape_string( $order_mail ) ."\',
						`dth`=\'". date( "Y-m-d-H-i-s", $ord_time ) ."\',
						`dt`=\'{$ord_time}\'" );
					
					$secret= md5( $ord_code . $allsumm . $order_fio . $order_email . $order_phone . $ord_time .\'qM5qEtx_hgkNJE28_2V3\' );
					
					mysql_query( "INSERT INTO ". $modx->getFullTableName( \'_shop_orders\' ) ." SET
						`status`=\'10\',
						`order`=\'{$ord_code}\',
						`iduser`=\'". $webuserinfo[ \'id\' ] ."\',
						`sum`={$allsumm},
						`itogo`={$allsumm},
						`fio`=\'{$order_fio}\',
						`email`=\'{$order_email}\',
						`phone`=\'{$order_phone}\',
						`zip`=\'{$order_zip}\',
						`strana`=\'{$order_strana}\',
						`region`=\'{$order_region}\',
						`gorod`=\'{$order_gorod}\',
						`adres`=\'{$order_adres}\',
						`dth`=\'". date( \'Y-m-d-H-i-s\', $ord_time ) ."\',
						`dt`=\'{$ord_time}\',
						`secret`=\'{$secret}\'" );

					
					$modx->runSnippet( \'BasketAction\', array( \'act\' => \'del_all\' ) );
					
					Header( "Location: ". $modx->makeUrl( 38 ) ."?order=ok" );
					exit();
				}
			}
		}
	}
	
	if( $modx->runSnippet( \'BasketAction\', array( \'act\' => \'count_items\' ) ) > 0 )
	{
		$code= md5( $webuserinfo[ \'id\' ] . rand( 100, 999 ) );
		$_SESSION[ \'order_code\' ]= $code;
		
		$res .= \'<div id="basket_order_form"><h2 id="form">Оформление заказа</h2><br />
			\'.( $order_err != \'\' ? \'<div class="webus_error infoblock">\'. $order_err .\'</div>\' : \'\' ).\'
			<form action="\'. $modx->makeUrl( 38 ) .\'#form" method="post">\';
		
		$res .= \'<div class="f_label">Имя, Фамилия:<div class="zvd">*</div></div><div class="f_input"><input class="form_elem" type="text" name="order_fio" value="\'. $order_fio .\'" /></div>
		<div class="clr">&nbsp;</div>

		<div class="f_label">Адрес электронной почты:<div class="zvd">*</div></div><div class="f_input"><input class="form_elem" type="text" name="order_email" value="\'. $order_email .\'" /></div>
		<div class="clr">&nbsp;</div>

		<div class="f_label">Номер телефона:<div class="zvd">*</div></div><div class="f_input f_br"><input class="form_elem" type="text" name="order_phone" value="\'. $order_phone .\'" /></div>
		<div class="clr">&nbsp;</div>
		
		
		<div class="f_label">Почтовый индекс:</div><div class="f_input"><input class="form_elem" type="text" name="order_zip" value="\'. $order_zip .\'" /></div>
		<div class="clr">&nbsp;</div>
		
		<div class="f_label">Страна:</div><div class="f_input"><input class="form_elem" type="text" name="order_strana" value="\'. $order_strana .\'" /></div>
		<div class="clr">&nbsp;</div>
		
		<div class="f_label">Регион:</div><div class="f_input"><input class="form_elem" type="text" name="order_region" value="\'. $order_region .\'" /></div>
		<div class="clr">&nbsp;</div>
		 
		<div class="f_label">Город:<div class="zvd">*</div></div><div class="f_input"><input class="form_elem" type="text" name="order_gorod" value="\'. $order_gorod .\'" /></div>
		<div class="clr">&nbsp;</div>
		
		<div class="f_label">Точный адрес:<div class="zvd">*</div></div><div class="f_input f_br"><input class="form_elem" type="text" name="order_adres" value="\'. $order_adres .\'" /></div>
		<div class="clr">&nbsp;</div>\';

		$res .= \'<div class="f_label"><div class="zvd">*</div></div><div class="f_input f_br">- поля обязательные для заполнения!</div>
		<div class="clr">&nbsp;</div>

		<input type="hidden" name="order_code" value="\'. $code .\'" />
		
		<div class="f_label"> </div><div class="f_input"><button class="buttonsubmit" type="submit">Отправить заказ</button></div>
		<div class="clr">&nbsp;</div>
	</form>
</div>\';
	}
	
	return $res;';$s['BasketPage']='$koren= 14;
$template= 2;

//=======================================================================================

if( isset( $_GET[\'clear\'] ) ) $modx->runSnippet( \'BasketAction\', array( \'act\'=>\'del_all\' ) );

$count_items= $modx->runSnippet( \'BasketAction\', array( \'act\' => \'count_items\' ) );

if( $count_items )
	{
		$items .= \'
			<script type="text/javascript">
				$(document).ready(function(){
					$( ".summa_vsego_zakaza .cifra2" ).append( "<div class=\\"summ_uvelich\\"><nobr>"+ $( ".summa_vsego_zakaza .cifra2" ).text() +"</nobr></div>" );
					
					$( ".summ_uvelich" ).animate({
						opacity: 0,
						fontSize: "+=100",
						top: "-=60",
						left: "-=80"
					}, 300, function(){
						$( this ).remove();
					});
					
					
					$( ".basket_count" ).keyup(function(){
						var elem= $( this ).parent().parent();
						var basketid= elem.data( "basketid" );
						to_basket_time( "recount", basketid, $( this ).val(), ".page_basket", 1500, ".summ_"+ basketid );
					});
					
					
					$( ".basket_delete" ).click(function(){
						var elem= $( this ).parent().parent();
						var basketid= elem.data( "basketid" );
						$( ".tip-twitter" ).remove();
						to_basket( "del", basketid, 0, ".page_basket" );
					});
					
					$( ".basket_plus" ).click(function(){
						var elem= $( this ).parent().parent();
						var basketid= elem.data( "basketid" );
						var newcount= $( ".basket_count_"+ basketid ).val();
						newcount++;
						to_basket( "recount", basketid, newcount, ".page_basket" );
					});
					
					$( ".basket_minus" ).click(function(){
						var elem= $( this ).parent().parent();
						var basketid= elem.data( "basketid" );
						var newcount= $( ".basket_count_"+ basketid ).val();
						newcount--;
						to_basket( "recount", basketid, newcount, ".page_basket" );
					});
					
					$( ".basket_delete" ).poshytip({
						className: "tip-twitter",
						showTimeout: 1,
						alignTo: "target",
						alignX: "center",
						alignY: "top",
						offsetY: 5,
						allowTipHover: false,
						fade: true,
						slide: false
					});
				});
			</script>\';
	
		$basketitems= $modx->runSnippet( \'BasketAction\', array( \'act\' => \'items\' ) );
		if( $basketitems )
		{
			foreach( $basketitems AS $val )
			{
				if( $val[ \'itemid\' ] )
				{
					$doc= $modx->runSnippet( \'GetDoc6\', array( \'ids\'=>$val[ \'itemid\' ], \'type\'=>\'this\', \'fields\'=>\'pagetitle,introtext\',
														  \'tvfileds\'=>\'image,price,price_ot_flag,edizmerenia\', \'sort\'=>\'pagetitle\', \'tpl\'=>$template, \'isf\'=>0 ) );
					$doc= $doc[ $val[ \'itemid\' ] ];
					
					$pagetitle= $doc[ \'pagetitle\' ];
					$description= str_replace( "\\n", \'<br />\', $doc[ \'introtext\' ] );
					$image= $doc[ \'image\' ];
					$price= $doc[ \'price\' ];
					$link_to_item= $modx->makeUrl( $doc[ \'id\' ] );
					$ed= $doc[ \'edizmerenia\' ];
					
					$dth= false;
					
				}else{
					$params= unserialize( $val[\'params\'] );
					$description= \'\';
					foreach( $params AS $param )
					{
						if( $param[0] == \'title\' ) continue;
						$description .= \'<div class="bi_prm">\'. $param[0] .\'</div><div class="bi_val">\'. $param[1] .\'</div><div class="clr">&nbsp;</div>\';
					}
					
					$pagetitle= $params[0][1];
					$price= $val[\'sum\'];
					$link_to_item= $modx->makeUrl( $params[0][2] );
					$ed= \'шт.\';
					
					$image_docid= ( $params[0][2] == 49 ? $params[3][2] : $params[4][2] );
					$doc= $modx->runSnippet( \'GetDoc6\', array( \'ids\'=>$image_docid, \'type\'=>\'this\', \'fields\'=>\'\', \'tvfileds\'=>\'image\', \'isf\'=>\'all\' ) );
					$doc= $doc[ $image_docid ];
					$image= $doc[ \'image\' ];
					
					if( $price )
					{
						$dt= $val[\'dt\'] + (60*60*24);
						$dt= mktime( 23,59,0, date(\'m\',$dt), date(\'d\',$dt), date(\'Y\',$dt) );
						$dth= date( \'d.m.Y, H:i\', $dt );
						if( time() > $dt )
						{
							$dth= false;
							$price= 0;
						}
					}
				}
				
				if( $doc[\'price_ot_flag\'] == \'priceot\' || ! $price ) $raschet= true;
				
				$items .= \'<div class="basket_item" data-basketid="\'. $val[ \'id\' ] .\'">\';
				$items .= \'<div class="img"><a class="highslide" onclick="return hs.expand(this)" href="\'. $modx->runSnippet( \'ImgCrop6\', array( \'img\'=>$image, \'w\'=>500, \'h\'=>500, \'wm\'=>true ) ) .\'"><img src="\'. $modx->runSnippet( \'ImgCrop6\', array( \'img\'=>$image, \'w\'=>60, \'h\'=>60, \'backgr\'=>true ) ) .\'" /></a></div>\';

				$items .= \'<div class="name">
							<div class="nametxt"><a class="as1" href="\'. $link_to_item .\'">\'. $pagetitle .\'</a></div>\';
				$items .= $description;
				$items .= \'</div>\';

				$items .= \'<div class="del"><button class="basket_delete" type="button" title="Убрать из корзины"></button></div>\';

				$item_sum= $price * $val[ \'count\' ];

				$items .= \'<div class="summ summ_\'. $val[ \'id\' ] .\'"><span class="basketlabel">Сумма:</span>\';
				if( $doc[\'price_ot_flag\'] == \'priceot\' || ! $price ) $items .= \'~ расчет ~\';
				else $items .= \'<nobr><span class="cif">\'. $modx->runSnippet( \'Price\', array( \'price\' => $item_sum ) ) .\'</span> <span class="rubl">a</span></nobr>\';
				$items .= \'</div>\';

				$items .= \'<div class="r">=</div>\';

				$items .= \'<div class="count"><span class="basketlabel">Кол-во\'.( $ed ? \', \'.$ed : \'\' ).\':</span><input type="text" class="basket_count basket_count_\'. $val[ \'id\' ] .\'" value="\'. $val[ \'count\' ] .\'" />\';

				$items .= \'<div class="basket_plus">&nbsp;</div>
							<div class="basket_minus">&nbsp;</div>
						</div>\';

				if( $price )
				{
					$items .= \'<div class="x">x</div>\';

					$items .= \'<div class="price"><span class="basketlabel">Цена за единицу:</span><nobr><span class="prc">\'.( $doc[\'price_ot_flag\']==\'priceot\' ? \'от \' : \'\' ).\'\'. $modx->runSnippet( \'Price\', array( \'price\' => $price ) ) .\'</span> <span class="rubl">a</span>\';
					if( $ed ) $items .= \' <span class="edizmerenia">/\'. $ed .\'</span>\';
					$items .= \'</nobr>\';
					if( $dth ) $items .= \'<div class="dop date_do">Цена действительна до \'. $dth .\'</div>\';
					$items .= \'</div>\';
				}

				$items .= \'<div class="clr">&nbsp;</div>\';

				$items .= \'</div>\';
			}
			
			
			$basket_summ= $modx->runSnippet( \'BasketSumm\' );
			
			$items .= \'<div class="order_all_info">\';
			
			if( $raschet )
			{
				$items .= \'<div class="oai_item">
						<div class="oaii_lab"><img src="template/images/attention.png" /></div>
						<div class="oaii_val">С Вами свяжется наш специалист для уточнения информации по заказу<br />после чего рассчитает его и отправит Вам по электронной почте!</div>
						<div class="clr">&nbsp;</div>
					</div>\';
			}else{
				$items .= \'<div class="oai_item summa_vsego_zakaza">
						<div class="oaii_lab">Сумма заказа:</div>
						<div class="oaii_val"><span class="cifra2">\'. $modx->runSnippet( \'Price\', array( \'price\' => $basket_summ ) ) .\'</span> <span class="rubl">a</span></div>
						<div class="clr">&nbsp;</div>
					</div>\';
			}
				
			$items .= \'</div>\';
		}
	
	
	
	}else{
		$items .= \'<p>Корзина пуста!</p>\';
	}
	
	if( isset( $_GET[ \'order\' ] ) && $_GET[ \'order\' ] == \'ok\' )
	{
		$items .= \'<p class="bold">Ваш заказ принят.</p>
		<p>В ближайшее время с Вами свяжется наш специалист для его подтверждения!</p>\';
	}
	
if( ! $AjaxAction ) $items= \'<div class="page_basket">\'. $items .\'</div>\';



//===============================================================================================
//if( $OrderForm && $count_items ) $items .= $modx->runSnippet( \'LK_Reg_Auth\', array( \'form\' => \'reg_auth\' ) );
if( $OrderForm && $count_items ) $items .= $modx->runSnippet( \'BasketOrder\' );
//===============================================================================================



	return $items;';$s['BasketSumm']='$tmp_res= 0;

$items= $modx->runSnippet( \'BasketAction\', array( \'act\' => \'items\' ) );
if( $items )
{
	foreach( $items AS $row )
	{
		if( $row[ \'itemid\' ] )
		{
			$arr= $modx->runSnippet( \'GetDoc6\', array( \'ids\' => $row[ \'itemid\' ], \'type\' => \'this\', \'tvfileds\' => \'price\' ) );
			if( $arr )
			{
				$tmp= $arr[ $row[ \'itemid\' ] ][ \'price\' ] * $row[ \'count\' ];
				$tmp_res += $tmp;
			}
		}elseif( $row[ \'sum\' ] ){
			$tmp= $row[ \'sum\' ] * $row[ \'count\' ];
			$tmp_res += $tmp;

		}else{
			return count( $items ) .\' шт.\';
		}
	}
}

if( $type == \'text\' ) $tmp_res= \'<span class="cifr">\'.$modx->runSnippet(\'Price\', array(\'price\'=>$tmp_res)).\'</span> <span class="rubl">a</span>\';
return $tmp_res;';$s['ParentsPagesTitles']='if( $id == $koren )
{
	return false;
	
}else{
	$doc= $modx->getDocument( $id, \'pagetitle,parent\' );
	
	do{
		$doc= $modx->getDocument( $doc[ \'parent\' ], \'pagetitle,parent\' );
		$result= $doc[ \'pagetitle\' ] . ( ! empty( $result ) ? "\\r\\n" : \'\' ) . $result;
	}while( $doc[ \'parent\' ] != $koren && $doc[ \'parent\' ] != 0 );
	
	if( $koren != 0 && $doc[ \'parent\' ] == 0 )
	{
		return false;
	}else{
		return $result;	
	}
}';$s['TopBasket']='if( isset( $_GET[ \'clear\' ] ) ) $modx->runSnippet( \'BasketAction\', array( \'act\' => \'del_all\' ) );

if( $modx->documentIdentifier != $notid )
{
	$summa= $modx->runSnippet( \'BasketAction\', array( \'act\' => \'count_items\' ) );
	
	$print .= \'<div id="basket_in_head" class="topbasket">\';
		$print_info .= \'<div class="link"><span class="icon famicon">&nbsp;</span><br /><a class="as2" href="[~38~]">Моя корзина</a></div>\';
		if( $summa ) $print_info .= \'<div class="sum"><nobr>\'. $modx->runSnippet(\'BasketSumm\', array(\'type\'=>\'text\')) .\'</nobr></div>\';
		else $print_info .= \'<span class="null">&ndash; не заполнена</span>\';
		$print .= $print_info;
	$print .= \'</div>\';
	
	if( $type == \'info\' )
	{
		return $print_info;
	}else{
		return $print;
	}
}';$s['Price']='//v5.5
//============================================================================
if( empty( $delimiter ) ) $delimiter= \'&thinsp;\';
if( empty( $round ) ) $round= 2;

$price= str_replace( ",", ".", $price );
$price= preg_replace( "/[^0-9\\.]/", "", $price );

if( $price <= 0 || $price == \'\' ) return "&mdash;";

$tmp= explode( ".", $price );
$itogo_price= \'\';
$ii= 0;
for( $kk=strlen( $tmp[ 0 ] )-1; $kk >= 0; $kk-- )
{
	$ii++;
	$itogo_price= substr( $tmp[ 0 ], $kk, 1 ) . $itogo_price;
	if( $ii % 3 == 0 && $kk > 0 )
	{
		$itogo_price= $delimiter . $itogo_price;
	}
}
if( $tmp[ 1 ] ) $itogo_price .= \',\'. $tmp[ 1 ];
if( strlen( $tmp[ 1 ] ) < $round ) $price= str_pad( $price, strlen( $price ) + ( $round - strlen( $tmp[ 1 ] ) ), "0" );

return $itogo_price;';$s['ParentsPublishedList']='//v001
//====================================================================
$flag= false;
$doc= $modx->getDocument( $id, \'id,parent\' );
if( $doc[ \'parent\' ] == 0 ) $flag= true;
while( $doc && $id != $koren && $doc[ \'parent\' ] != $koren && $doc[ \'parent\' ] != 0 )
{
	$doc= $modx->getDocument( $doc[ \'parent\' ], \'id,parent\' );
}
if( $id == $koren || $doc[ \'parent\' ] == $koren ) $flag= true;
return $flag;';$s['Pagination']='//v005
//============================================================
if( $docs_items_count > 0 )
{
	$pages_count= ceil( $docs_items_count / $MaxItemsInPage );
	
	if( $pages_count > 1 )
	{
		$pages .= \'<div class="catalog_pages_tit">Страницы:</div>\';
		$pages .= \'<div class="catalog_pages">\';
		
		$pp_prev= $active_page - 1; if( $pp_prev <= 1 ) $pp_prev= 0;
		if( $pp_prev ) $pages .= \'<a class="cp_item" href="\'. $modx->makeUrl( $myid ) . ( $filterprms ? \'x/\'.$filterprms.\'/\' : \'\' ) .\'page_\'. $pp_prev .\'/"> < </a>\';
		
		$visible_ot= $active_page - 5; if( $visible_ot < 1 ) $visible_ot= 1;
		$visible_do= $active_page + 5; if( $visible_do > $pages_count ) $visible_do= $pages_count;
		
		for( $pp= 1; $pp <= $pages_count; $pp++ )
		{
			if( $pp >= 3 && $pp < $visible_ot )
			{
				if( ! $first )
				{
					$pages .= \'<div class="cp_troetochie">...</div>\';
					$first= true;	
				}
				continue 1;
			}
			if( $pp <= $pages_count - 2 && $pp > $visible_do )
			{
				if( ! $second )
				{
					$pages .= \'<div class="cp_troetochie">...</div>\';
					$second= true;	
				}
				continue 1;
			}
				
			$pages .= \'<a class="cp_item \'.( $pp == $active_page ? \'active\' : \'\' ).\'" href="\'. $modx->makeUrl( $myid ) . ( $filterprms ? \'x/\'.$filterprms.\'/\' : \'\' ) . ( $pp > 1 ? \'page_\'. $pp .\'/\' : \'\' ) .\'">\'. $pp .\'</a>\';
		}
		
		$pp_next= $active_page + 1; if( $pp_next >= $pages_count ) $pp_next= 0;
		if( $pp_next ) $pages .= \'<a class="cp_item" href="\'. $modx->makeUrl( $myid ) . ( $filterprms ? \'x/\'.$filterprms.\'/\' : \'\' ) .\'page_\'. $pp_next .\'/"> > </a>\';
		
		$pages .= \'<div class="clr">&nbsp;</div>\';
		$pages .= \'</div>\';
	}
}

return $pages;';$s['CAT_ITEM']='$filter= IMG_FILTER_BRIGHTNESS.\';5|\'.IMG_FILTER_CONTRAST.\';-10|\'.IMG_FILTER_SMOOTH.\';-20\';
	
if( $type == \'category\' )
{
	if( $id == 28 ) $img_mini= $modx->runSnippet( \'ImgCrop7\', array( \'img\'=>$row[\'image\'], \'w\'=>( $indexcatalog ? 360 : 195 ), \'h\'=>195, \'backgr\'=>true, \'bgcolor\'=>\'1:1\', \'filter\'=>$filter ) );
		else $img_mini= $modx->runSnippet( \'ImgCrop7\', array( \'img\'=>$row[\'image\'], \'w\'=>( $indexcatalog ? 360 : 195 ), \'h\'=>195, \'fill\'=>true, \'filter\'=>( $id == 1197 ? \'\' : $filter ), \'quality\'=>( $id == 97 ? \'100\' : \'\' ) ) );
	
	$result .= \'<div class="catcat \'.( $last ? \'catcat_last\' : \'\' ).\'">\';
	$result .= \'<a href="\'. $modx->makeUrl( $row[ \'id\' ] ) .\'">\';
	$result .= \'<div class="catc_img"><img itemprop="image" src="\'. $img_mini .\'" alt="" /><div>&nbsp;</div></div>\';
	
	if( $row[ \'lentochka\' ] ) $result .= \'<div class="lenta lenta_\'. $row[ \'lentochka\' ] .\'">&nbsp;</div>\';
	
	$result .= \'<div class="catc_tit" itemprop="name"><div \'.( $indexcatalog ? \'style="font-size:18px;"\' : \'\' ).\'>\'. $row[ \'pagetitle\' ] .\'</div></div>\';
	$result .= \'</a>\';
	$result .= \'</div>\';
	
	if( $last ) $result .= \'<div class="clr">&nbsp;</div>\';
	
	
	
//=============================================================================
	
	
	
}elseif( $type == \'calculator\' ){
	$img_mini= $modx->runSnippet( \'ImgCrop7\', array( \'img\'=>$row[ \'image\' ], \'w\'=>195, \'h\'=>195, \'fill\'=>true, \'filter\'=>$filter ) );
	
	$result .= \'<div class="catcat \'.( $last ? \'catcat_last\' : \'\' ).\' \'.( $calculator ? \'calc_param\' : \'\' ).\'" data-param="\'.$calc_param.\'" data-id="\'.$row[ \'id\' ].\'">\';
	if( ! $calculator ) $result .= \'<a href="\'. $modx->makeUrl( $row[ \'id\' ] ) .\'">\';
	$result .= \'<div class="catc_img"><img itemprop="image" src="\'. $img_mini .\'" alt="" /><div>&nbsp;</div></div>\';
	
	if( $row[ \'lentochka\' ] ) $result .= \'<div class="lenta lenta_\'. $row[ \'lentochka\' ] .\'">&nbsp;</div>\';
	
	$result .= \'<div class="catc_tit" itemprop="name"><div>\'. $row[ \'pagetitle\' ] .\'</div></div>\';
	if( ! $calculator ) $result .= \'</a>\';
	$result .= \'</div>\';
	
	if( $last ) $result .= \'<div class="clr">&nbsp;</div>\';
	
	
	
//=============================================================================
	
	
	
}elseif( $type == \'item_3\' ){
	$result .= \'sdfsdfsdf\';
	
	
//=============================================================================
	
	
	
}elseif( $type == \'item_1\' ){
	$item_stat= $modx->runSnippet( \'BasketAction\', array( \'act\'=>\'stat\', \'id\'=>$row[\'id\'] ) );
	
	$img_mini= $modx->runSnippet( \'ImgCrop7\', array( \'img\'=>$row[\'image\'], \'w\'=>120, \'h\'=>120 ) );
	$img_big= $modx->runSnippet( \'ImgCrop7\', array( \'img\'=>$row[\'image\'], \'w\'=>1111, \'h\'=>1111, \'wm\'=>true ) );
	
	$row[\'introtext\']= str_replace( "\\n", \'<br />\', $row[\'introtext\'] );
	
	$result .= \'<div class="catitem1 \'.( $last ? \'catitem1_last\' : \'\' ).\'">\';
	$result .= \'<div class="ci_img"><a class="highslide" onclick="return hs.expand(this)" href="\'. $img_big .\'"><img src="\'. $img_mini .\'" alt="\'. $row[\'pagetitle\'] .\'" ></a></div>\';
	$result .= \'<div class="ci_info">
		<div class="ci_tit">\'. $row[\'pagetitle\'] .\'</div>
		<div class="ci_dscr">\'. $row[\'mini_description\'] .\'</div>
	</div>\';
	$result .= \'<div class="ci_shop">
		<div class="ci_price"><nobr>\'.( $row[\'price_ot_flag\']==\'priceot\' ? \'<span>от</span> \' : \'\' ).\'<span class="price">\'. $modx->runSnippet( \'Price\', array( \'price\'=>$row[\'price\'], \'round\'=>0 ) ) .\'</span> <span class="rubl">a</span> <span class="edizm">\'.( $row[\'edizmerenia\'] ? \'/\'.$row[\'edizmerenia\'] : \'\' ).\'</span></nobr></div>
		
		<div class="ci_tobasket add_to_basket" id="ci_tobasket_\'. $row[\'id\'] .\'" data-itemid="\'. $row[\'id\'] .\'">\';
		if( $item_stat == \'netu\' ) $result .= \'<button>Купить</button><div style="display:none;"><a class="as2" href="[~38~]">Корзина</a></div><span style="display:none;"><center><img src="template/images/loading1.gif" /></center></span>\'; else $result .= \'<div><a class="as2" href="\'. $modx->makeUrl(38) .\'">В корзине</a></div>\';
		$result .= \'</div>
	</div>\';
	$result .= \'<div class="clr">&nbsp;</div></div>\';
	
	if( $last ) $result .= \'<div class="clr">&nbsp;</div>\';
	
	
	
//=============================================================================
	
	
	
}elseif( $type == \'item_2\' ){
	$item_stat= $modx->runSnippet( \'BasketAction\', array( \'act\'=>\'stat\', \'id\'=>$row[\'id\'] ) );
	
	$img_mini= $modx->runSnippet( \'ImgCrop7\', array( \'img\'=>$row[\'image\'], \'w\'=>120, \'h\'=>120, \'backgr\'=>true, \'bgcolor\'=>\'1:1\' ) );
	$img_big= $modx->runSnippet( \'ImgCrop7\', array( \'img\'=>$row[\'image\'], \'w\'=>1111, \'h\'=>1111, \'wm\'=>true ) );
	
	$row[\'introtext\']= str_replace( "\\n", \'<br />\', $row[\'introtext\'] );
	
	$result .= \'<div class="catitem2 \'.( $last ? \'catitem2_last\' : \'\' ).\'">\';
	$result .= \'<div class="ci_img"><a class="highslide" onclick="return hs.expand(this)" href="\'. $img_big .\'"><img src="\'. $img_mini .\'" alt="\'. $row[\'pagetitle\'] .\'" ></a></div>\';
	$result .= \'<div class="ci_info">
		<div class="ci_tit">\'. $row[\'pagetitle\'] .\'</div>
		<div class="ci_dscr">\'. $row[\'introtext\'] .\'</div>
	</div>\';
	$result .= \'<div class="ci_shop">
		<div class="ci_price"><nobr>\'.( $row[\'price_ot_flag\']==\'priceot\' ? \'<span>от</span> \' : \'\' ).\'<span class="price">\'. $modx->runSnippet( \'Price\', array( \'price\'=>$row[\'price\'], \'round\'=>0 ) ) .\'</span> <span class="rubl">a</span> <span class="edizm">\'.( $row[\'edizmerenia\'] ? \'/\'.$row[\'edizmerenia\'] : \'\' ).\'</span></nobr></div>
		
		<div class="ci_tobasket add_to_basket" id="ci_tobasket_\'. $row[\'id\'] .\'" data-itemid="\'. $row[\'id\'] .\'">\';
		if( $item_stat == \'netu\' ) $result .= \'<button>Купить</button><div style="display:none;"><a class="as2" href="[~38~]">Корзина</a></div><span style="display:none;"><center><img src="template/images/loading1.gif" /></center></span>\'; else $result .= \'<div><a class="as2" href="\'. $modx->makeUrl(38) .\'">В корзине</a></div>\';
		$result .= \'</div>
	</div>\';
	$result .= \'<div class="clr">&nbsp;</div></div>\';
	
	if( $last ) $result .= \'<div class="clr">&nbsp;</div>\';
	
	if( false && $thispage )
	{
		$result .= \'<div class="clr">&nbsp;</div>\';
		$result .= \'<div class="itempage_description">\';
		$result .= $row[ \'content\' ];
		$result .= \'</div>\';
	}
	
	
	
//=============================================================================
	
	
	
}elseif( $type == \'item_5\' ){
	$item_stat= $modx->runSnippet( \'BasketAction\', array( \'act\'=>\'stat\', \'id\'=>$row[\'id\'] ) );
	
	$img_mini= $modx->runSnippet( \'ImgCrop7\', array( \'img\'=>$row[\'image\'], \'w\'=>135, \'h\'=>135, \'fill\'=>true ) );
	$img_big= $modx->runSnippet( \'ImgCrop7\', array( \'img\'=>$row[\'image\'], \'w\'=>1111, \'h\'=>1111, \'wm\'=>true ) );
	
	$row[\'introtext\']= str_replace( "\\n", \'<br />\', $row[\'introtext\'] );
	
	$result .= \'<div class="catitem5 \'.( $last ? \'catitem5_last\' : \'\' ).\'">\';
	$result .= \'<div class="ci_img"><a class="highslide" onclick="return hs.expand(this)" href="\'. $img_big .\'"><img src="\'. $img_mini .\'" alt="\'. $row[\'pagetitle\'] .\'" ></a></div>\';
	$result .= \'<div class="ci_info">
		<div class="ci_tit">\'. $row[\'pagetitle\'] .\'</div>
	</div>\';
	$result .= \'<div class="ci_shop">
		<div class="ci_price"><nobr>\'.( $row[\'price_ot_flag\']==\'priceot\' ? \'<span>от</span> \' : \'\' ).\'<span class="price">\'. $modx->runSnippet( \'Price\', array( \'price\'=>$row[\'price\'], \'round\'=>0 ) ) .\'</span> <span class="rubl">a</span> <span class="edizm">\'.( $row[\'edizmerenia\'] ? \'/\'.$row[\'edizmerenia\'] : \'\' ).\'</span></nobr></div>
		
		<div class="ci_tobasket add_to_basket" id="ci_tobasket_\'. $row[\'id\'] .\'" data-itemid="\'. $row[\'id\'] .\'">\';
		if( $item_stat == \'netu\' ) $result .= \'<button>Купить</button><div style="display:none;"><a class="as2" href="[~38~]">Корзина</a></div><span style="display:none;"><center><img src="template/images/loading1.gif" /></center></span>\'; else $result .= \'<div><a class="as2" href="\'. $modx->makeUrl(38) .\'">В корзине</a></div>\';
		$result .= \'</div>
	</div>\';
	$result .= \'<div class="clr">&nbsp;</div></div>\';
	
	if( $last ) $result .= \'<div class="clr">&nbsp;</div>\';
	
	
	
//=============================================================================
	
	
	
}

return $result;';$s['Catalog_Birka']='//v001
//============================================================================

$myid= $modx->documentIdentifier;
if( empty( $id ) ) $id= $myid;

$template= 2;
$koren= 14;

if( $marker <= 0 ) return false; else $marker= intval( $marker );

$rr= mysql_query( "SELECT sc.id FROM ". $modx->getFullTableName( \'site_content\' ) ." AS sc
			INNER JOIN ". $modx->getFullTableName( \'site_tmplvar_contentvalues\' ) ." AS tv ON tv.contentid=sc.id AND tv.tmplvarid=17
				WHERE sc.template={$template} AND tv.`value`=\'{$marker}\'" );
if( $rr && mysql_num_rows( $rr ) > 0 ) while( $row= mysql_fetch_assoc( $rr ) ) $ids .= ( ! empty( $ids ) ? "," : "" ) . $row[ \'id\' ];

$docs= $modx->runSnippet( \'GetDoc5\', array( \'ids\' => $ids, \'type\' => \'this\', \'depth\' => 1, \'fields\' => \'pagetitle,isfolder\', \'tvfileds\' => \'image,lentochka\', \'isf\' => \'1\', \'sort\' => \'menuindex\' ) );

//$docs2= $modx->runSnippet( \'GetDoc5\', array( \'ids\' => $ids, \'type\' => \'this\', \'fields\' => \'pagetitle,parent,isfolder,content,introtext\',
//											\'tvfileds\' => \'image,price,art,marker,oldprice,edizmerenia\', \'isf\' => \'0\', \'sort\' => \'menuindex\', \'limit\' => $page_s .",". $MaxItemsInPage ) );

if( $docs && $docs2 ) $docs= array_merge( $docs, $docs2 ); elseif( $docs2 ) $docs= $docs2;

if( $docs )
{
	
	$ii= 0;
	$iii= 0;
	foreach( $docs AS $row )
	{
		if( $row[ \'isfolder\' ] == 1 )
		{		
			$ii++;
			$items .= $modx->runSnippet( \'CAT_ITEM\', array( \'type\' => \'category\', \'val\' => $row, \'indexcatalog\' => $indexcatalog, \'last\' => ( $ii % 4 == 0 ? true : false ), \'parentlist\' => $parentlist[ $row[ \'id\' ] ], \'mylvl\' => $mylvl[ $row[ \'id\' ] ] ) );
			
		}else{
			$iii++;
			$items .= $modx->runSnippet( \'CAT_ITEM\', array( \'type\' => \'item\', \'val\' => $row, \'last\' => ( $iii % 3 == 0 ? true : false ), \'parentlist\' => $parentlist[ $row[ \'parent\' ] ] ) );
		}
	}
}

$result .= \'<div id="catalog" class="catalog \'.( $indexcatalog ? \'indexcatalog\' : \'catalogpage\' ).\'">\';
if( $items != \'\' )
{
	$result .= $items;
	$result .= \'<div class="clr">&nbsp;</div>\';
}
$result .= \'</div>\';

return $result;';$s['CATALOG']='/*
$print .= \'<img src="\'. $modx->runSnippet( \'ImgCrop7\', array( \'img\'=>\'assets/images/catalog/zhaluzi/gg_h01.jpg\', \'toimg\'=>\'tmp1.jpg\', \'r\'=>true, \'w\'=>150, \'h\'=>150 ) ) .\'" />\';
$print .= \'<img src="\'. $modx->runSnippet( \'ImgCrop7\', array( \'img\'=>\'assets/images/catalog/zhaluzi/gg_h01.jpg\', \'toimg\'=>\'tmp2.jpg\', \'r\'=>true, \'w\'=>150, \'h\'=>150, \'fill\'=>true ) ) .\'" />\';
$print .= \'<img src="\'. $modx->runSnippet( \'ImgCrop7\', array( \'img\'=>\'assets/images/catalog/zhaluzi/gg_h01.jpg\', \'toimg\'=>\'tmp3.jpg\', \'r\'=>true, \'w\'=>150, \'h\'=>150, \'backgr\'=>true ) ) .\'" />\';
$print .= \'<img src="\'. $modx->runSnippet( \'ImgCrop7\', array( \'img\'=>\'assets/images/catalog/zhaluzi/gg_h01.jpg\', \'toimg\'=>\'tmp4.jpg\', \'r\'=>true, \'w\'=>150, \'h\'=>150, \'backgr\'=>true, \'bgcolor\'=>\'200,200,200,127\' ) ) .\'" />\';
$print .= \'<img src="\'. $modx->runSnippet( \'ImgCrop7\', array( \'img\'=>\'assets/images/catalog/zhaluzi/gg_h01.jpg\', \'toimg\'=>\'tmp5.jpg\', \'r\'=>true, \'w\'=>150, \'h\'=>150, \'backgr\'=>true, \'bgcolor\'=>\'470:600\' ) ) .\'" />\';
$print .= \'<img src="\'. $modx->runSnippet( \'ImgCrop7\', array( \'img\'=>\'assets/images/catalog/zhaluzi/gg_h01.jpg\', \'toimg\'=>\'tmp6.jpg\', \'r\'=>true, \'w\'=>150, \'h\'=>150, \'backgr\'=>true, \'bgcolor\'=>\'fill:\'.IMG_FILTER_BRIGHTNESS.\';-100\' ) ) .\'" />\';

$print .= \'<img src="\'. $modx->runSnippet( \'ImgCrop7\', array( \'img\'=>\'assets/images/catalog/zhaluzi/gg_h01.jpg\', \'toimg\'=>\'tmp7.jpg\', \'r\'=>true, \'w\'=>150, \'h\'=>150, \'fill\'=>true, \'wm\'=>true ) ) .\'" />\';
	
$print .= \'<img src="\'. $modx->runSnippet( \'ImgCrop7\', array( \'img\'=>\'assets/images/catalog/zhaluzi/gg_h01.jpg\', \'toimg\'=>\'tmp8.jpg\', \'r\'=>true, \'w\'=>150, \'h\'=>150, \'filter\'=>IMG_FILTER_BRIGHTNESS.\';100\' ) ) .\'" />\';

$print .= \'<img src="\'. $modx->runSnippet( \'ImgCrop7\', array( \'img\'=>\'assets/images/catalog/zhaluzi/gg_h01.jpg\', \'toimg\'=>\'tmp9.jpg\', \'r\'=>true, \'w\'=>150, \'h\'=>150, \'fill\'=>true, \'ellipse\'=>\'max\' ) ) .\'" />\';

$print .= \'<img src="\'. $modx->runSnippet( \'ImgCrop7\', array( \'img\'=>\'assets/images/catalog/zhaluzi/gg_h01.jpg\', \'toimg\'=>\'tmp10.jpg\', \'r\'=>true, \'w\'=>150, \'h\'=>150, \'fill\'=>true, \'ellipse\'=>\'max\', \'degstep\'=>45 ) ) .\'" />\';

$print .= \'<img src="\'. $modx->runSnippet( \'ImgCrop7\', array( \'img\'=>\'assets/images/catalog/zhaluzi/gg_h01.jpg\', \'toimg\'=>\'tmp11.jpg\', \'r\'=>true, \'w\'=>90, \'h\'=>90, \'fill\'=>true, \'ellipse\'=>\'max\', \'degstep\'=>15, \'dopimg\'=>\'template/images/kruzhok1.png\', \'dopimg_xy\'=>\'0:0\' ) ) .\'" />\';

$print .= \'<img src="\'. $modx->runSnippet( \'ImgCrop7\', array( \'img\'=>\'assets/images/catalog/zhaluzi/gg_h01.jpg\', \'toimg\'=>\'tmp12.jpg\', \'r\'=>true, \'w\'=>150, \'h\'=>150, \'quality\'=>10 ) ) .\'" />\';
	
$print .= \'<img src="\'. $modx->runSnippet( \'ImgCrop7\', array( \'img\'=>\'assets/images/catalog/zhaluzi/gg_h01.jpg\', \'toimg\'=>\'tmp13.jpg\', \'r\'=>true, \'w\'=>150, \'h\'=>150 ) ) .\'" />\';
$print .= \'<img src="\'. $modx->runSnippet( \'ImgCrop7\', array( \'img\'=>\'assets/images/catalog/zhaluzi/gg_h01.jpg\', \'toimg\'=>\'tmp14.jpg\', \'r\'=>true, \'w\'=>150, \'h\'=>150, \'filter\' => IMG_FILTER_BRIGHTNESS.\';5|\'.IMG_FILTER_CONTRAST.\';-10|\'.IMG_FILTER_SMOOTH.\';-20\' ) ) .\'" />\';
*/
	
	
//============================================================================
$catalog_koren= 14;
$catalog_template= 2;

$templates= array(
	// docId => array( кол-во в строке, название шаблона )
	\'24\' =>					array( 1, \'item_1\' ),
	\'25\' =>					array( 2, \'item_2\' ),
	\'26\' =>					array( 2, \'item_2\' ),
	\'>=28\' =>				array( 2, \'item_2\' ),
	\'92\' =>					array( 2, \'item_2\' ),
	\'93\' =>					array( 2, \'item_2\' ),
	\'94\' =>					array( 5, \'item_5\' ),
	\'>97\' =>				array( 5, \'item_5\' ),
);
//============================================================================

	
$myid= $modx->documentIdentifier;
if( empty( $id ) ) $id= $myid;
//$doc= $modx->getDocument( $id, \'id,pagetitle,isfolder,content,introtext\' );
$doc= $modx->runSnippet( \'GetDoc6\', array( \'ids\'=>$id, \'type\'=>\'this\', \'fields\'=>\'pagetitle,isfolder,content,introtext,parent\', \'tvfileds\'=>\'image\', \'isf\'=>\'all\' ) );
$doc= $doc[ $id ];


$lvl= $modx->runSnippet( \'GetLvl\', array( \'koren\'=>$catalog_koren, \'id\'=>$id ) );
$maincategory= $modx->runSnippet( \'GetIdOnLvl\', array( \'koren\'=>$catalog_koren, \'id\'=>$id ) );
if( $maincategory[2][\'id\'] == 22 )
{
	if( $maincategory[3][\'id\'] == 48 ) $calculator= 48;
	if( $maincategory[3][\'id\'] == 49 ) $calculator= 49;
	if( $maincategory[3][\'id\'] == 50 ) $calculator= 50;
	//if( $maincategory[3][\'id\'] == 51 ) $calculator= 51;
}
if( $calculator )
{
	$print= $modx->runSnippet( \'Calculator\', array( \'calculator\'=>$calculator ) );
	$print .= $doc[ \'content\' ];
	return $print;
}


if( $templates[\'>=\'.$id][1] ) $template= $templates[\'>=\'.$id];
if( $templates[\'>=\'.$doc[\'parent\']][1] ) $template= $templates[\'>=\'.$doc[\'parent\']];
if( $templates[\'>\'.$doc[\'parent\']][1] ) $template= $templates[\'>\'.$doc[\'parent\']];
if( $templates[$id][1] ) $template= $templates[$id];
if( ! $template[1] ) $template= array( 2, \'item_2\' );


$ParentsPublishedList_flag= $modx->runSnippet( \'ParentsPublishedList\', array( \'koren\'=>$catalog_koren, \'id\'=>$id ) );
if( $lvl && ! $ParentsPublishedList_flag ) $modx->sendErrorPage();


if( $doc[ \'isfolder\' ] == 1 )
{
	$docs= $modx->runSnippet( \'GetDoc6\', array( \'ids\'=>$id, \'type\'=>\'childs\', \'depth\'=>\'1\', \'fields\'=>\'pagetitle,isfolder,introtext,menuindex,parent\',
												\'tvfileds\'=>\'image,price,price_ot_flag,edizmerenia,lentochka,mini_description\', \'isf\'=>\'all\', \'sort\'=>\'menuindex\' ) );
	if( $docs )
	{
		$ii= 0;
		$iii= 0;
		foreach( $docs AS $row )
		{
			if( $row[ \'isfolder\' ] == 1 || $itemprinttype == \'category\' )
			{
				$ii++;
				$categories .= $modx->runSnippet( \'CAT_ITEM\', array( \'id\'=>$id, \'type\'=>\'category\', \'row\'=>$row, \'last\'=>( $ii % ( $indexcatalog ? 3 : 4 ) == 0 ? true : false ), \'indexcatalog\'=>$indexcatalog ) );
				
			}else{
				$iii++;
				$items .= $modx->runSnippet( \'CAT_ITEM\', array( \'type\'=>$template[1], \'row\'=>$row, \'last\'=>( $iii % $template[0] == 0 ? true : false ) ) );
			}
		}
	}
	
	if( ! empty( $doc[ \'content\' ] ) ) $content .= $doc[ \'content\' ];
	
}elseif( true ){
	$docinfo= $modx->runSnippet( \'GetDoc6\', array( \'ids\'=>$id, \'type\'=>\'this\', \'fields\'=>\'pagetitle,isfolder,introtext,menuindex,parent,content\',
												  \'tvfileds\'=>\'image,price,price_ot_flag,edizmerenia,lentochka,mini_description\', \'isf\'=>\'0\' ) );
	$item_page .= $modx->runSnippet( \'CAT_ITEM\', array( \'type\'=>$template[1], \'thispage\'=>true, \'row\'=>$docinfo[ $id ] ) );
}


$print .= \'<div id="catalog" class="catalog \'.( $indexcatalog ? \'catalogindex\' : \'catalogpage\' ).\'" itemscope itemtype="http://schema.org/Product">\';
if( ! empty( $categories ) )
{
	$print .= $categories;
	$print .= \'<div class="clr">&nbsp;</div>\';
	if( ! empty( $items ) ) $print .= \'<br /><br />\';
}
if( ! empty( $items ) )
{
	$print .= $items;
	$print .= \'<div class="clr">&nbsp;</div>\';
}
if( ! empty( $item_page ) )
{
	$print .= $item_page;
}
$print .= \'</div>\';


if( $type != \'content\' )
{
	$print .= \'<div class="clr">&nbsp;</div>\';
	$print .= \'<div class="category_content">\'. $content .\'</div>\';
	$print .= \'<div class="clr">&nbsp;</div>\';
}


return $print;';$p=&$this->pluginCache;$p['CodeMirror']='$_CM_BASE = \'assets/plugins/codemirror/\';

$_CM_URL = $modx->config[\'site_url\'] . $_CM_BASE;

require(MODX_BASE_PATH. $_CM_BASE .\'codemirror.plugin.php\');';$p['CodeMirrorProps']='&theme=Theme;list;default,ambiance,blackboard,cobalt,eclipse,elegant,erlang-dark,lesser-dark,midnight,monokai,neat,night,rubyblue,solarized,twilight,vibrant-ink,xq-dark,xq-light; &indentUnit=Indent unit;int;4 &tabSize=The width of a tab character;int;4 &lineWrapping=lineWrapping;list;true,false;true &matchBrackets=matchBrackets;list;true,false;true &activeLine=activeLine;list;true,false;false &emmet=emmet;list;true,false;true &search=search;list;true,false;false &indentWithTabs=indentWithTabs;list;true,false;true ';$p['Forgot Manager Login']='require MODX_BASE_PATH.\'assets/plugins/forgotmanagerlogin/plugin.forgotmanagerlogin.php\';';$p['FileSource']='require MODX_BASE_PATH.\'assets/plugins/filesource/plugin.filesource.php\';';$p['ManagerManager']='// You can put your ManagerManager rules EITHER in a chunk OR in an external file - whichever suits your development style the best

// To use an external file, put your rules in /assets/plugins/managermanager/mm_rules.inc.php 
// (you can rename default.mm_rules.inc.php and use it as an example)
// The chunk SHOULD have php opening tags at the beginning and end

// If you want to put your rules in a chunk (so you can edit them through the Manager),
// create the chunk, and enter its name in the configuration tab.
// The chunk should NOT have php tags at the beginning or end.

// See also user-friendly module for editing ManagerManager configuration file ddMMEditor (http://code.divandesign.biz/modx/ddmmeditor).

// ManagerManager requires jQuery 1.9.1, which is located in /assets/plugins/managermanager/js/ folder.

// You don\'t need to change anything else from here onwards
//-------------------------------------------------------

// Run the main code
include($modx->config[\'base_path\'].\'assets/plugins/managermanager/mm.inc.php\');';$p['ManagerManagerProps']='&remove_deprecated_tv_types_pref=Remove deprecated TV types;list;yes,no;yes &config_chunk=Configuration Chunk;text;mm_rules ';$p['TinyMCE Rich Text Editor']='require MODX_BASE_PATH.\'assets/plugins/tinymce/plugin.tinymce.php\';';$p['TinyMCE Rich Text EditorProps']='&customparams=Custom Parameters;textarea;valid_elements : "*[*]", &mce_formats=Block Formats;text;p,h1,h2,h3,h4,h5,h6,div,blockquote,code,pre &entity_encoding=Entity Encoding;list;named,numeric,raw;named &entities=Entities;text; &mce_path_options=Path Options;list;Site config,Absolute path,Root relative,URL,No convert;Site config &mce_resizing=Advanced Resizing;list;true,false;true &disabledButtons=Disabled Buttons;text; &link_list=Link List;list;enabled,disabled;enabled &webtheme=Web Theme;list;simple,editor,creative,custom;simple &webPlugins=Web Plugins;text;style,advimage,advlink,searchreplace,contextmenu,paste,fullscreen,xhtmlxtras,media &webButtons1=Web Buttons 1;text;undo,redo,selectall,|,pastetext,pasteword,|,search,replace,|,hr,charmap,|,image,link,unlink,anchor,media,|,cleanup,removeformat,|,fullscreen,code,help &webButtons2=Web Buttons 2;text;bold,italic,underline,strikethrough,sub,sup,|,|,blockquote,bullist,numlist,outdent,indent,|,justifyleft,justifycenter,justifyright,justifyfull,|,styleselect,formatselect,|,styleprops &webButtons3=Web Buttons 3;text; &webButtons4=Web Buttons 4;text; &webAlign=Web Toolbar Alignment;list;ltr,rtl;ltr &width=Width;text;100% &height=Height;text;500 ';$p['TransAlias']='require MODX_BASE_PATH.\'assets/plugins/transalias/plugin.transalias.php\';';$p['TransAliasProps']='&table_name=Trans table;list;common,russian,dutch,german,czech,utf8,utf8lowercase;russian &char_restrict=Restrict alias to;list;lowercase alphanumeric,alphanumeric,legal characters;lowercase alphanumeric &remove_periods=Remove Periods;list;Yes,No;No &word_separator=Word Separator;list;dash,underscore,none;dash &override_tv=Override TV name;string; ';$p['REDIRECT']='$subfolder= \'/_new\';

$redirect= array(
	1 => array(
		\'/index.html\' => \'/\',
		\'/index.php\' => \'/\',
		
		\'/cont/\' => \'/contacts.html\',
	)
);

//=================================================================

$REQUEST_URI= str_replace( $subfolder, \'\', $_SERVER[ \'REQUEST_URI\' ] );
if( $redirect[ 1 ][ $REQUEST_URI ] )
{
	header( \'HTTP/1.1 301 Moved Permanently\' );
	header( \'location: \'. $subfolder . $redirect[ 1 ][ $REQUEST_URI ] );
	exit();
}';$p['BaseAndCanonical']='//v004
//BaseAndCanonical
//=========================================================================================
//MODX_SITE_URL = http://domain.ru/
	//$_SERVER[ \'REDIRECT_URL\' ] = /sdfsdf/mail.html
	
	//<base href="" />
	//<link rel="canonical" href="http://domain.ru/404.html" />
	//<base_and_canonical>
$html= $modx->documentOutput;
if( true || isset( $_GET[ \'test\' ] ) )
{
	$wsite= rtrim( MODX_SITE_URL, "/" );
	$redirurl= ( ! empty( $_SERVER[ \'REDIRECT_URL\' ] ) ? $_SERVER[ \'REDIRECT_URL\' ] : \'/\' );
	//$redirurl= $modx->makeUrl( $modx->documentIdentifier );
	
	$uri= strpos( $_SERVER[ \'REQUEST_URI\' ], "?" );
	$get= \'\';
	if( $uri !== false )
	{
		$get= substr( $_SERVER[ \'REQUEST_URI\' ], $uri );
	}
	
	$canonical= $wsite . $redirurl .( $get ? $get : \'\' );
	$base= MODX_SITE_URL;
	
	if( ! empty( $canonical ) && ! empty( $base ) )
	{
		$base_and_canonical .= \'<base href="\'. $base .\'" />\';
		$base_and_canonical .= "\\r\\n\\t";
		$base_and_canonical .= \'<link rel="canonical" href="\'. $canonical .\'" />\';
	}
	
	$html= str_replace( "<base_and_canonical />", $base_and_canonical, $html );
	
	/*
	//preg_match_all( "/<link (.*)rel=\\"canonical\\"(.*)href=(\\"(.*)\\"|\'(.*)\')(.*)>/imU", $html, $ss );
	preg_match_all( "/<link (.*)rel=\\"canonical\\"(.*)>/imU", $html, $ss );
	
	if( ! empty( $ss[ 0 ][ 0 ] ) )
	{
		preg_match_all( "/href=(\\"(.*)\\"|\'(.*)\')/imU", $ss[ 0 ][ 0 ], $sss );
		
		$redirurl= ( ! empty( $_SERVER[ \'REDIRECT_URL\' ] ) ? $_SERVER[ \'REDIRECT_URL\' ] : \'/\' );
		
		print \'Установлен: \'. $sss[ 2 ][ 0 ] ."\\r\\n";
		print \'Нужно:      \'. $wsite . $redirurl ."\\r\\n";
	}
	*/
}
$modx->documentOutput= $html;';$p['Antideer4']='// v4
// 24.06.2016
// Antideer
// Для MODx Evo 1.1
//===========================================================================
$tb_1= \'site_content\';
$tb_2= \'site_htmlsnippets\';
$tb_3= \'site_snippets\';
$tb_4= \'site_templates\';
$tb_5= \'site_tmplvar_contentvalues\';
$tb_6= \'site_tmplvars\';

mysql_query( "CREATE TABLE IF NOT EXISTS ".$modx->getFullTableName( \'aaa_\'. $tb_1 )." (
  `idm` int(10) NOT NULL AUTO_INCREMENT,
  `id` int(10) NOT NULL,
  `type` varchar(20) NOT NULL DEFAULT \'document\',
  `contentType` varchar(50) NOT NULL DEFAULT \'text/html\',
  `pagetitle` varchar(255) NOT NULL DEFAULT \'\',
  `longtitle` varchar(255) NOT NULL DEFAULT \'\',
  `description` varchar(255) NOT NULL DEFAULT \'\',
  `alias` varchar(255) DEFAULT \'\',
  `link_attributes` varchar(255) NOT NULL DEFAULT \'\' COMMENT \'Link attriubtes\',
  `published` int(1) NOT NULL DEFAULT \'0\',
  `pub_date` int(20) NOT NULL DEFAULT \'0\',
  `unpub_date` int(20) NOT NULL DEFAULT \'0\',
  `parent` int(10) NOT NULL DEFAULT \'0\',
  `isfolder` int(1) NOT NULL DEFAULT \'0\',
  `introtext` text COMMENT \'Used to provide quick summary of the document\',
  `content` mediumtext,
  `richtext` tinyint(1) NOT NULL DEFAULT \'1\',
  `template` int(10) NOT NULL DEFAULT \'0\',
  `menuindex` int(10) NOT NULL DEFAULT \'0\',
  `searchable` int(1) NOT NULL DEFAULT \'1\',
  `cacheable` int(1) NOT NULL DEFAULT \'1\',
  `createdby` int(10) NOT NULL DEFAULT \'0\',
  `createdon` int(20) NOT NULL DEFAULT \'0\',
  `editedby` int(10) NOT NULL DEFAULT \'0\',
  `editedon` int(20) NOT NULL DEFAULT \'0\',
  `deleted` int(1) NOT NULL DEFAULT \'0\',
  `deletedon` int(20) NOT NULL DEFAULT \'0\',
  `deletedby` int(10) NOT NULL DEFAULT \'0\',
  `publishedon` int(20) NOT NULL DEFAULT \'0\' COMMENT \'Date the document was published\',
  `publishedby` int(10) NOT NULL DEFAULT \'0\' COMMENT \'ID of user who published the document\',
  `menutitle` varchar(255) NOT NULL DEFAULT \'\' COMMENT \'Menu title\',
  `donthit` tinyint(1) NOT NULL DEFAULT \'0\' COMMENT \'Disable page hit count\',
  `haskeywords` tinyint(1) NOT NULL DEFAULT \'0\' COMMENT \'has links to keywords\',
  `hasmetatags` tinyint(1) NOT NULL DEFAULT \'0\' COMMENT \'has links to meta tags\',
  `privateweb` tinyint(1) NOT NULL DEFAULT \'0\' COMMENT \'Private web document\',
  `privatemgr` tinyint(1) NOT NULL DEFAULT \'0\' COMMENT \'Private manager document\',
  `content_dispo` tinyint(1) NOT NULL DEFAULT \'0\' COMMENT \'0-inline, 1-attachment\',
  `hidemenu` tinyint(1) NOT NULL DEFAULT \'0\' COMMENT \'Hide document from menu\',
  `alias_visible` int(2) NOT NULL DEFAULT \'1\',
  PRIMARY KEY (`idm`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;" );


mysql_query( "CREATE TABLE IF NOT EXISTS ".$modx->getFullTableName( \'aaa_\'. $tb_5 )." (
  `idm` int(11) NOT NULL AUTO_INCREMENT,
  `id` int(11) NOT NULL,
  `tmplvarid` int(10) NOT NULL DEFAULT \'0\' COMMENT \'Template Variable id\',
  `contentid` int(10) NOT NULL DEFAULT \'0\' COMMENT \'Site Content Id\',
  `value` text,
  PRIMARY KEY (`idm`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;" );


mysql_query( "CREATE TABLE IF NOT EXISTS ".$modx->getFullTableName( \'aaa_\'. $tb_2 )." (
  `idm` int(10) NOT NULL AUTO_INCREMENT,
  `id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL DEFAULT \'\',
  `description` varchar(255) NOT NULL DEFAULT \'Chunk\',
  `editor_type` int(11) NOT NULL DEFAULT \'0\' COMMENT \'0-plain text,1-rich text,2-code editor\',
  `editor_name` varchar(50) NOT NULL DEFAULT \'none\',
  `category` int(11) NOT NULL DEFAULT \'0\' COMMENT \'category id\',
  `cache_type` tinyint(1) NOT NULL DEFAULT \'0\' COMMENT \'Cache option\',
  `snippet` mediumtext,
  `locked` tinyint(4) NOT NULL DEFAULT \'0\',
  PRIMARY KEY (`idm`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;" );


mysql_query( "CREATE TABLE IF NOT EXISTS ".$modx->getFullTableName( \'aaa_\'. $tb_3 )." (
  `idm` int(10) NOT NULL AUTO_INCREMENT,
  `id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL DEFAULT \'\',
  `description` varchar(255) NOT NULL DEFAULT \'Snippet\',
  `editor_type` int(11) NOT NULL DEFAULT \'0\' COMMENT \'0-plain text,1-rich text,2-code editor\',
  `category` int(11) NOT NULL DEFAULT \'0\' COMMENT \'category id\',
  `cache_type` tinyint(1) NOT NULL DEFAULT \'0\' COMMENT \'Cache option\',
  `snippet` mediumtext,
  `locked` tinyint(4) NOT NULL DEFAULT \'0\',
  `properties` text COMMENT \'Default Properties\',
  `moduleguid` varchar(32) NOT NULL DEFAULT \'\' COMMENT \'GUID of module from which to import shared parameters\',
  PRIMARY KEY (`idm`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;" );


mysql_query( "CREATE TABLE IF NOT EXISTS ".$modx->getFullTableName( \'aaa_\'. $tb_4 )." (
  `idm` int(10) NOT NULL AUTO_INCREMENT,
  `id` int(10) NOT NULL,
  `templatename` varchar(50) NOT NULL DEFAULT \'\',
  `description` varchar(255) NOT NULL DEFAULT \'Template\',
  `editor_type` int(11) NOT NULL DEFAULT \'0\' COMMENT \'0-plain text,1-rich text,2-code editor\',
  `category` int(11) NOT NULL DEFAULT \'0\' COMMENT \'category id\',
  `icon` varchar(255) NOT NULL DEFAULT \'\' COMMENT \'url to icon file\',
  `template_type` int(11) NOT NULL DEFAULT \'0\' COMMENT \'0-page,1-content\',
  `content` mediumtext,
  `locked` tinyint(4) NOT NULL DEFAULT \'0\',
  `selectable` tinyint(4) NOT NULL DEFAULT \'1\',
  PRIMARY KEY (`idm`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;" );

$e= &$modx->Event;
$mid= $e->params[ \'id\' ];

if( $e->name == "OnBeforeDocFormSave" || $e->name == "OnBeforeDocFormDelete" ) // СТРАНИЦЫ
{
	mysql_query( "INSERT INTO ".$modx->getFullTableName( \'aaa_\'. $tb_1 )."
		( `id`,`type`,`contentType`,`pagetitle`,`longtitle`,`description`,`alias`,
		`link_attributes`,`published`,`pub_date`,`unpub_date`,`parent`,`isfolder`,`introtext`,
		`content`,`richtext`,`template`,`menuindex`,`searchable`,`cacheable`,`createdby`,
		`createdon`,`editedby`,`editedon`,`deleted`,`deletedon`,`deletedby`,`publishedon`,
		`publishedby`,`menutitle`,`donthit`,`haskeywords`,`hasmetatags`,`privateweb`,`privatemgr`,`content_dispo`,`hidemenu`,`alias_visible` )
			SELECT * FROM ".$modx->getFullTableName( $tb_1 )." WHERE id={$mid} LIMIT 1" );
	
	$rr= mysql_query( "SELECT id FROM ".$modx->getFullTableName( $tb_6 )." ORDER BY id" );
	
	if( $rr && mysql_num_rows( $rr ) > 0 )
	{
		while( $row= mysql_fetch_assoc( $rr ) )
		{
			mysql_query( "INSERT INTO ".$modx->getFullTableName( \'aaa_\'. $tb_5 )." ( `id`, `tmplvarid`, `contentid`, `value` )
				SELECT * FROM ".$modx->getFullTableName( $tb_5 )." WHERE contentid={$mid} AND tmplvarid={$row[id]}" );
		}
	}
//----------------------------
	
}elseif( $e->name == "OnBeforeChunkFormSave" || $e->name == "OnBeforeChunkFormDelete" ){ // ЧАНКИ
	mysql_query( "INSERT INTO ".$modx->getFullTableName( \'aaa_\'. $tb_2 )." ( `id`,`name`,`description`,`editor_type`,`editor_name`,`category`,`cache_type`,`snippet`,`locked` )
		SELECT * FROM ".$modx->getFullTableName( $tb_2 )." WHERE id={$mid} LIMIT 1" );
//----------------------------
	
}elseif( $e->name == "OnBeforeSnipFormSave" || $e->name == "OnBeforeSnipFormDelete" ){ // СНИППЕТЫ
	mysql_query( "INSERT INTO ".$modx->getFullTableName( \'aaa_\'. $tb_3 )." ( `id`,`name`,`description`,`editor_type`,`category`,`cache_type`,`snippet`,`locked`,`properties`,`moduleguid` )
		SELECT * FROM ".$modx->getFullTableName( $tb_3 )." WHERE id={$mid} LIMIT 1" );
//----------------------------
	
}elseif( $e->name == "OnBeforeTempFormSave" || $e->name == "OnBeforeTempFormDelete" ){ // ШАБЛОНЫ
	mysql_query( "INSERT INTO ".$modx->getFullTableName( \'aaa_\'. $tb_4 )." ( `id`,`templatename`,`description`,`editor_type`,`category`,`icon`,`template_type`,`content`,`locked`,`selectable` )
		SELECT * FROM ".$modx->getFullTableName( $tb_4 )." WHERE id={$mid} LIMIT 1" );
}';$p['Highslide']='//v001
//26.05.2016
//Highslide
//Event: OnWebPagePrerender
//Snippet: ImgCrop71
//<a class="highslide" onclick="return hs.expand(this)" href><img class="highslidezoom" /></a>
//======================================================================================
$html= $modx->documentOutput;
if( true || isset( $_GET[ \'test\' ] ) )
{
	preg_match_all( \'/<img(.*)class="(.*)highslidezoom(.*)"(.*)>/imU\', $html, $result );
	
	if( $result )
	{
		foreach( $result[ 0 ] AS $row )
		{
			preg_match_all( \'/src="(.*)"/imU\', $row, $src );
			$img= $modx->runSnippet( \'ImgCrop71\', array( \'img\'=>$src[ 1 ][ 0 ], \'wm\'=>true ) );
			$row2= str_replace( $src[ 1 ][ 0 ], $img, $row );
			if( $src[ 1 ] ) $html= str_replace( $row, \'<a class="highslide" onclick="return hs.expand(this)" href="\'. $img .\'">\'. $row2 .\'</a>\', $html );
		}
	}
}
$modx->documentOutput= $html;';$e = &$this->pluginEvent;$e['OnBeforeChunkFormDelete']=array('Antideer4');$e['OnBeforeChunkFormSave']=array('Antideer4');$e['OnBeforeDocFormDelete']=array('Antideer4');$e['OnBeforeDocFormSave']=array('ManagerManager','Antideer4');$e['OnBeforeManagerLogin']=array('Forgot Manager Login');$e['OnBeforePluginFormSave']=array('FileSource');$e['OnBeforeSnipFormDelete']=array('Antideer4');$e['OnBeforeSnipFormSave']=array('FileSource','Antideer4');$e['OnBeforeTempFormDelete']=array('Antideer4');$e['OnBeforeTempFormSave']=array('Antideer4');$e['OnChunkFormRender']=array('CodeMirror');$e['OnDocDuplicate']=array('ManagerManager');$e['OnDocFormPrerender']=array('ManagerManager');$e['OnDocFormRender']=array('ManagerManager','CodeMirror');$e['OnDocFormSave']=array('ManagerManager');$e['OnInterfaceSettingsRender']=array('TinyMCE Rich Text Editor');$e['OnManagerAuthentication']=array('Forgot Manager Login');$e['OnManagerLoginFormRender']=array('Forgot Manager Login');$e['OnModFormRender']=array('CodeMirror');$e['OnPluginFormPrerender']=array('FileSource');$e['OnPluginFormRender']=array('CodeMirror','ManagerManager','FileSource');$e['OnRichTextEditorInit']=array('TinyMCE Rich Text Editor');$e['OnRichTextEditorRegister']=array('TinyMCE Rich Text Editor');$e['OnSnipFormPrerender']=array('FileSource');$e['OnSnipFormRender']=array('FileSource','CodeMirror');$e['OnStripAlias']=array('TransAlias');$e['OnTempFormRender']=array('CodeMirror');$e['OnTVFormRender']=array('ManagerManager');$e['OnWebPageInit']=array('REDIRECT');$e['OnWebPagePrerender']=array('REDIRECT','BaseAndCanonical','Highslide');