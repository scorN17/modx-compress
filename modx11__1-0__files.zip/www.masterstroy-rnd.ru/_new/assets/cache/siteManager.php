<?php
define('MGR_DIR', 'manager');
