<?php
$recent_update = 1468573058;
$cacheRefreshTime = 0;