<?php
include_once(dirname(__FILE__) . "/autoTable.abstract.php");

class modChunk extends autoTable
{
    protected $table = "site_htmlsnippets";
}
