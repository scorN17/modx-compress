<?php
include_once(dirname(__FILE__) . "/autoTable.abstract.php");

class modModule extends autoTable
{
    protected $table = "site_modules";
}
