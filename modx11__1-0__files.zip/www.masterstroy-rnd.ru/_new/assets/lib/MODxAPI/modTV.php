<?php
include_once(dirname(__FILE__) . "/autoTable.abstract.php");

class modTV extends autoTable
{
    protected $table = "site_tmplvars";
}
