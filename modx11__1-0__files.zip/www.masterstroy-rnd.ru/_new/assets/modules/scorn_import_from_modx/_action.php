<?php


$sm_base= '../assets/modules/scorn_import_from_modx/';
$module_url= MODX_MANAGER_URL .'?a='. $_GET[ 'a' ] .'&id='. $_GET[ 'id' ];




$step= intval( $_GET['step'] );
if( ! $step ) $step= 1;
if( $_GET['act'] == 'import' )
{
	$prefix= addslashes( trim( $_POST['prefix'] ) );
	$iddonor= intval( $_POST['iddonor'] );
	$idrecipient= intval( $_POST['idrecipient'] );
	
	if( $step === 1 )
	{
		$tvs1= '';
		$rr= mysql_query("SELECT * FROM ".$modx->getFullTableName('site_tmplvars')."");
		if( $rr && mysql_num_rows( $rr ) > 0 )
		{
			$tvs1 .= '<option value="0">~ не использовать ~</option>';
			while( $row= mysql_fetch_assoc( $rr ) )
			{
				$tvs1 .= '<option value="'. $row['id'] .'">'. $row['id'] .' | '. $row['name'] .' | '. $row['caption'] .'</option>';
			}
		}
		
		$tvs2= '';
		$rr= mysql_query("SELECT * FROM `{$prefix}site_tmplvars`");
		if( $rr && mysql_num_rows( $rr ) > 0 )
		{
			while( $row= mysql_fetch_assoc( $rr ) )
			{
				$tvs2 .= '<div>Из ['. $row['id'] .' | '. $row['name'] .' | '. $row['caption'] .'] в
				<select name="tvs['. $row['id'] .']">'. $tvs1 .'</select></div>';
			}
		}
		
	}elseif( $step === 2 ){
		$tvs= $_POST['tvs'];
		
		tree( $iddonor, $idrecipient, $prefix, $tvs );
	}
	
	$step++;
}



function tree( $from, $to, $prefix, $tvs )
{
	global $modx;
	
	$rr= mysql_query("SELECT * FROM `{$prefix}site_content` WHERE parent={$from} AND published=1 AND deleted=0");
	if( $rr && mysql_num_rows( $rr ) > 0 )
	{
		while( $row= mysql_fetch_assoc( $rr ) )
		{
			$row['pagetitle']= addslashes( trim( $row['pagetitle'] ) );
			$rr2= mysql_query("SELECT * FROM ".$modx->getFullTableName('site_content')." WHERE pagetitle='{$row[pagetitle]}' AND parent={$to} LIMIT 1");
			if( $rr2 && mysql_num_rows( $rr2 ) == 1 )
			{
				$insert_id= mysql_result( $rr2, 0, 'id' );
			}else{
				$alias= $modx->runSnippet( 'GenerAlias', array( 'txt'=>$row['pagetitle'] ) );
				mysql_query("INSERT INTO ".$modx->getFullTableName('site_content')." SET
					pagetitle='$row[pagetitle]',
					alias='{$alias}',
					parent={$to},
					published=1,
					deleted=0,
					isfolder='{$row[isfolder]}',
					template=2");
				$insert_id= mysql_insert_id();
			}
			if( $insert_id )
			{
				foreach( $tvs AS $key => $val )
				{
					if( ! $val ) continue;
					$rr3= mysql_query("SELECT * FROM `{$prefix}site_tmplvar_contentvalues` WHERE tmplvarid={$key} AND contentid={$row[id]} LIMIT 1");
					if( $rr3 && mysql_num_rows( $rr3 ) == 1 && mysql_result( $rr3, 0, 'value' ) )
					{
						if( $val == 6 )
						{
							if( ! $parentslist[ $insert_id ] ) $parentslist[ $insert_id ]= $modx->runSnippet( 'GetIdOnLvl', array( 'koren'=>14, 'id'=>$insert_id ) );
							if( ! $path_to_koren[ $insert_id ] )
							{
								foreach( $parentslist[ $insert_id ] AS $tmprow )
								{
									if( $tmprow['id'] && $tmprow['id'] != 14 && $tmprow['id'] != $insert_id ) $path_to_koren[ $insert_id ] .= $tmprow['id'] .'/';
								}
							}

							if( ! file_exists( MODX_BASE_PATH .'assets/images/catalog/'. $path_to_koren[ $insert_id ] ) )
								mkdir( MODX_BASE_PATH .'assets/images/catalog/'. $path_to_koren[ $insert_id ], 0777, true );

							$filename= explode( '/', mysql_result( $rr3, 0, 'value' ) );
							$filename= $filename[ count($filename)-1 ];

							$imgfrom= file_get_contents( 'http://april-inter.ru/'.mysql_result( $rr3, 0, 'value' ) );
							$imgto= file_put_contents( MODX_BASE_PATH .'assets/images/catalog/'. $path_to_koren[ $insert_id ] . $filename, $imgfrom );

							tv_insert_update( $val, $insert_id, 'assets/images/catalog/'. $path_to_koren[ $insert_id ] . $filename );

						}else{
							tv_insert_update( $val, $insert_id, addslashes( trim( mysql_result( $rr3, 0, 'value' ) ) ) );
						}
					}
				}

				tree( $row['id'], $insert_id, $prefix, $tvs );
			}
		}
	}
}



function tv_insert_update( $tmplvarid, $contentid, $value )
{
	global $modx;
	$rr2= mysql_query( "SELECT id FROM ".$modx->getFullTableName( 'site_tmplvar_contentvalues' )." WHERE tmplvarid='{$tmplvarid}' AND contentid='{$contentid}' LIMIT 1" );
	if( $rr2 && mysql_num_rows( $rr2 ) == 1 )
	{
		mysql_query( "UPDATE ".$modx->getFullTableName( 'site_tmplvar_contentvalues' )." SET `value`='{$value}' WHERE id=". mysql_result( $rr2, 0, 'id' ) ." LIMIT 1" );
	}elseif( $rr2 ){
		mysql_query( "INSERT INTO ".$modx->getFullTableName( 'site_tmplvar_contentvalues' )." SET tmplvarid='{$tmplvarid}', contentid='{$contentid}', `value`='{$value}'" );
	}
}
function tv_append( $tmplvarid, $contentid, $value )
{
	global $modx;
	mysql_query( "UPDATE ".$modx->getFullTableName( 'site_tmplvar_contentvalues' )." SET `value`=CONCAT(`value`,'||{$value}') WHERE tmplvarid='{$tmplvarid}' AND contentid='{$contentid}' LIMIT 1" );
}



if( $result != '' ) $result .= '<br /><br />';
if( $result2 != '' ) $result2 .= '<br /><br />';

?><div class="modul_scorn_all">
<!-- -------------------------- -->
<link rel="stylesheet" type="text/css" href="<?php print $sm_base;?>_styles.css" />
<script type="text/javascript" src="//yandex.st/jquery/2.1.0/jquery.min.js"></script>
<script type="text/javascript" src="//yandex.st/jquery-ui/1.10.4/jquery-ui.min.js"></script>
	
	
	
	
<?php if( $step <= 2 ){ ?>
	<form action="<?= $module_url ?>&act=import&step=<?= $step ?>" method="post">
		<div><label>Префикс таблиц донора <input type="text" name="prefix" value="<?= $prefix ?>" /></label></div>
		<div><label>ID ресурса донора <input type="text" name="iddonor" value="<?= $iddonor ?>" /> (все подресурсы)</label></div>
		<div><label>ID ресурса реципиента <input type="text" name="idrecipient" value="<?= $idrecipient ?>" /></label></div>
		
		<br />
		<?php if( $step === 1 ){ ?>
			<div><label><button type="submit">Далее ...</button></label></div>
		
		<?php }else{ ?>
			<?= $tvs2 ?>
			<br />
			<div><label><button type="submit">Импортировать</button></label></div>
		<?php } ?>
	</form>
<?php } ?>
	
	
	
	
<?php
/*
*/
?>