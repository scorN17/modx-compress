<?php
$_lang["Static file path"] = 'Static file path';
