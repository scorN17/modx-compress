<?php
$_lang["Static file path"] = 'Statischer Dateipfad';
