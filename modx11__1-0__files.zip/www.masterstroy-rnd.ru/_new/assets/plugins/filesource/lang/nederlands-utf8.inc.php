<?php
$_lang["Static file path"] = 'Statische bestandspad';
