<?php
$_lang["Static file path"] = 'Ruta de archivo estático';
